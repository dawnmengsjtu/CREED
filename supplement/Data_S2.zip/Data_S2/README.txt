Data S2. Pre-registration files and reproduction-gate logs, related to STAR Methods.

For each 2026-10-09 analysis and the 2026-10-11 follow-up N6 (for N6 also the per-fold results, automated analyses,
run code and logs, dry-run summaries and the script that builds Table S15): PLAN.md and, where recorded, the
registration time, SHA256SUMS and OUTPUT_SHA256SUMS, and the reproduction-gate summaries; also the protocols of the
three 2026-10-08 development runs whose folds, inner banks, teacher and graph design later runs reuse. For the
2026-10-22 prospective test of the low-dimensional structure: the plan with its addendum, registration times, checksum
lists, input list, GDSC1 data-gate record, dry-run summaries, per-fold gates and results, analysis outputs and run
logs, including the log of the first scoring attempt (the same for all 30 folds), which stopped on a software error
before any score was written.

About this archive
- Run records are byte-for-byte copies (not edited). Files that are not copies of files of the server run directories
  (derived tables, renderings, and records kept outside the compute server) are described under "Files" below.
- Plain-text formats only (.csv, .env, .json, .log, .md, .py, .sh, .tsv, .txt, checksum lists without extension or
  with .v1-.v3). JSON files use NaN for missing values (Python json syntax; strict parsers need NaN replaced by null).
- Most registered plans and audit records are in Chinese, as registered; they are not translated.
- Some files contain absolute file paths of the compute server (/public/home/<user>/...) and of the authors' local
  workstation (/Users/<user>/...); they are left unedited so that the files stay byte-identical to the original
  records.
- Run folders have the layout of the run directory on the compute server, so each checksum list can be checked from
  its run folder (e.g. cd Data_S2/<run folder>; shasum -a 256 -c <list>). Entries for files not included here (code
  files, .npz arrays, RESULT.md files and other run files) are reported as missing. Lines beginning with # are
  comments written by the runs; checkers report them as improperly formatted. CHECKSUM_INDEX.tsv (derived by the
  archive builder) gives the status of every entry: OK (verifies here), FAILED (a different version is at the listed
  path; see Plan versions), ELSEWHERE (the same bytes are at the archive path given), NOT_INCLUDED.

Files
Run folders (folder = server run directory under /public/home/<user>/creed-research-runs/; registration time from
PLAN_REGISTERED_AT.txt; checksum lists present):
  acquisition_probe = acquisition-probe-20261009-0001; registration time: none (registration date stated in PLAN.md);
  checksum lists: OUTPUT_SHA256SUMS, SHA256SUMS
  acquisition_probe_rna = acquisition-probe-rna-20261009-0001; registration time: 2026-10-09T14:14:24+0800; checksum
  lists: SHA256SUMS
  crispr_endpoint = crispr-endpoint-20261009-0001; registration time: 2026-10-09T16:43:18+0800; checksum lists:
  OUTPUT_SHA256SUMS, SHA256SUMS
  crosslayer_matrix = crosslayer-matrix-20261009-0001; registration time: 2026-10-09T13:23:40+0800; checksum lists:
  SHA256SUMS, posthoc/SHA256SUMS_posthoc
  generator_curve = generator-curve-20261009-0001; registration time: 2026-10-09T17:04:52+0800; checksum lists:
  OUTPUT_SHA256SUMS, SHA256SUMS
  generator_fullpool = generator-fullpool-20261009-0001; registration time: 2026-10-09T17:50:56+0800; checksum lists:
  OUTPUT_SHA256SUMS, SHA256SUMS.v1, SHA256SUMS.v2, SHA256SUMS.v3
  null_baseline = no server run directory; registration time: none (registration date stated in PLAN.md); checksum
  lists: none
  probe2_context_abstain = probe2-context-abstain-20261009-0001; registration time: 2026-10-09T14:50:52+0800; checksum
  lists: OUTPUT_SHA256SUMS, SHA256SUMS
  prospective_lowdim = prospective-lowdim-20261022-0001; registration time: 2026-10-22T08:57:07+0800; checksum lists:
  ADDENDUM1_SHA256SUMS, OUTPUT_SHA256SUMS, SHA256SUMS
  protein_panel = protein-panel-20261009-0001; registration time: none (registration date stated in PLAN.md); checksum
  lists: OUTPUT_SHA256SUMS, SHA256SUMS
  pushline_checks = pushline-checks-20261009-0001; registration time: none (registration date stated in PLAN.md);
  checksum lists: OUTPUT_SHA256SUMS, SHA256SUMS
  rna_learning_curve = rna-learning-curve-20261009-0001; registration time: 2026-10-09T11:21:29+0800; checksum lists:
  SHA256SUMS
  rna_panel = rna-panel-20261009-0001; registration time: 2026-10-09T15:37:58+0800; checksum lists: OUTPUT_SHA256SUMS,
  SHA256SUMS
  settle_stageA = settle-stageA-20261011-0001; registration time: 2026-10-11T12:37:18+0800; checksum lists:
  server_record/OUTPUT_SHA256SUMS_server.txt, server_record/PLAN_SHA_AFTER_ADDENDUM2.txt, server_record/SHA256SUMS,
  server_record/SHA256SUMS_CRISPR, server_record/dryrun/SHA256_and_mtime_server.txt
  shared_crossdrug = shared-crossdrug-20261009-0001; registration time: none (registration date stated in PLAN.md);
  checksum lists: SHA256SUMS
  tissue_kernel = tissue-kernel-20261009-0001; registration time: none (registration date stated in PLAN.md); checksum
  lists: SHA256SUMS

- Data S2 holds every plan-registration and checksum file that exists in these server run directories
  (PLAN_REGISTERED_AT, SHA256SUMS*, OUTPUT_SHA256SUMS*, *_WRITTEN_AT), plus the reproduction-gate summaries and logs.
  protein_panel, acquisition_probe, pushline_checks, tissue_kernel and shared_crossdrug have no
  PLAN_REGISTERED_AT.txt: their plans state the registration date (2026-10-09) and their SHA256SUMS hold the plan hash
  (shared_crossdrug/SHA256SUMS also notes the time it was written, 2026-10-09T11:35:05+0800). crosslayer_matrix,
  acquisition_probe_rna, tissue_kernel and shared_crossdrug wrote no output checksum list; rna_learning_curve appended
  its output hashes to SHA256SUMS (see below).
- null_baseline: read-only rescoring of the saved predictions of extra-supervision-20261008-0001, with no server run
  directory. PLAN.md was registered in its text (2026-10-09, before any prediction value was read) and not hashed;
  results_new_cell.txt and results_tissue.txt are the printed results.
- rna_learning_curve/SHA256SUMS: the first 7 entries (PLAN.md and code) were verified at the start of the main run
  (run.log lines 1-7, OK); RESULT.md and the 4 output entries were appended after the run. code/fake_outputs.py writes
  random synthetic outputs, used only to test analyze.py before any outer score.
- crosslayer_matrix/run.log gives the main-run window (13:25:31-13:32:47); crispr_endpoint/CODE_FIXES_BEFORE_MAIN.txt
  records the code fixes made before the main run.
- probe2_context_abstain/OUTPUT_SHA256SUMS is the server file (62 lines); an earlier 59-line local copy is not
  included. No file appears twice in this archive; reproduction-gate summaries that are also result tables appear in
  Data S4-S10 as well (same bytes, same path in the run folder).
- Paths in the lists are relative to the server run directory, i.e. to the run folder here. Exceptions:
  acquisition_probe/OUTPUT_SHA256SUMS is relative to the run's output/ folder (check it from
  acquisition_probe/output/), and settle_stageA/server_record/dryrun/SHA256_and_mtime_server.txt to the server folder
  dev/ (the files are saved here under other names, see below).
- settle_stageA = follow-up N6 (run settle-stageA-20261011-0001). PLAN.md is the plan as registered; server_record/
  holds copies of the files at the top of the server run directory, among them PLAN.md after both addenda.
  server_record/OUTPUT_SHA256SUMS_server.txt and server_record/dryrun/SHA256_and_mtime_server.txt are SHA-256 listings
  computed on the server after the run and saved by the authors (no file of that name exists on the server); the
  dry-run summaries are the server files dev/<name>/summary.json saved as <name>_summary.json. make_table_s15.py,
  table_s15.md and table_s15_values.json were written after the run to build Table S15 from the 20 fold_result.json
  files. The frozen cross-layer and CRISPR-endpoint code that N6 imported (code/crosslayer.py,
  code/crispr_endpoint.py) has the same SHA-256 as in those runs' SHA256SUMS.
- development_protocols_20261008/: protocols of the three 2026-10-08 development runs whose folds, inner banks,
  measured teacher and protein sample-graph design the later runs reuse (recoverability =
  strong-teacher-recoverability-20261008-0001, privileged_geometry = privileged-geometry-20261008-0001,
  extra_supervision = extra-supervision-20261008-0001). These runs wrote no checksum list or registration-time file.
  handoff/ is the run's link to its planning folder. recoverability/PROTOCOL.md (run directory, written before the
  run) and recoverability/handoff/PROTOCOL.md (the same protocol plus the mid-run technical revision v2 for
  held-out-tissue teacher folds with fewer than three training tissues) differ only by that section;
  privileged_geometry/EXTENSION.md records the later extension of the mu grid to 100 and 1000.

Checksum verification (each list checked from its run folder; counts of CHECKSUM_INDEX.tsv): OK 141, FAILED 5,
ELSEWHERE 47, NOT_INCLUDED 412. The 5 FAILED entries are plan versions other than the PLAN.md at the listed path
(generator_fullpool/SHA256SUMS.v1 line 1; generator_fullpool/SHA256SUMS.v2 line 1; prospective_lowdim/SHA256SUMS line
1; settle_stageA/server_record/PLAN_SHA_AFTER_ADDENDUM2.txt line 1; settle_stageA/server_record/SHA256SUMS_CRISPR line
5); each is reproduced as shown under Plan versions. NOT_INCLUDED entries are code files, .npz arrays, RESULT.md
files, logs and other run files that are not part of the Data S files.

Plan versions (SHA-256 prefix = the file or byte prefix that reproduces it, e.g. head -c 15135 generator_curve/PLAN.md
| shasum -a 256):
  7b796fbe... = first 15135 bytes of generator_curve/PLAN.md: registered plan (STAR Methods), before ADDENDUM-A
  b64cebf8... = full file generator_curve/PLAN.md: after ADDENDUM-A; the hash in SHA256SUMS
  c9234493... = first 7485 bytes of generator_fullpool/PLAN.md: SHA256SUMS.v1 (registered)
  78b08ed7... = first 8265 bytes of generator_fullpool/PLAN.md: SHA256SUMS.v2 (first pre-run correction)
  48b94bb1... = full file generator_fullpool/PLAN.md: SHA256SUMS.v3 (second pre-run correction)
  1a498cac... = full file settle_stageA/PLAN.md: server_record/SHA256SUMS (registered)
  1a498cac... = first 7812 bytes of settle_stageA/server_record/PLAN.md: the same registered plan
  b2a06e7b... = first 8574 bytes of settle_stageA/server_record/PLAN.md: server_record/SHA256SUMS_CRISPR (after the
  CRISPR-step addendum)
  cffc1590... = full file settle_stageA/server_record/PLAN.md: server_record/PLAN_SHA_AFTER_ADDENDUM2.txt (after both
  addenda)
  7a448be6... = first 32248 bytes of prospective_lowdim/PLAN.md: registered plan (SHA256SUMS); ADDENDUM 1 was appended
  after it
  9f535f71... = full file prospective_lowdim/PLAN.md: with ADDENDUM 1 (ADDENDUM1_SHA256SUMS)

SHA-256 of every file in this archive:
b00a3cfc8c3691adf3e56a36eeaff5c14e9ae28ebe3b2d55fee8ccee4068fce4  Data_S2/CHECKSUM_INDEX.tsv
7a2ab7ec9b8bb11bbdd1656a9757211a3e44758bf05590b43cc6f82bac4c1ef1  Data_S2/acquisition_probe/OUTPUT_SHA256SUMS
26974b9889e7c0a78d9ad877c26e342e2405224ce4845386ff8fd7bda298bb45  Data_S2/acquisition_probe/PLAN.md
974a04d734404e65a2e4274432762420119c7d5712cfc23bc5e8e8b1e46ea008  Data_S2/acquisition_probe/SHA256SUMS
c101451c80f07cc1589ed1c8d7d15e28e79acedd8cc41802b0538eedef10da56  Data_S2/acquisition_probe/output/analysis/summary.json
d4ddd5a1686edff2e86de0e694aa7be84e077d55ee46dc59f8f62526913dd834  Data_S2/acquisition_probe/output/new_cell_repro/summary.json
e677630b667591073ccc7c5845cbf64609cf948f3d584633b9f597513514a15c  Data_S2/acquisition_probe/output/tissue_repro/summary.json
003373ed5ad27162fa045453cf24fffd7644ea069efec7dd6f4cfd6d343b2820  Data_S2/acquisition_probe_rna/PLAN.md
efbea6c9e616df2c794c43ab9deb3b33f1f76df998d8e07d4f2bb60fd09d653b  Data_S2/acquisition_probe_rna/PLAN_REGISTERED_AT.txt
9274ccec564feed2959a296b36b87ee4d6870d8309a62e5c64196f8fd6f9ec8f  Data_S2/acquisition_probe_rna/SHA256SUMS
ed4f57bfbdcaa3bbd2202a520295d0a05e754d7f73fd9b29f0895fab71dc7157  Data_S2/acquisition_probe_rna/output/analysis/summary.json
d46d2085c00376ed38a19dd1f6cf8d15782f10e15679b17d5a1291e5372957b7  Data_S2/acquisition_probe_rna/output/new_cell_repro/summary.json
4de0e037dd33a9c8b541d777e755aee8ec6ee9da749a73f08862bae7fcc1ce69  Data_S2/acquisition_probe_rna/output/tissue_repro/summary.json
910a3e24178aae3c31bb8ad4074eef99b886cc132cb0f930ccad85e5b0fb979c  Data_S2/crispr_endpoint/CODE_FIXES_BEFORE_MAIN.txt
9a1112550e5635ad3fd9042cb7fb2e134ae57f88ac6e4811fee968941ff7e9a1  Data_S2/crispr_endpoint/OUTPUT_SHA256SUMS
41526cda93c468523afbe168c1a26f98d5f42fa259f0f3fc7a64b7fb2421fb67  Data_S2/crispr_endpoint/PLAN.md
5552518755bab8ea917a6f079d575eda92096615ad2d627566900740c0132e2d  Data_S2/crispr_endpoint/PLAN_REGISTERED_AT.txt
9866ae954490be286551e137c42647a4fc7d8b04ac0b10ed7c9bd9218d158892  Data_S2/crispr_endpoint/SHA256SUMS
4d4924eafff1e046b509fea88cc39278af1170015503525a9e8cc87d8179aadf  Data_S2/crispr_endpoint/output/summary.json
f27acb323cb9f046d547a91ec651c60a6858485b54d2061bd25141ef63039839  Data_S2/crosslayer_matrix/PLAN.md
c1d4daa3f2117a268cc093b6cb38777315561af3ad7c549fdc62b45a28ad9121  Data_S2/crosslayer_matrix/PLAN_REGISTERED_AT.txt
8499e805fcfee5e052150686563c0c5fb56a01bdd536a42d36962231dbdf39d5  Data_S2/crosslayer_matrix/SHA256SUMS
578e603480d55c5dae3cf4ec66ee4193b47052c5da0796c9b37f262e25d7bf2f  Data_S2/crosslayer_matrix/SHA256SUMS_WRITTEN_AT.txt
c8a101dc8508ccc10aeeef1e74c478e1c9007f89a6438579fd81aa4e085bcb8c  Data_S2/crosslayer_matrix/posthoc/SHA256SUMS_posthoc
5e721f74bcc4172d28c2a66e463abc1a8de29de89a8d1478cf62888b6fb8837e  Data_S2/crosslayer_matrix/posthoc/posthoc_saved_compare.json
ec298d2b89487bf68ddc01d27e961807ebdc3082c7756aa93fe06eab9cc34709  Data_S2/crosslayer_matrix/run.log
7a820ae6d954d4d054246771b890cc00f6c9f47ce0c6e20c5499cbe2e0bc1b54  Data_S2/development_protocols_20261008/extra_supervision/PROTOCOL.md
325984ea12589f8e2698bea7fbfbb2b73d2dd1c91edd6d6dd4e016b5f4bcc626  Data_S2/development_protocols_20261008/extra_supervision/README.md
906dbd4b9d85d0d003e02aa112c03504605f0901040ea9f17615f2708ed8ee02  Data_S2/development_protocols_20261008/privileged_geometry/EXTENSION.md
f2a4ee52ff55beb5da3200b10e9d86420c17ebabad53d07f95686a6a7631d47d  Data_S2/development_protocols_20261008/privileged_geometry/PROTOCOL.md
a0042d4939b9ba12725c58fb136b4e88ffa6f0f5b950b27f1f293161125eda82  Data_S2/development_protocols_20261008/privileged_geometry/handoff/README.md
e6fcae16ce41605645175d199409407d28db5f0af61a3f5b3d55a6f6f47f1103  Data_S2/development_protocols_20261008/recoverability/PROTOCOL.md
1e4515e03f139be9538ded4c7f6a736734f7a265bc137c95a498f6bc654e0513  Data_S2/development_protocols_20261008/recoverability/handoff/PROTOCOL.md
7e253f46f8c3c0f64d82e88f1df9f0de21ffb02195610ff71a9451bdb60d58c4  Data_S2/development_protocols_20261008/recoverability/handoff/README.md
d45d7fcc3a9f8b6ab4e382f0e17bac5dec591267fbcf8ef338e15a858e61b886  Data_S2/generator_curve/OUTPUT_SHA256SUMS
b64cebf8a58da17a3f2426d9e321d0a27295107da660ca0ffaa00f994f0f374b  Data_S2/generator_curve/PLAN.md
6e87946ba4650915ce6a6ce5eb735ccdda24b9790c089f970a1cba35d3314fd6  Data_S2/generator_curve/PLAN_REGISTERED_AT.txt
884ca29f4cbed27e6c30fb6996a8a5ea2524b4160e7d9dc89706d7772ffeaf7b  Data_S2/generator_curve/SHA256SUMS
04fb756006f6b8083c8696a41e7563f7fb3bb40f8f5c35ee24bcacb3979a3acd  Data_S2/generator_curve/SHA256SUMS_WRITTEN_AT.txt
f68abc818c17b87686fa7597d783d5ff842757164b36448e1a134929310a320e  Data_S2/generator_curve/output/summary.json
11bb411da508fdac43323a9f25f39d77b6a490699160218435402d7449f355cb  Data_S2/generator_fullpool/OUTPUT_SHA256SUMS
97e4e8c528683700a13e28e93287fc89750c3913491c760346d98facab565b1d  Data_S2/generator_fullpool/OUTPUT_SHA256SUMS_WRITTEN_AT.txt
48b94bb102bf52d4519e04be47d5ab1ef6eb64148a97b6f070ea779c1c4d9b8b  Data_S2/generator_fullpool/PLAN.md
e29d5397aaa022e6457efe3c19ae5b29db02314b1110d2a69628320b9fa6fafc  Data_S2/generator_fullpool/PLAN_REGISTERED_AT.txt
5283af62100ae9120e71841eee260d12b2d9a2bb5e8d643407171a1808aa14dd  Data_S2/generator_fullpool/SHA256SUMS.v1
6e457349ad896531b5349f80a46e79cccd71536b5580320980aca3457e5802c3  Data_S2/generator_fullpool/SHA256SUMS.v2
a8a405d71f43f38150eed4d96d147c0c29a6a28c5f1f92d0de34e966f56a3416  Data_S2/generator_fullpool/SHA256SUMS.v3
e29d5397aaa022e6457efe3c19ae5b29db02314b1110d2a69628320b9fa6fafc  Data_S2/generator_fullpool/SHA256SUMS_WRITTEN_AT.v1.txt
3e0e2afcfc792e048cff6ea67da50b574e0ddf07322f3728b265c7cb142414c5  Data_S2/generator_fullpool/SHA256SUMS_WRITTEN_AT.v2.txt
c0e96b6adb2a831fc1bdd64d042a6d799a73a28161a24c57eb878c01fd38e136  Data_S2/generator_fullpool/SHA256SUMS_WRITTEN_AT.v3.txt
e8ecc9670090ff865fc460ae072b8d592b1b8d420ade587c5348953137e3674d  Data_S2/null_baseline/PLAN.md
ec79a4b4cc58f36bace06fb5efc2ff3233ca6589383f2cd8322d30f82f073046  Data_S2/null_baseline/results_new_cell.txt
871dc01888b66cffa0ffb8147caddb5ac93c002504e50aad5ad1bb8d085fbc4d  Data_S2/null_baseline/results_tissue.txt
e7c7ebac4a75db2184a4b2f7b2334899741e3727970ab7bb135bc6ef898a8268  Data_S2/probe2_context_abstain/OUTPUT_SHA256SUMS
31a65edda245f42c7e34c49d6117c44501568714467f39460b7e0b254690ed92  Data_S2/probe2_context_abstain/PLAN.md
b6dbb417205587627c63b3790384ddafa616778cbe54717cff80f831c0daaf92  Data_S2/probe2_context_abstain/PLAN_REGISTERED_AT.txt
17a6c9210d4108e4afba92f32e7cf08500959468f5e0c8c345c4f6eed79b959b  Data_S2/probe2_context_abstain/SHA256SUMS
321e284563003856e5daecb9cd004bac7c1b24da043ac7f1b8ace35dc0b36c32  Data_S2/probe2_context_abstain/SHA256SUMS_WRITTEN_AT.txt
1b125418ecad87aa9788f16ea1671324c2049e9f91481416545f8071dcaaffd2  Data_S2/probe2_context_abstain/output/A/new_cell/fold-0_repro.json
62742ed0bd47819226f1117c2685ce05fbe8b6f7b99f4fbaf0da9cf8ca590dd3  Data_S2/probe2_context_abstain/output/A/new_cell/fold-1_repro.json
edd275ff94583e2c76acda27ff3fd9f1b52661ad732d095bdad1e66e0a743d27  Data_S2/probe2_context_abstain/output/A/new_cell/fold-2_repro.json
c6ed69724b0018acf45dba969c28687a75f3d78a1cb5f747adc25253486716dc  Data_S2/probe2_context_abstain/output/A/new_cell/fold-3_repro.json
c769b6a873bd0aec807623b86d738405e74902ebb825b798842278dbe7074040  Data_S2/probe2_context_abstain/output/A/new_cell/fold-4_repro.json
3a7adfdc55773ae61bbb72ad5270dd14989c735afcd9a7f557702fcc90007705  Data_S2/probe2_context_abstain/output/A/tissue/fold-0_repro.json
b240ebdc5b19eed6ef82ad22a02966d512846a82d4c5cdb13d958e20e6008ea7  Data_S2/probe2_context_abstain/output/A/tissue/fold-1_repro.json
0affff84d0d97d5757f2915e2ab262f5fcae22bca3ea98e1a132a355df987808  Data_S2/probe2_context_abstain/output/A/tissue/fold-2_repro.json
9433282aad1bb98746d82a075c39e6624a6c499dde2fab2da89311509bc68c64  Data_S2/probe2_context_abstain/output/A/tissue/fold-3_repro.json
c064fd3559146a877f37520072b60584deaf61092e792d651e28766d5f8d3949  Data_S2/probe2_context_abstain/output/A/tissue/fold-4_repro.json
4b09a68bd33ac292f64edabfa0f6d5518ba5bbf66ca3f8bcbbc0447f08812c22  Data_S2/probe2_context_abstain/output/summary.json
ce553175c05c1f6eda32766c9739807d2bce9f34797353a5bc3d9d7d9b2761f8  Data_S2/prospective_lowdim/ADDENDUM1_REGISTERED_AT.txt
bd0170c8a9126ec797f6dac17f5b4131f0226e762ef3b58dd360e1f91a7b7aa6  Data_S2/prospective_lowdim/ADDENDUM1_SHA256SUMS
b7adb32baf52c90be9311bf390ef58267585d4ca3e2faa9129b42422dcc1c7f1  Data_S2/prospective_lowdim/INPUTS.env
e5fb063ccfcbd44db9860de607d8c9cdcb5b21eb53bedd4b816eb9723604ef3e  Data_S2/prospective_lowdim/OUTPUT_SHA256SUMS
9f535f719d5cdb854a1ce63cd76ce250f5dfee9118fdeec20c7f5fe00b2b8bfc  Data_S2/prospective_lowdim/PLAN.md
879ba7afdeb8b4a84ffb21c6aea77006cd38e8d3f5b1ce4a097d277ebe4b433a  Data_S2/prospective_lowdim/PLAN_REGISTERED_AT.txt
e265010bfb0d5709c8d4bf9c6380b0c3d53d3372024bf28ca42e2cdf4d25bca5  Data_S2/prospective_lowdim/SHA256SUMS
17b77c79c0d5beee02eeb7943fdbd4bdc5b6e8de5894613a85491d50223b60d4  Data_S2/prospective_lowdim/analysis/RESULT_AUTO.md
224a99eaec825d4e3e0ad63b3f15243fe619c0c0d33de6dde009e3f727b075de  Data_S2/prospective_lowdim/analysis/analysis.json
c0606bc5d88a015122987255eec8a79c80b2351de5f8262cc3c86a2c7cf8d172  Data_S2/prospective_lowdim/analysis/cells_A.csv
c208dc71d33f732905e12d75ea9e3a8187e68c33534d3637a45e64f5d51e8f29  Data_S2/prospective_lowdim/analysis/figure_2H_prospective.csv
69a0c398e3b8aa335c9be01ea3506d293051330f5c4e8869abc01bd2335b1b33  Data_S2/prospective_lowdim/analysis/panel_comparisons.csv
13b69c39b83ed92a8cc1833de0a75534e71fb350f667ea7aad9bce260d3d0d43  Data_S2/prospective_lowdim/data_gdsc1/data_gate.json
03585108d8340eeeda5f5683009c1a853aee0d9995d251effa8cd2eb4ae58246  Data_S2/prospective_lowdim/dryrun/crispr-new_cell/summary.json
828e42009033f65f384f23657c379b12c5fe28f55e7c4ba06f79e9ac824e0469  Data_S2/prospective_lowdim/dryrun/crispr-tissue/summary.json
c18eb573d773895cce28f886dd330333bc612bc083124ad446971698493b2f05  Data_S2/prospective_lowdim/dryrun/drug-new_cell/summary.json
6ca306b18bdf441b2846078df946b5e41453fc47aa1312d312b6d396e740af5b  Data_S2/prospective_lowdim/dryrun/drug-tissue/summary.json
64120c191fd48e9ec47f70ff01b27f88b8d33f2f10a5d96de1a4f1c3806d31e8  Data_S2/prospective_lowdim/dryrun/gdsc1-new_cell/summary.json
aa0b9964f1e3b68a214fd06a9f48c5aae915973ea7b0a2c2d2cea0a8d713ed0d  Data_S2/prospective_lowdim/dryrun/gdsc1-tissue/summary.json
6f40c80d2050db7bb50c789da679bc6039763a65ec69d4e0ffe3c9058331d2f7  Data_S2/prospective_lowdim/logs/analyze.log
32a2a537ec202a520e2282db270386ba870e50f47ca21234d1a6b83dc9b9f651  Data_S2/prospective_lowdim/logs/data_gate.log
86d5287c7a031509c0b4515aabd8d7cdffc88ab310a746910a9c54b831814fe6  Data_S2/prospective_lowdim/logs/env.txt
55a8d5d568b316c3af60f3b3e80a395f128836e6dd3314c1cf57c0977c382220  Data_S2/prospective_lowdim/logs/failed_score_attempt1/score-drug-new_cell-fold-0.log
c3f8f09e7679748f64f1731fe8e326bfe1a92f9aeed53b63134f24b40152bc16  Data_S2/prospective_lowdim/output/crispr/new_cell/fold-0/fold_result.json
c5228ef7b62ca134772a7076cd78a2fb96e61964eb327f49da35dcc6b97ab92b  Data_S2/prospective_lowdim/output/crispr/new_cell/fold-0/gate.json
1605f31e62e0ff9f982e6da87c95af587cb149a036c0d7ecc258888569011148  Data_S2/prospective_lowdim/output/crispr/new_cell/fold-1/fold_result.json
4737de64d7f2ab722c6c0e53ebdbd53549932e8ce2099c69a5dd496a49139410  Data_S2/prospective_lowdim/output/crispr/new_cell/fold-1/gate.json
d0e5b42555a00d2183c0fd089a83a8529f6e949170690866f039bd633c0960f3  Data_S2/prospective_lowdim/output/crispr/new_cell/fold-2/fold_result.json
a0a011b0e977e2808804113f775c02bf0219eb14a7161b4ccbdea11b32a530d2  Data_S2/prospective_lowdim/output/crispr/new_cell/fold-2/gate.json
cd929120fcc1446030bfd62a461c917c7ac99f50ede28f33888da0ab5935f0d9  Data_S2/prospective_lowdim/output/crispr/new_cell/fold-3/fold_result.json
beb39bf64e052c7776edd602fd352c4cb6bea1ddf09dbff52c023db5111ea968  Data_S2/prospective_lowdim/output/crispr/new_cell/fold-3/gate.json
2ce8a90248b7e6744dfe8b024a13468dd704fb1d5814ee7f52523f366cbbf00e  Data_S2/prospective_lowdim/output/crispr/new_cell/fold-4/fold_result.json
9ff22405d9534afbac803f56622540ce952272bc95513015e8063c4471f6eacf  Data_S2/prospective_lowdim/output/crispr/new_cell/fold-4/gate.json
ef67a0d54f7ccda7a98051beee20ae6a05934ac5ed9aca0008d7de092519ffe8  Data_S2/prospective_lowdim/output/crispr/tissue/fold-0/fold_result.json
2f8c5b423b9fcf5fb1445eee4f4c6ea11c213cf2a83599d0c44f5c3ca3653564  Data_S2/prospective_lowdim/output/crispr/tissue/fold-0/gate.json
42ac651d04a2801db560f074f76e991384f88ef619f24fd14c4b665f9f4906d7  Data_S2/prospective_lowdim/output/crispr/tissue/fold-1/fold_result.json
a23533d81ce9218ddf2e949e859463d19c0165c267c8ce2efe61d7cd7df6e07d  Data_S2/prospective_lowdim/output/crispr/tissue/fold-1/gate.json
59d5150ad156d845dbb072a0015733f5739c71a991d60a25a4b0d810e42cd798  Data_S2/prospective_lowdim/output/crispr/tissue/fold-2/fold_result.json
2f2f2b9da02b66f368ca575ae8a19a84c7c29eee6205e30f03688010634d31de  Data_S2/prospective_lowdim/output/crispr/tissue/fold-2/gate.json
4f32219dcb1b12913470ac92796e699096cb2f45eb57bd582e89d1f5050c11a8  Data_S2/prospective_lowdim/output/crispr/tissue/fold-3/fold_result.json
cfc598cf698076c10d7a42b968634d7a89929a77a3c97c9a412d334b3900f93c  Data_S2/prospective_lowdim/output/crispr/tissue/fold-3/gate.json
33e1a633be58fa7878fda99324587b51f39783a1ab2569c57928ef44c19d6653  Data_S2/prospective_lowdim/output/crispr/tissue/fold-4/fold_result.json
f08f1c58b60c3d5bf7671d37dcaa2d7098d70420e27dbbfe809bc615e85e5d3c  Data_S2/prospective_lowdim/output/crispr/tissue/fold-4/gate.json
1300fe06c112fc13d9f2ef0606a1d47b4af8d114af9a0583b556436d3f80dc01  Data_S2/prospective_lowdim/output/drug/new_cell/fold-0/fold_result.json
91215e3241ed356731590c823fda1c6625d42f578f1cac030922dae8cab03455  Data_S2/prospective_lowdim/output/drug/new_cell/fold-0/gate.json
a0871dec755e02764c71f7b5e1512049b755fc9fd79692f21eacd6c40c10d6ef  Data_S2/prospective_lowdim/output/drug/new_cell/fold-1/fold_result.json
fa0324e23f4aa1d954ae055169ab663abb29f48c47071b2a2ba5f16330b35fd2  Data_S2/prospective_lowdim/output/drug/new_cell/fold-1/gate.json
d37022452c78cd2a436d75dcc1c413d446e8c03e76c31caa4cfe83c9621fddc2  Data_S2/prospective_lowdim/output/drug/new_cell/fold-2/fold_result.json
4045bde3d64151e308b4c03ec6621475554bfafb23ac9d05f9f6081ace56080c  Data_S2/prospective_lowdim/output/drug/new_cell/fold-2/gate.json
43e39c6185d165aeb7306c31119aa41c24e025117fad2735abc54d544366177e  Data_S2/prospective_lowdim/output/drug/new_cell/fold-3/fold_result.json
64de06640409e6653d7e8f8f44bfc2f2c040f9011624838b8967e5b8bdfe6ffa  Data_S2/prospective_lowdim/output/drug/new_cell/fold-3/gate.json
a1a9c638e2dab373aa13a36e1243acf933efb9c009b37ff4d46f365c540a126e  Data_S2/prospective_lowdim/output/drug/new_cell/fold-4/fold_result.json
b030a1c7081f8f5a286a913728fe966603c607551e5de7dc98645449c6b38759  Data_S2/prospective_lowdim/output/drug/new_cell/fold-4/gate.json
cffeacf3597310645f56fd52863aa4a20f1069942e78b7530a3f0fdde85a7fb8  Data_S2/prospective_lowdim/output/drug/tissue/fold-0/fold_result.json
88e6be258b340b3faa843bc50be9f943b10c48c913aad552b1877ea3a1e68330  Data_S2/prospective_lowdim/output/drug/tissue/fold-0/gate.json
b2e57ddeaae286ae8b45c10b88f7d953540b4a20c0bbedf74fdcb970de6891be  Data_S2/prospective_lowdim/output/drug/tissue/fold-1/fold_result.json
29a3ee9703500744ea24a9611fd7ad9cd5ef2c036bc5e2c2440d32632f30b394  Data_S2/prospective_lowdim/output/drug/tissue/fold-1/gate.json
78185b3c0d47ba6a4fb0eb992c1b8f61c718561cfbaefcc3be76039b94ec9889  Data_S2/prospective_lowdim/output/drug/tissue/fold-2/fold_result.json
e5cd4466c4aefa4e057e3e59d0b07962d2643dab7b872ed75950b775eb39a1b7  Data_S2/prospective_lowdim/output/drug/tissue/fold-2/gate.json
7a9985a83def17026e7825126edaa6a002800b688f236af5d7405b4bdba90904  Data_S2/prospective_lowdim/output/drug/tissue/fold-3/fold_result.json
f5522d3cd69f6a3b664d10cc872c2b49cf75b1ec1625f05bbe8131fe6798b6b2  Data_S2/prospective_lowdim/output/drug/tissue/fold-3/gate.json
86916e1eca38b277633b1243bfdb63f2a1878063cfe6da1a1116e2eb51b3d884  Data_S2/prospective_lowdim/output/drug/tissue/fold-4/fold_result.json
66a989a92269fc2f50b6016164ee3597a01fd6288e3077db0f0c74c6102f081e  Data_S2/prospective_lowdim/output/drug/tissue/fold-4/gate.json
ba5666a81d5c87bb89c118ead31cecda091854b89b3280736c08b4b3cee71fe4  Data_S2/prospective_lowdim/output/gdsc1/new_cell/fold-0/fold_result.json
5c8c15901d86638f72f0bdf8825fadd990e5553350bcfd918137efd1668e1db5  Data_S2/prospective_lowdim/output/gdsc1/new_cell/fold-0/gate.json
9208cc5f07c505331d73e1b99cd6536a2c7eff71d962d2179ef15002f6355de6  Data_S2/prospective_lowdim/output/gdsc1/new_cell/fold-1/fold_result.json
4696b1048fbec58e19834e98d7157a10e6e97af9ba0766be0068f6818ab0c9db  Data_S2/prospective_lowdim/output/gdsc1/new_cell/fold-1/gate.json
2197f936eb6bc8356cb18f5a3d0292e639c79fdf2baf4d9face4bb46b26ba11a  Data_S2/prospective_lowdim/output/gdsc1/new_cell/fold-2/fold_result.json
009ae13d2a7b9a2a9905b99e1f9af90b5441128c18b692709d769d7c88ef620e  Data_S2/prospective_lowdim/output/gdsc1/new_cell/fold-2/gate.json
395c7dc7e778ffb8bfbd0b6a207dccd0eafed018c0f6e22f33a3dc9e2e23b612  Data_S2/prospective_lowdim/output/gdsc1/new_cell/fold-3/fold_result.json
0acf842456daecd742a252326d59f1d1341ce3223634cf42ec7d7e896368f6b9  Data_S2/prospective_lowdim/output/gdsc1/new_cell/fold-3/gate.json
3b93510405cfddfd3af6c234874ac0c885a6ea55cd6c91dfa1d8f3e228d7d60a  Data_S2/prospective_lowdim/output/gdsc1/new_cell/fold-4/fold_result.json
624e1f3a56ac4992d1b290a65f3633cbc9842805a2a05609111c0ed5a00c181d  Data_S2/prospective_lowdim/output/gdsc1/new_cell/fold-4/gate.json
7663be76f809526d392ad8188594d4a727a7f7a3aa40d1521aa26fb7bab41b0f  Data_S2/prospective_lowdim/output/gdsc1/tissue/fold-0/fold_result.json
f1f2e55f090b12fc172637f5872a6d45964d7b5264d56721f49100674d272564  Data_S2/prospective_lowdim/output/gdsc1/tissue/fold-0/gate.json
c81354271f2e02d936b6779e677ed19caa163c78de2cc849a358626b9bc69af2  Data_S2/prospective_lowdim/output/gdsc1/tissue/fold-1/fold_result.json
87ead89ffe9fb4f3096d2cc53d5a1c9a5361ef582263ff39e3e4ba5fe2dde7c0  Data_S2/prospective_lowdim/output/gdsc1/tissue/fold-1/gate.json
23bfbdac67c5c4ce78d473d3292517003d2c5348b09fd236750c6f74615e454b  Data_S2/prospective_lowdim/output/gdsc1/tissue/fold-2/fold_result.json
afde05da9c45fba3e6acca40df6a87e5e0bfa8bd0090342ccc48d444aa41827e  Data_S2/prospective_lowdim/output/gdsc1/tissue/fold-2/gate.json
b85d204bc7fbd7f96bf85292a747c4fa20636299c2d161df8f3b5db59e3af801  Data_S2/prospective_lowdim/output/gdsc1/tissue/fold-3/fold_result.json
9b474ef780338a605022de6be2fb8dfd0cab602771b49aa24d9b85802f3e24f6  Data_S2/prospective_lowdim/output/gdsc1/tissue/fold-3/gate.json
406fe797dd5a00dd5a3962b0d668bd47a767042edaf8bcbd7342c0bd59db0ed7  Data_S2/prospective_lowdim/output/gdsc1/tissue/fold-4/fold_result.json
6f8f8576b54ae74f558741f0de52081217a58ebdb995c9297353c0d2f893a8bc  Data_S2/prospective_lowdim/output/gdsc1/tissue/fold-4/gate.json
f84b83cfa5868626fb919442da1b78515a764a3f2558af20186a00b9bcf3236f  Data_S2/prospective_lowdim/run.log
8efee96c7d359de91e1b1506c82951f8563018c1bf60f075494a7127fa797950  Data_S2/prospective_lowdim/run_resume.log
90ef65a54e0671660be444028bca5d9025df88565b2e683d380148fc6489588f  Data_S2/protein_panel/OUTPUT_SHA256SUMS
f95fa994d7205bc01a4919c6836d521509406c4f2204d33848ba55630c7e2089  Data_S2/protein_panel/PLAN.md
2dd85aa18cdc6b330940deda42b566dcdb0b430073cec1cf5a697e9df19370b4  Data_S2/protein_panel/SHA256SUMS
4cc27c8277c8bafc7f5de0d1db80ee7cd031ee8e94195bfe93fbe85393be7ddc  Data_S2/protein_panel/output/analysis.json
d9c6f2eca048686d060088a04b40586e42b78c46382db98139ad8ee60f1e1ebd  Data_S2/pushline_checks/OUTPUT_SHA256SUMS
f4b8f609a0d3255d2cc6e58b46ad0f2d3c9cc5233ea8045a16dc5914c0c25da2  Data_S2/pushline_checks/PLAN.md
177212f76cb620b672166500e6526f8c6026a18de48aa8e04c0c81d77d82d213  Data_S2/pushline_checks/SHA256SUMS
230c9bb47a61a503fbbc06b556fde025532ec48211ced3a9248b2a48f642dca4  Data_S2/pushline_checks/output/summary.json
97e8e41c1f3c72913932af21cead809626e5c006c865bf3ab7416e75b2b45474  Data_S2/rna_learning_curve/PLAN.md
3399d8de4ea412309f4c7d030ecbc2d87dbfd45b41b62d4d474cc158029a44a6  Data_S2/rna_learning_curve/PLAN_REGISTERED_AT.txt
364e2a64adf0b3f9731eb738c88b2f90008e9205f14d4f47c5a45ea0533113e7  Data_S2/rna_learning_curve/SHA256SUMS
63e2a164b2e9cd983aabc5e5337ab6ea6946ec8407fb4817320442c4dc2cb199  Data_S2/rna_learning_curve/output/new_cell/summary.json
7885c593a0008646f50e850c7e178a043bc64337b18b4c949a129cc1327b9c97  Data_S2/rna_learning_curve/output/tissue/summary.json
0450bf3875a0f8050e3b277467aeca156245d39cd1996986e7a68f60843778b8  Data_S2/rna_learning_curve/run.log
3fa9e62f76782af0a911c347153ed9b19304305797246cdb28787e38f4594648  Data_S2/rna_panel/OUTPUT_SHA256SUMS
e9cf391e957b3d2bbf002c75f18e25183cc93ea5a2772166fa55faede51fe31c  Data_S2/rna_panel/PLAN.md
b9d8cc7f466eef007381782621d1225ea6600c739780db01984758f13a89f46d  Data_S2/rna_panel/PLAN_REGISTERED_AT.txt
4a66477302af8f0ddd73df6ec16ae552483f1a6a44fb6944eb3d9eed06eba05e  Data_S2/rna_panel/SHA256SUMS
682b3d04c1242e6bf7c91316f8a722c07bf02b17699ad1b6797251dd058557a9  Data_S2/rna_panel/SHA256SUMS_WRITTEN_AT.txt
4e08c6f7e1d3a4ad2dda599c1f692d9e9fbdfb99d670efade775fe647c261b98  Data_S2/rna_panel/output/summary.json
1a498cac1f87b9dea554bea7d61fd0b082aee8dc0f8fc4cf06236d2a41526a03  Data_S2/settle_stageA/PLAN.md
d609e2306ee38d284937a7a653607f50663b08f08665a201771954822ef4a16a  Data_S2/settle_stageA/code/analyze.py
5c5cddbfc8d2663055cce3940ac1b0bcb010e914dcb85d0f422de7d900c24043  Data_S2/settle_stageA/code/analyze_crispr.py
5b5cb08eb4500425f017abf83c1c4e5933d14744fc841fc532f148744e0cdcfb  Data_S2/settle_stageA/code/run.sh
5ebdf3525f8ae08d218085699f57f8c3c2f96843758372e6885b3108284a1fbd  Data_S2/settle_stageA/code/run_crispr.sh
f94ab897588ab58cbec2adf4197553ae9b8eb730f8164c4c46563e165cb8dfc6  Data_S2/settle_stageA/code/stageA.py
9a74d2a4288c8f79b2861e69eeba08f82b7a893d5b00f240f262ed4e3d21f397  Data_S2/settle_stageA/code/stageA_crispr.py
0faa58199c5bc68145ab57bdde8ef9dca2b80576c9f823d72807c97e662be8e7  Data_S2/settle_stageA/make_table_s15.py
0451820da39b8030f298d51681cb3c08814d2734916b6488e907f7b06a2266e3  Data_S2/settle_stageA/output/RESULT_AUTO.md
c4b1fd229222135a3840ee46f4e77260f91ef00b52e66a4b7205a0fd0ffaa224  Data_S2/settle_stageA/output/analysis.json
c2c433d98e72fb4331dfa8ab9abd2558492c357e85327d42971331c24b36305e  Data_S2/settle_stageA/output/new_cell/fold-0/fold_result.json
e45c6cd6f12141e6a66a862b5796cda94fc2c1d7a67647071bb23e8d90008c8d  Data_S2/settle_stageA/output/new_cell/fold-1/fold_result.json
45f0a18fc1871a9492139be65c1d2a647499962a8ef22141db4604397b71a8b3  Data_S2/settle_stageA/output/new_cell/fold-2/fold_result.json
703d7420901852d0e33b4f9590dcc771fd0ae7883a1d25260107942164457a7a  Data_S2/settle_stageA/output/new_cell/fold-3/fold_result.json
59feb879d44e4ca60775f930f8df1666810f4405b14a4e82e69a717ffbb8dc64  Data_S2/settle_stageA/output/new_cell/fold-4/fold_result.json
cc520453bfbd9cee7f1e4cae9d7a9c1ed367fa5a42020c86d0895a114ba2090b  Data_S2/settle_stageA/output/tissue/fold-0/fold_result.json
b7d4296cd7e800ad7da35b706f5ab28aa79d62999f13caf85f4c13c8d24703f0  Data_S2/settle_stageA/output/tissue/fold-1/fold_result.json
54facdc77174fd832ea449271c4ea7bc8298a879993c5fe116f1042a198a4efd  Data_S2/settle_stageA/output/tissue/fold-2/fold_result.json
2f616ca46dd679065916484c3658b71ad4666c311c635b2e88c8c0806b96d72b  Data_S2/settle_stageA/output/tissue/fold-3/fold_result.json
3a78174dbf6fdd59cfde5ff1471a628d8f0a6d4c893d307480f45f583dd4187b  Data_S2/settle_stageA/output/tissue/fold-4/fold_result.json
3b6b641cae81db2742fd7bd3de5e90ec04fcc1eda94c2349ac8f4f802e373556  Data_S2/settle_stageA/output_crispr/RESULT_AUTO_CRISPR.md
22ea994c702f4987dcf47128f24f95a50e61dc6e4ef03ece4963a9119285362c  Data_S2/settle_stageA/output_crispr/analysis_crispr.json
15407fe1482e076066d44fa360aa69620bad1d8231b43072422da7a74360cba2  Data_S2/settle_stageA/output_crispr/new_cell/fold-0/fold_result.json
8e1a95b7e6c549f7d05b30fa09dd1961ee2350edf4a6368cee9226c184ad7111  Data_S2/settle_stageA/output_crispr/new_cell/fold-1/fold_result.json
5e70d8f2440ffd7a5355ab2c0b3f019ac4c74a3551e6f3bd9c94391d75d56006  Data_S2/settle_stageA/output_crispr/new_cell/fold-2/fold_result.json
757c2283e894d5fbee695cdb82ef558789b5083a4a709a59629c86a49aa082c0  Data_S2/settle_stageA/output_crispr/new_cell/fold-3/fold_result.json
828c97a5ea8262af33f2b513335883e5e82873cf92de0134901f1b93f5f27f7b  Data_S2/settle_stageA/output_crispr/new_cell/fold-4/fold_result.json
fe9816b22b3e44ce0048aeb7ff765162e97861b2ed478703f7848ad105100c29  Data_S2/settle_stageA/output_crispr/tissue/fold-0/fold_result.json
356bccc7578ade15df61b0908445bcb5883f5a2f6ca693aa4d524c8e31d80593  Data_S2/settle_stageA/output_crispr/tissue/fold-1/fold_result.json
4b8243799752886652cee9479715e43a9ad6ce10c6753148190bf05e9a7d5ba4  Data_S2/settle_stageA/output_crispr/tissue/fold-2/fold_result.json
ae89c2595dc1c213ff3d74892fbfff209f4b72bb8b8193d6232a6918885e07d8  Data_S2/settle_stageA/output_crispr/tissue/fold-3/fold_result.json
b626bd63056da004416e5b5fae8bba53e1f67b90797d300a122f95a6a9b32e8e  Data_S2/settle_stageA/output_crispr/tissue/fold-4/fold_result.json
410cb01ddeae41dcce2fbb44f7566ed9c889712a9a9dc3c861d8ef89efc14cc2  Data_S2/settle_stageA/server_record/OUTPUT_SHA256SUMS_server.txt
cffc1590bab35b0f3dfc4e87e995bf1680aa9f138ca7152ff8e8f10266a078ab  Data_S2/settle_stageA/server_record/PLAN.md
186ad40d4cb8ebb8f06c12debd22aedc09796e0cfb6067fb3deff1c7057028ba  Data_S2/settle_stageA/server_record/PLAN_REGISTERED_AT.txt
66379dccc4afd3771092466c5560e01d35272dbc802acaf8dff627340b0b2be5  Data_S2/settle_stageA/server_record/PLAN_SHA_AFTER_ADDENDUM2.txt
2623ea05ca34ad4462b25d37a6563b9f424030c08cf1104ae3144705b0403f40  Data_S2/settle_stageA/server_record/SHA256SUMS
2a588cf01eb6028daaa4a6389dbd3213f1e121031d79c10524961ffb5009207c  Data_S2/settle_stageA/server_record/SHA256SUMS_CRISPR
186ad40d4cb8ebb8f06c12debd22aedc09796e0cfb6067fb3deff1c7057028ba  Data_S2/settle_stageA/server_record/SHA256SUMS_WRITTEN_AT.txt
b701bbc2274ca1ae73b9aecc658f8903f4d3c77ce5ec0535a0b3fff62a55f56c  Data_S2/settle_stageA/server_record/dryrun/SHA256_and_mtime_server.txt
05e2f1b3c6e760f64ef52c5e4313727e1e07501ef60e94192ecb638d0dfcdb27  Data_S2/settle_stageA/server_record/dryrun/crispr_dryrun_new_cell_summary.json
5592b8edca10c6a1baac5920fd0210cfba95d64e7d3d11925960512665f24412  Data_S2/settle_stageA/server_record/dryrun/dryrun_new_cell_summary.json
29f27f61dea8624391f2a8f7fc4d323f893eedaa6e9326d929405ec0a10ce50c  Data_S2/settle_stageA/server_record/dryrun/dryrun_tissue_summary.json
54b7357c4823a076f759a0752017d2859715ec2f66c6f8f8f0dfbf1ea7678d4c  Data_S2/settle_stageA/server_record/run.log
47e8cb8be1f739c5dba9c14c80df3326e39cf74dc9e2166e86f0187552d8d5c8  Data_S2/settle_stageA/server_record/run_crispr.log
19a15f27cfca00e3277e02805d9ed3df3adc29ef3999c63d8e44f2a3af5b9796  Data_S2/settle_stageA/table_s15.md
28db88493b0f8d1512f216ed06b0638124b9c03c082d24dd07ba0468b3ff97aa  Data_S2/settle_stageA/table_s15_values.json
081c4147f84affda103d4c4f18cdedfd5354e27bfbeaf0975c5a7bc2544aefe7  Data_S2/shared_crossdrug/PLAN.md
36912c4f1fd4936f2d430520405d1fe29d4591e9f9121dc1d9370d0f48baa201  Data_S2/shared_crossdrug/SHA256SUMS
6440934653d3eb915b529509183fa5d80fee7475598f2a2a36100bf50bc431a7  Data_S2/shared_crossdrug/output_new_cell/summary.json
f76f45f0148ef423c76bc455d2d1167b20c64fd66bf3e4d9fbc4693f29c1a6c9  Data_S2/shared_crossdrug/output_tissue/summary.json
39eff4c07ad192b32791b763972ce9b758d4ef346c2241d19daaf1e67de5f547  Data_S2/shared_crossdrug/repro.log
e9bb93c260a59526a0242a69679bbcd8f8376546820c2d549ccb7882e3a95943  Data_S2/tissue_kernel/PLAN.md
2062a98ad395143df0d09e11c24b39452e6d4170d1f0c4cf1cede6a728a11ffc  Data_S2/tissue_kernel/SHA256SUMS
d272e3e22eaeeba785293109cc67453e5facf8d2a37af6f761af999b0b7155fc  Data_S2/tissue_kernel/output/summary.json
