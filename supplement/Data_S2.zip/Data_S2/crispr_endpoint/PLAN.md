# 预注册计划：把"跨层可恢复性地图 + 面板规律"换到 CRISPR 基因效应终点上复现

run id：`crispr-endpoint-20261009-0001`
撰写时间：2026-10-09（**必须在任何外折打分之前登记**；登记后只允许追加 ADDENDUM，不允许修改本文）

---

## 0. 目的与唯一要回答的问题

论文现有的两条规律都建立在 **GDSC 药物响应**这一个终点上：

1. **地图（matrix）**：多层空间只在"部署层 = 代谢物 M"这一行；免费虚拟层能追回该空间的约 1/3。
2. **面板规律（panel law）**：补测 k = 32–64 个监督选出的分子，能追回 M→多层空间的约 2/3–3/4。

审稿人必然会问：这是**规律**，还是**某一个终点的性质**？

本 run 的唯一目的：**在 CRISPR 基因效应终点上，用完全相同的 421 划分、相同的层编码、相同的生成器、相同的头，重新测一遍这两条规律。只换终点，不换任何别的东西。**

本 run **不是**算法探测，不引入任何新方法。不新增臂（除本计划 §5 列出的以外）。

## 1. 已核验的事实（写代码前已在服务器上确认）

- `effects.npy` = (310, 18443) float64，NaN 占 3.463%；`gene_ids` 18443；310 个 `sample_ids` **全部**落在 421 个开发系之内（映射 310/310，最大行号 420）。
- 跨细胞系基因效应 SD：SD>0.2 共 2,546 基因；SD>0.3 共 958；均值 < −1（近似 common-essential）共 887。
- 缺失结构极为规整：18,443 列中只有 **8 种不同的缺失模式**，17,109 个基因在 310 系上全观测。
- 每个外折（outer bank）带 CRISPR 的 query 细胞数：new_cell = 59/60/65/60/66；tissue = 60/49/65/68/68。带 CRISPR 的 fit 细胞数 242–261。
- 每个 outer bank 按 §3 规则的可评估基因数预计 2,345–2,521（new_cell 2,459–2,477；tissue 2,345–2,521）。

## 2. 数据边界（硬约束）

只读：
- `crispr310-prepare-20260908-0001/output/result/{effects.npy, gene_ids.npy, sample_ids.npy, model_ids.npy, lineage.npy}`
- `extra-supervision-20261008-0001/output/{scenario}/fold-{f}/{bank}/geometry.npz`（只用 `fit`/`query`/`m_only_kernel`/`m_only_cross`；`fit`、`query` 的下标本来就全部 < 421，`m_only_kernel` 超出 `len(fit)` 的 19 行/列**丢弃**）
- `gdsc-metabolite-full-protein-20260908-0001/output/result/source-inputs.npz`（m, p, tissues, sample_ids, protein_ids）
- `rna421-20260906-0002/{rna_log_cpm.npy, sample_ids.npy}`
- `crosslayer-matrix-20261009-0001/{code/crosslayer.py, output/{scenario}/bank_info.json}`（只为复现门）
- `protein-panel-20261009-0001/`、`rna-panel-20261009-0001/` 的代码模板

**绝不读**：64 验证集 / 123 内部最终集 / CTRP / GBM99 / DepMap 原始 CSV / 任何其他路径。

只写：服务器 `/public/home/mengxl/creed-research-runs/crispr-endpoint-20261009-0001/`（必须原本不存在）与本地 `~/Desktop/proj/creed/crispr_endpoint_20261009/`。

## 3. 终点、可评估靶标与细胞

**终点**：基因效应矩阵 E。把 310×18,443 按 `sample_ids` 映射回 421 行，得到 F（421×18,443），没有 CRISPR 的 111 个细胞系整行为 NaN。于是"某细胞是否有 CRISPR"自动由掩码 KRR 处理，不需要另外切分下标。

**可评估靶标（逐 bank，只看 fit，不看 query）**：对 bank b，
- `cnt_b(g)` = b 的 fit 细胞中 E[g] 被观测的个数；
- `sd_b(g)` = 这些细胞上的 nanstd；
- `evaluated_b = {g : cnt_b(g) >= 20 且 sd_b(g) >= 0.2}`。

打分用的是 **outer bank 的** `evaluated_outer`（逐折），并在报告中给出每个 bank 的个数。
**计算列集合** = `evaluated_outer`（4 个 bank 都在同一组列上出预测，这样内折选择逐列可用）。
面板权重（§5）用的是**该 bank 自己的** `evaluated_b`。

必要的定义性排除：某靶标若在 outer 的 query 细胞上**观测数为 0**，其 MSE 无定义（不是 0），从折内均值中剔除，并报告被剔除的个数与 query 观测数的最小值（按 §1 的缺失结构，预计为 0 个）。这是定义性的，不是筛选。

敏感性（描述性，不参与判据）：`sd_b(g) >= 0.3`。
稳健性："共同集" = 在 5 个外折中都可评估的基因。

**细胞**：outer 与 3 个 inner bank 的 fit/query 下标集合全部取自 `extra-supervision-20261008-0001`，与矩阵 run 逐字相同。
- **层核与生成器**用的是 421 划分的**全部 fit 细胞**（每层对所有 421 个细胞都存在），与矩阵 run 完全一致 —— 这是复现门能成立的前提。
- **头**（KRR 解）只会用到有 CRISPR 标签的 fit 细胞，这由掩码 KRR 自动完成（`predict_grid` 对每列取 `isfinite` 的行）。
- **query 细胞永不进入任何拟合**（核宽度、z-score、生成器 λ、面板选择、头的解，全部只用 fit）。

## 4. 层编码（与 `crosslayer.py` 逐字一致）

- **M**：225 个代谢物，fit z-score，RBF 宽度 = fit 行间正平方距离的中位数。
- **RNA**：按 fit 方差降序取前 3,000 基因（stable 排序），fit z-score，RBF 中位数宽度。生成器目标取前 512 列。
- **P**：在 fit 细胞中观测率 ≥ 50% 的蛋白；数值核（fit 均值填补 + fit 标准化 + RBF 中位数）与掩码核（0/1 指示向量上的 RBF，宽度 = 正 Hamming 平方距离中位数）各 0.5 相加 —— 即 `crosslayer.py` 的 `P`。
- **Pval**：同一候选池的**纯数值核**（蛋白面板 run 的教师编码）。
- **T**：同组织指示矩阵（只在 new_cell 场景）。

等权核相加：两层 0.5/0.5，三层各 1/3。

**生成器**：与 `crosslayer.py` 的 `generator()` 逐字一致 —— fit 内 3 折交叉拟合 KRR（X→Z），λ ∈ {0.1, 1, 10, 100} 按目标列平均 OOF MSE 选，fit 行用 OOF 预测、query 行用全 fit 生成器，种子 `sha256('oof|scenario|fold|bank')` 的前 8 字节小端。配对置乱对照与矩阵 run 同规则：用 `sha256('pair_shuffle|scenario|fold|bank')` 的置换对**生成器目标 Z 的 fit 行**重排后再拟合生成器（这正是矩阵 run 的做法，也是 `_shuf` 生成器 λ 能复现的前提）。

**复现门（硬门，先过门再打分）**：
1. M 核块：`|K_M − m_only_kernel[:n,:n]|` 与 `|H_M − m_only_cross[:, :n]|` 的最大绝对差 ≤ 1e-11。
2. 12 个生成器（6 个有向层对 × {原始, 置乱}）× 20 个 bank × 2 场景的 **λ 必须与矩阵 run 的 `bank_info.json` 完全相同**，`oof_r2_mean` / `oof_r2_median` / `virtual_width` 的最大绝对差 ≤ 1e-9。
报告 max |diff|。门不过就停下报告，不打外折分。

## 5. 臂（预注册，不增不减）

### 5.1 地图臂（两场景都有）
- `null`（逐靶标 fit 均值）
- 单层：`M`、`RNA`、`P`、`Pval`
- 实测多层：`M+RNA`、`M+P`、`M+Pval`、`RNA+P`、`M+RNA+P`
- 虚拟层：`M+vRNA`、`M+vP`、`RNA+vP`、`RNA+vM`、`P+vM`、`P+vRNA`
- 对应 6 个配对置乱对照：`M+vRNA_shuf`、`M+vP_shuf`、`RNA+vP_shuf`、`RNA+vM_shuf`、`P+vM_shuf`、`P+vRNA_shuf`
- new_cell 追加：`T`、`M+T`、`M+vRNA+T`、`RNA+T`、`P+T`

（new_cell 26 臂 + null；tissue 21 臂 + null）

### 5.2 面板臂（两场景都有）
- **蛋白面板**：候选 = fit 细胞观测率 ≥ 90% 且 fit 方差 > 1e-12 的蛋白（蛋白面板 run 的规则，是 Pval 候选池的子集）。权重 `w_j = Σ_{g ∈ evaluated_b} |Spearman(protein_j, effect_g)|`，逐对只用两边都观测的 fit 细胞，配对数 < 10 或任一边常数则该对贡献 0。按 w 降序取前 k，k ∈ {8,16,32,64} → `m_panel_P_k{k}`。
- **基因面板**：候选 = RNA 前 3,000 方差池（稠密无缺失）。同样的 w 规则 → `m_panel_G_k{k}`，k ∈ {8,16,32,64}。
- **随机面板**：k ∈ {16,32}，每个 5 个种子，两层各自做：`rng = np.random.default_rng([20261009, scenario_id, fold, bank, s, layer_id])`，`scenario_id`：new_cell=0, tissue=1；`bank`：inner-0=0, inner-1=1, inner-2=2, outer=3；`layer_id`：蛋白=0, 基因=1。从该层候选池无放回取 k 个 → `random_P_k{k}_s{s}`、`random_G_k{k}_s{s}`。
- **面板核**：所选分子上的 RBF（蛋白先 fit 均值填补；两层都 fit z-score、fit 中位数宽度）。头在 `0.5*K_M + 0.5*K_panel` 上**重训**。
- **教师**：蛋白面板的教师 = `M+Pval`；基因面板的教师 = `M+RNA`（都已在地图臂里）。
- **追回比例** `R(k) = (S_M − S_panel_k) / (S_M − S_teacher)`，用 5 折均值分数算（与面板 run 的口径一致），同时给逐折值。

共 8 + 20 = 28 个面板臂。

## 6. 指标（与药物任务形式完全相同）

对每折、每个可评估靶标：
`mse_g = mean over observed query cells of ((pred − truth)/train_sd_g)^2`，其中 `train_sd_g = max(outer fit 的 nanstd, 1e-8)`。
`fold score = sqrt(mean over evaluated targets of mse_g)`（= sRMSE）。
`headline = 5 折 score 的算术平均`。
同时报告：**折内 Spearman**（逐靶标在 query 细胞上 truth 与 pred 的 Spearman，再对可评估靶标取均值）与 **centered MSE**（`mse_g − bias_g^2`，`bias_g` = 标准化后的平均偏移）。

**超参只在 3 个 inner bank 上选**：逐靶标取 α ∈ {0.1, 1, 10, 100} 中使"3 个 inner bank 上标准化 MSE 之和"最小的那个；该靶标在 3 个 inner bank 上都没有可用 query 观测时回落到下标 1（α = 1）。某靶标在某 bank 的 fit 可观测细胞 < 20 时，该 bank 该靶标用 fit 均值（不解 KRR）。

## 7. 统计

- `gain%`（**主口径**）= 逐折相对改善的 5 折均值：`d_f = (S_base,f − S_arm,f)/S_base,f × 100`，`gain% = mean_f d_f`。同时报告 **5 折均值之比** `(mean S_base − mean S_arm)/mean S_base × 100`。
- **胜折数** = `S_arm,f < S_base,f` 的折数。
- **Nadeau–Bengio 校正配对 t**：`se = sqrt((1/5 + r) · var(d, ddof=1))`，`t = mean(d)/se`，df = 4，双侧 p；95% 区间 `mean(d) ± t_{.975,4}·se`。`r` = 5 折 **带 CRISPR 的** `n_query/n_fit` 的均值（同时报告全划分的 `n_query/n_fit` 比值）。
- **不丢任何臂、任何折**；不做事后换指标；阴性结果照常报告；**不做多重比较校正**（如实声明）。

## 8. 预注册判据（每个场景分别判）

`R1 空间在 M 行`：`M+RNA vs M` 与 `M+P vs M` 的 `gain%` 都 > 0 **且**都在 ≥ 4/5 折为正。
`R2 虚拟层追回`：`M+vRNA`、`M+vP` 至少一个满足 —— 对 `M` 在 ≥ 4/5 折胜且 NB p < 0.10，**并且**对它自己的置乱对照在 ≥ 4/5 折胜。
`R3 M 对 RNA/P 部署没有贡献`（**只报告，不计入判定**）：`RNA+M vs RNA` 与 `P+M vs P` 各自 `gain% <= +0.3%` 或胜折 <= 2/5。给出确切数字。这是 GDSC 的格局，不是规律的要求。
`R4 面板规律`：蛋白面板与基因面板**都**满足 `R(32) >= 0.5` 且 `R(64) >= 0.5`（5 折均值口径的 R）。

**场景判定** = R1、R2、R4 中满足的条数（R3 只报告）：
- 3/3 → **规律复现**
- 2/3 → **部分复现**
- ≤ 1/3 → **不复现**

另外报告每个 M 行格子的 **追回份额 = recovered/room**，并与 GDSC 地图逐格并列：
new_cell：M→RNA room 3.08%、share 34%；M→P room 2.40%、share 29%。
tissue：M→RNA 2.19%/33%；M→P 2.21%/33%。
面板 R(k) 与 GDSC 并列：蛋白 new_cell 0.48/0.56/0.65/0.72，tissue 0.64/0.57/0.66/0.74；基因 new_cell 0.37/0.56/0.72/0.76，tissue 0.45/0.64/0.78/0.76（k = 8/16/32/64）。

## 9. 稳健性（对 R1 / R2 / R4）

1. **去一折最小值**：依次去掉每一折，重算 5 个"4 折 gain%"，报告最小值。
2. **分组 bootstrap**：B = 2000，`rng = np.random.default_rng(20261009 + scenario_id)`（与面板 run 同约定）。靶标按 bank 并集重抽，**5 折共享同一组权重**；细胞 —— new_cell 场景按组织簇整簇重抽，tissue 场景在留出组织内分层重抽。报告 95% 分位区间与 P(>0)。
3. **SD >= 0.3 敏感性**：用 `sd_b >= 0.3` 重算全部判据。
4. **共同集敏感性**：只用 5 折都可评估的基因重算。

## 10. 产出

服务器 `crispr-endpoint-20261009-0001/`：`PLAN.md`、`PLAN_REGISTERED_AT.txt`、`SHA256SUMS`（PLAN + 代码，**跑之前**）、`code/`、`dryrun/`（只有 fold-0 inner-0：生成器 λ/R² 复现 + 内折网格合理性，**不出外折分**）、`logs/`、`run.log`、`output/{scenario}/fold-f_predictions.npz`（逐臂 pred、truth、train_sd、evaluated、细胞与基因下标）、`fold-f_selection.npz`、`fold-f_bank_info.json`、`output/fold_metrics.csv`、`output/comparisons.csv`、`output/summary.json`、`OUTPUT_SHA256SUMS`。

本地 `crispr_endpoint_20261009/`：`PLAN.md`、`code/`、`fold_metrics.csv`、`comparisons.csv`、`summary.json`、`RESULT.md`（中文）。

## 11. 预先声明的局限（结果好坏都要写）

310 个细胞系（不是 421）；每折 query 细胞只有 49–68 个；基因集由 fit SD 选出；复用了已被多次使用的开发折；不做多重比较校正；基因面板的候选是 RNA 表达、靶标是 CRISPR 效应，存在"同一基因自预测"的成分（不剔除，如实说明）。

## 12. 执行顺序（不可颠倒）

1. 写完本 PLAN 与 `code/`，算 `SHA256SUMS`，拷到服务器并写 `PLAN_REGISTERED_AT.txt`。
2. 跑 `dryrun`（fold-0 inner-0），过复现门与网格合理性。
3. 跑 `main`（两场景，各 ≤ 4 线程，总共 ≤ 8 线程）。
4. 跑 `analyze.py`，出 `comparisons.csv` / `summary.json`。
5. 写 `RESULT.md`。PLAN 自第 3 步起不再改动，只允许 ADDENDUM。
