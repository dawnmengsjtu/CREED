# 原 608 之外全部身份安全 M+RNA 配对池的提取（generator-fullpool-20261009-0001）：预先登记

登记时间：2026-10-09。本文件在任何原始数值被解码之前写下，上传服务器 run 目录并记录 sha256（`PLAN_REGISTERED_AT.txt`、`SHA256SUMS.v1`）。之后不按结果修改；若必须改动，只在文末追加 ADDENDUM 并保留追加前的哈希。

服务器 run 目录：`/public/home/mengxl/creed-research-runs/generator-fullpool-20261009-0001/`（新建，之前不存在）
本地目录：`/Users/xlzhexue/Desktop/proj/creed/generator_fullpool_20261009/`

## 0. 要回答的问题

PI 于 2026-10-09 放行 5 个原始文件（`_raw_whitelist_20261009/`：CCLE 代谢组 CSV、CCLE RSEM expected counts、ProCan mmc2/mmc3、DepMap Model.csv）。此前的盘点（`generator_scaleup_20261009/INVENTORY.md`）只能沿用 2026-10-08 冻结的 66 条额外 M+RNA 线，因为原始源不可读。现在要**从原始源重新穷举**：原 608 之外、身份安全、同时有 M 行和 RNA 列的全部细胞系有多少条？它们在新细胞场景和整组织留出场景的各外折各能用多少？M∩P 的全集是否"基本就是 608"？

这是一次**提取与计数**，不计算任何外折分数，不训练任何模型。可行性预设阈值：`usable_new_cell >= 150` 则进入下一步生成器扩容实验；否则如实报告不可行。

## 1. 数据边界（硬）

- 只读：`_raw_whitelist_20261009/` 的 5 个文件（sha256 以验收报告 `SHA256SUMS` 为准，运行前断言）；`extra-supervision-20261008-0001/resources/`（`extract_rna_candidates.py`、`rna_config.json`、`m_rna_extra66.npz` 等）；`rna421-20260906-0002/`（冻结 34,985 基因面板与变换）；`gdsc-metabolite-full-protein-20260908-0001/output/result/source-inputs.npz`（225 代谢物顺序、421 的 M 值、组织词表、fold_ids）。
- **mmc3.xlsx 只读 `Prot matrix excl single-peptide` 第一列的样本 ID**（SIDM 前缀），不存任何蛋白值。
- **封存线（64 validation + 123 internal_final）**：ID 来自本地 `handoff_20261009/evidence/original_identity_split.json`（只复制 ID 到 `resources/original_identity_split_ids.json`），运行前断言 421+64+123 的并集 == `rna_config.json` 的 `excluded_old608`（608 项）。它们的任何数值不解码、不写、不打印：M CSV 与 RNA gz 均按身份前缀/表头做行列门控，只有池内线与 5 条 421 训练校验线的数值字段会被 `float()`。
- 只写：上述新 run 目录与本地目录。不修改任何旧 run。8 线程。

## 2. 身份桥（镜像 2026-10-08 白名单审计）

1. **mmc2 为唯一权威**：`Cell line level sample info` 的 `model_id(SIDM) ↔ BROAD_ID(ACH) / CCLE_ID`，以及 `Tissue_type`（项目组织词表来源）。一个 ACH 或 CCLE_ID 在 mmc2 中对应多个 SIDM → 该键视为歧义、不用。
2. **Model.csv 补充**：`ModelID(ACH) ↔ SangerModelID(SIDM) ↔ PatientID / CCLEName / OncotreeLineage`。只在 mmc2 对该 SIDM 与该 ACH 都没有映射时采用；mmc2 已把该 SIDM 或该 ACH 映射到别处 → **mmc2 胜**，Model.csv 的映射丢弃并记入 `bridge_conflicts`。一个 SIDM 在 Model.csv 对应多个 ACH → 不用。
3. **M 行解析**：`DepMap_ID → ACH → 桥 → SIDM`；`CCLE_ID → mmc2 CCLE_ID → SIDM` 或 `→ Model.csv CCLEName → ACH → 桥 → SIDM`。两条路径都解析且不一致 → 失败关闭（排除）。两条都不解析 → 排除（不猜）。同时按"仅 mmc2"口径再解析一次（608 协议），用于 M∩P 全集计数并断言恰为 609 个 SIDM。
4. **候选** = 解析出 SIDM 且该 SIDM 出现在 RNA 表头（1,047 列）的 M 行。
5. **排除（顺序记录首个命中原因）**：(a) SIDM ∈ 608；(b) ACH 与某 608 线相同；(c) PatientID 与某 608 线相同；(d) CCLE 名（mmc2 CCLE_ID 或 Model.csv CCLEName）与某 608 线相同；(e) 规范化细胞名（去非字母数字、大写；mmc2 Cell_line / Model.csv CellLineName / StrippedCellLineName）与某 608 线相同。然后池内去重：同 ACH 或同 PatientID 只保留 SIDM 最小者；同一 SIDM 对应多条 M 源行只保留文件中第一条并记录。
6. **组织**：SIDM 在 mmc2 中且 Tissue_type 非空 → 直接用；否则用 `OncotreeLineage → Tissue_type` 的经验映射（由同时出现在两表的线学习，多数类占比 ≥ 90% 且 n ≥ 3 才采用）；否则留空。组织空值在新细胞场景保留、在整组织场景排除（与 INVENTORY/曲线 run 一致）。与 66 包的 `tissues` 逐条比对并报告差异。
7. 断言与报告：421 ⊂ 608（按 ID）；已审计 66 条是否 ⊂ 池；池中不在 66 的新增线列出其 ID 与来源。

## 3. 数值与硬门

- **M**：源 CSV 的 225 列按 `source-inputs.npz['metabolite_ids']` 的顺序（运行前断言表头 == 该顺序 == `rna_config.m_feature_ids`），原值 float64，不取 log、不标准化、不插补（`original_prepare_gdsc421.py` / `extract_m_gdsc.py` 的口径：`m_transform='identity'`）。
- **RNA**：`original_prepare_research_rna421.py` 的变换：在冻结 34,985 个 `common_source_gene_indices` 上，`ln(1 + counts / 该样本在面板上的总计数 × 1e6)`；gene_id 顺序 == `rna421/gene_ids.npy`（断言源 37,279 个 gene_id == `all_source_gene_ids.npy`）。
- **硬门（任一失败即停止，不出包）**：5 条 421 训练线 `SIDM00018, SIDM00080, SIDM00082, SIDM00396, SIDM00685`（Sanger/Broad 两批都有）——M 向量与 `source-inputs m` 最大绝对差 ≤ 1e-9 且 NaN 模式相同；RNA log-CPM 与 `rna421/rna_log_cpm.npy` 最大绝对差 ≤ 1e-9。
- 信息性交叉核对：池中与 66 包重叠的线，M 与 RNA 的最大绝对差（预期 ~1e-15 量级）。

## 4. 逐折计数

- 整组织留出场景外折留出组织 = `source-inputs.npz fold_ids` 对应的组织集合（fold 0 Lung；1 Bone/Endometrium/Haem；2 Bladder/Breast/Kidney/Pancreas/PNS/Prostate；3 Biliary/H&N/Large Intestine/Ovary/Soft Tissue/Stomach；4 CNS/Esophagus/Liver/Other/Skin/Thyroid）。外折可用 = 池中组织非空且不在该折留出集合的线数。
- 内折 bank 的留出组织按 `INVENTORY.md` §3.2 的列表转录（不读 extra-supervision 的 output/geometry）。
- 新细胞场景：全部池线每折可用（组织空值按既定规则保留并单列）。

## 5. M∩P 全集

- P 的样本集合 = mmc3 `Prot matrix excl single-peptide` 第一列 SIDM 前缀（预期 949）。
- 报告 |M(仅 mmc2 解析) ∩ P|、|M(桥) ∩ P|、以及各自 ∩ RNA 的数目与其中在 608 之外的 ID 和它们的排除原因。这就是"608 基本就是整个 M∩P 全集"这句话的依据。

## 6. 产物

- `pack/m_rna_fullpool.npz`：`sample_ids`(SIDM)、`ach_ids`、`patient_ids`、`tissues`、`lineages`、`ccle_ids`、`rna_source_names`、`m [n×225] float64`、`rna [n×34985] float32`、`rna_counts_common`、`metabolite_ids`、`gene_ids`、`common_source_gene_indices`、5 条校验线的 `parity_*`、`qa_json`。
- `pack/qa.json`：计数、排除清单（不含任何 608 线的 PatientID/名字列表，只含数目）、硬门、逐折、全集。
- `pack/EXTRACTION.md`（中文）：结果与阴性如实写出；同步到本地。
- 完整性：`PLAN_REGISTERED_AT.txt`、`SHA256SUMS.v1`（运行前：PLAN.md、code/、resources/）、运行后 `OUTPUT_SHA256SUMS`；任何后续版本写 `SHA256SUMS.v2`…，不覆盖。

## ADDENDUM-A（2026-10-09，运行前程序修正，未解码任何数值）

首次运行在读 mmc2 身份表时停止（`AssertionError: ACH-000833;ACH-001741;ACH-001189`）：mmc2 的 `BROAD_ID`（以及可能的 `CCLE_ID`）字段可为分号分隔的多值。修正：按 `;` 拆分，每个列出的 ACH/CCLE_ID 都作为该 SIDM 的键（一个键在 mmc2 对应多个 SIDM 仍视为歧义、不用）；池内记录的 `ach_id` 取与该 M 行 `DepMap_ID` 相符的那个，否则取首个；"与 608 线共享 ACH / PatientID / CCLE 名 / 细胞名"的排除键取 608 线所有列出的 ACH 及其对应 Model.csv 记录的并集。其余不变。追加前 PLAN.md sha256 `c92344931d9aee4502dd01fc881c833a743cd227bed848e107a1be685f65c024`（见 `SHA256SUMS.v1`）。

## ADDENDUM-B（2026-10-09，运行前程序修正，未解码任何数值）

第二次运行在身份阶段停止：§2.3 预设的断言"仅 mmc2 解析恰为 609 个 SIDM"失败，实际 611。原因是 ADDENDUM-A 的分号拆分让 3 条多值线（`SIDM00096`、`SIDM00400`、`SIDM01095`）也可经 mmc2 解析，而原 608 协议显然把多值字段当整串处理（不匹配）。修正：不再断言 609，改为同时报告两种口径（拆分 / 整串）的计数与 608 之外的 ID，并保留 `608 ⊂ 两种口径` 的断言。其余不变。追加前 PLAN.md sha256 `78b08ed7832625de778b147f8e78fc23cd85327d3a18a830eade0b779c6970de`（见 `SHA256SUMS.v2`）。
