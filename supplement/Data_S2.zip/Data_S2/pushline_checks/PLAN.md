# 推进线补充检查（仅分析，不训练）：预先登记

登记时间：2026-10-09。写于计算本次任何新统计量之前。之后不按结果修改；如因程序错误必须改动，只在文末追加 ADDENDUM 说明原因，并重跑全部比较。

## 0. 已知信息声明（如实写明本登记"盲"到什么程度）

- 各臂的 5 折均值 sRMSE 已在之前的报告和本任务说明里公开：(a) extra__m_only__protein 1.006284 对 extra__m_only 1.010662；(b) m_tissue__protein 0.994376 对 m_tissue 0.996534（组织核 run 的逐折分数也已经公开，P 图增量 0.22%、4/5 折）；(c) original__virtual_fm__protein 1.110667 对 original__virtual_fm 1.113467，extra__virtual_fm__protein 1.112609 对 extra__virtual_fm 1.115144。
- 所以本登记对"主比较能否达到 1%"并不盲。它约束的是本次新增的统计量和判定规则：逐折相对改善、留一外折、数值臂对掩码臂、结构对照、成组二维 bootstrap、281 药共同面板、校正 t 检验，以及通过/未通过表。这些量此前没有算过（(b) 的 t 检验在组织核 RESULT 里报过一次，本次按同一定义重算）。
- 写本登记前只查看了不含结果的元数据：每折 held/fit 数、面板大小、evaluated 数、每折测试细胞的组织簇数、npz 的键名。

## 1. 边界

- 只读：extra-supervision-20261008-0001（output/、code/、resources/m_gdsc_extra19.npz）；source-inputs.npz（auc、tissues、sample_ids、drug_ids）；tissue-kernel-20261009-0001/output；strong-teacher-recoverability-20261008-0001/output 的 fold_metrics.csv（只作蒸馏条件的背景参照）。不跟随任何 handoff 符号链接。
- 只写：服务器 `/public/home/mengxl/creed-research-runs/pushline-checks-20261009-0001/` 与本地 `/Users/xlzhexue/Desktop/proj/creed/pushline_checks_20261009/`。
- 不训练任何模型，不新增任何臂。全部分析对象是已保存的外折预测。不碰 64/123、CTRP、GBM99、原始 CSV。
- 8 线程（OMP/OPENBLAS/MKL=8），单进程。

## 2. 复现检查（先于一切结论）

1. **分数级（判据）**：用本次独立实现的指标函数，从 extra-supervision 两个场景每折 predictions.npz 的预测、truth、train_sd、evaluated，重算全部 20 个保存臂 × 5 折的 score、spearman、centered_mse，与各自 fold_metrics.csv 比较。score 的最大绝对差 ≤ 1e-8 记为通过（spearman、centered_mse 同样报告差值）。组织核 run 的 7 个臂 × 5 折同样与其 fold_metrics.csv 比较。
2. **对齐检查（判据）**：组织核 run 的 repro_m、repro_mP 外折预测与 extra-supervision 的 extra__m_only、extra__m_only__protein 逐元素最大差 ≤ 1e-8，证明组织核预测与 extra-supervision 的 truth 行列对齐。
3. **真值核对**：truth 与 source auc[held, panel] 完全一致（NaN 位置相同、数值相同）；train_sd 与 max(nanstd(auc[fit, panel]), 1e-8) 的差 ≤ 1e-12。
4. **预测级（附加）**：用每个 bank 保存的 grids.npz 和原选择规则（3 个内折 bank 上逐药标准化均方误差——内折 truth = auc[query, panel]，标准化用内折拟合集逐药 nanstd，下限 1e-8——按药求和后 argmin；没有内折信息时回退 index 1；内折面板按药物全局索引对齐到外折面板），重新选出两个场景全部 20 臂 × 5 折的外折预测，与 predictions.npz 比较，判据 ≤ 1e-8。若第 1、2 项通过而本项失败，如实报告失败的臂和差值并写入注意事项；本次分析对象是保存的预测，不受影响。
5. 第 1 或第 2 项失败：只报告失败，不报告任何比较结果。

## 3. 候选与主比较（每个主比较：候选 对 同部署输入、同训练数据下最强的直接基线）

| 编号 | 场景 | 部署输入 | 候选 | 直接基线 | 掩码对照 | 结构对照 |
|---|---|---|---|---|---|---|
| P1 (a) | new_cell | M | extra__m_only__protein | extra__m_only | extra__m_only__mask | extra__m_only__shuffle, extra__m_only__metabolite |
| P2 (b) | new_cell | M + 组织标签 | m_tissue__protein | m_tissue | 无保存 | 无保存 |
| P3 (c1) | tissue | M（经虚拟 FM） | original__virtual_fm__protein | original__virtual_fm | original__virtual_fm__mask | original__virtual_fm__shuffle, original__virtual_fm__metabolite |
| P4 (c2) | tissue | M（经虚拟 FM） | extra__virtual_fm__protein | extra__virtual_fm | extra__virtual_fm__mask | extra__virtual_fm__shuffle, extra__virtual_fm__metabolite |

次要比较（只描述，不进通过表）：
- S1：extra__m_only__protein 对 original__m_only__protein（加数据对同方法的作用）。
- S2：extra__virtual_fm__protein 对 original__virtual_fm（与该场景所有直接臂里最强者比，不要求训练数据相同）。
- S3：m_tissue__protein 对 tissue_only、对 null_tissue_drug；extra__m_only__protein 对 tissue_only（输入不同，只作"其他强基线"报告）。
- 所有臂（两场景 20 个保存臂、组织核 7 个臂、逐药均值零模型的原数据和加数据版）都报告 5 折分数、5 折均值、Spearman、centered MSE。

## 4. 统计量定义

- 折分数：score_f = sqrt(mean_{evaluated j} mse_j)，mse_j = 观测测试细胞上 ((pred − truth)/train_sd)² 的均值；truth/train_sd/evaluated 取自 extra-supervision 同折 predictions.npz（(b) 也一样）。主终点 = 5 折均值。
- **相对改善**：rel = (mean_f base_f − mean_f cand_f) / mean_f base_f（5 折均值之比）。同时报告逐折相对改善 (base_f − cand_f)/base_f 及其平均。
- **胜折数**：cand_f < base_f 的折数。
- **留一外折（LOFO）**：去掉第 k 折后用剩下 4 折的均值重算 rel，k = 0..4，共 5 个值。
- **Nadeau–Bengio 校正配对 t 检验**：d_f = 逐折相对改善（%）；se = sqrt((1/5 + r) · var(d, ddof=1))，r = 5 折 n_held/n_fit 的平均（只数开发细胞，不含额外样本）；t = mean(d)/se，df = 4，双侧 p；95% CI = mean(d) ± t_{0.975,4} · se。
- **成组二维 bootstrap（主区间）**：B = 2000，`numpy.random.default_rng(20261009)`。每次重复：先在场景的药物全集 U（5 折面板 drug_id 的并集；new_cell 295，tissue 286）中有放回抽 |U| 个药，得到药物重数 w_j（同一次重复里 5 折共用）；再依次对 fold 0..4，把该折测试细胞按 source `tissues` 分簇，有放回抽与簇数相同个数的簇，簇内细胞全部带入，得到细胞重数 c_i。每折每臂：mse_j = Σ_i c_i·obs_ij·e_ij / Σ_i c_i·obs_ij（分母为 0 的药本次视为该折未评估）；score_f = sqrt(Σ_j w_j·v_j·mse_j / Σ_j w_j·v_j)，v_j = 该药在该折 evaluated 且分母 > 0。每次重复算 5 折均值的 rel。报告 2.5%/97.5% 分位数和 rel > 0 的比例。同一组重抽权重用于同场景所有臂（P1、P2、S1 共用 new_cell 的权重）。
- **两阶段 bootstrap（预先登记的敏感性，不进通过表）**：`numpy.random.default_rng([20261009, 2])`，药物抽法同上；每折先抽组织簇，再在每个被抽中的簇内有放回重抽该簇的细胞（个数等于簇大小）。理由：tissue 场景 fold 0 只有 1 个组织簇，fold 1 只有 3 个，主区间在这两折上几乎不含细胞层面的变异。
- **281 药共同面板**（tissue 场景）：5 折都 evaluated 的 drug_id 交集（元数据显示为 281 个）。只用这些药重算每折分数，再算 rel、胜折数、LOFO、校正 t 检验，以及数值对掩码。new_cell 场景 5 折都评估全部 295 药，共同面板与全面板相同，只注明。
- Spearman：逐药对观测细胞算 spearman(truth, pred)，truth 或 pred 常数（std(truth)=0 或 std(pred) ≤ 1e-15）时跳过，取 evaluated 药的均值。centered MSE：mse_j − bias_j²，bias_j = (观测细胞预测均值 − truth 均值)/train_sd，取 evaluated 药的均值。均与参考实现相同。

## 5. 推进线条件（逐候选通过/未通过表）

依据 `CREED_FOCUSED_PLAN_20261007.md` 第 81–92 行，操作化如下：

| 条件 | 内容 | 通过规则 |
|---|---|---|
| R1 | 对同输入、同训练数据最强直接基线的平均相对改善 | rel ≥ 1.00% |
| R2 | 同方向折数 | 胜折 ≥ 4/5 |
| R3 | 数值臂好于对应掩码臂 | 5 折均值 cand < mask |
| R4a | 去掉任一外折后主比较优势不完全消失 | 5 个 LOFO rel 全部 > 0 |
| R4b | 去掉任一外折后"数值对掩码"优势不完全消失 | 5 个 LOFO rel(cand 对 mask) 全部 > 0 |
| R5 | 成组重采样不确定性（原文只要求报告；本次预先操作化） | 主 bootstrap 95% 区间下界 > 0 |
| R6 | 281 药共同面板敏感性（仅 tissue 场景） | 共同面板上 R1 与 R2 仍成立 |
| R7 | 结构对照（类比原文"真实结构好于打乱身份"；只存了 1 个打乱图，不是 5 个） | 5 折均值 cand < shuffle 且 cand < metabolite |
| R8 | 匹配的普通方法/蒸馏不能解释全部优势 | 见下 |

- R8：本次任何候选都没有"同输入、同训练数据、同调参预算"的蒸馏臂，记为"未评估"。作为背景参照（不进判定）：读取 strong-teacher-recoverability run 的 fold_metrics.csv，先核对其 m_only 逐折分数与 original__m_only 一致（≤ 1e-8）；一致时报告原数据、M 输入下 original__m_only__protein 与 transfer_protein_delta（蛋白教师残差迁移，即 H057）的逐折比较和相对改善，tissue 场景同样报告 original__virtual_fm__protein 与 transfer_protein_delta（基底表示不同，只是描述）。
- 无保存对照时（P2 的 R3、R4b、R7），记为"不可评估"。
- 不适用时（P1、P2 的 R6），记为"不适用"（new_cell 共同面板 = 全面板）。

## 6. 分级判定（预先写好）

- **过推进线**：R1–R7 中所有可评估项全部通过，且没有"不可评估"项；R8 不为未通过。由于 R8 本次只能是"未评估"，最好结果写为"除蒸馏条件外过线"。
- **小幅但可靠**（按原计划第 92 行，可作为已有方法的补充分析，不是新方法优越性）：rel > 0、胜折 ≥ 4/5、R4a 通过、R5 通过，且 R3 通过（P2 无掩码臂，则此项记缺失，结论加注"无掩码对照"）。
- **小幅不稳**：rel > 0 但不满足上一档。
- **无增益**：rel ≤ 0。

不靠增加种子、改 bootstrap 单位、删药、删折或换主终点改变上述判定。两阶段 bootstrap 只作敏感性报告。

## 7. 输出

服务器 run 目录：PLAN.md、code/pushline_checks.py、SHA256SUMS（PLAN 与代码）、run.log、output/summary.json、output/fold_scores.csv、output/comparisons.csv、output/pass_fail.csv、output/bootstrap.npz。本地目录：PLAN.md、代码副本、summary.json 副本、pass_fail.csv 副本、RESULT.md（中文）。
