# Extra measured supervision with frozen kernels — 2026-10-08

Execute the third item previously planned in strategy_20261008/DECISION.md. One finite full-label comparison on the original 421 development samples, unchanged original five outer/three inner folds and full drug panels. Query inputs remain M only. No protected 64/123 or CTRP outcomes; old strong models and six R figures remain intact.

## Added observations

Use the 19 M–GDSC identities already qualified outside original 608 and their known same-patient/same-name identities, exact ACH/SIDM bridge from frozen Model.csv, CCLE-name crosscheck, response-independent eligibility. Numeric extraction retains the original raw 225 metabolite definitions, 295 drug order and GDSC 24Jul22 AUC/QC. SHA256 of added table: d4e7dc603f491217805a1d06b673f8c2662a8c0f2ad77ec875f7d7868526384c. All 19 have complete M and some valid Y; 4,485 observed responses, other pairs remain NaN. All data/metadata provenance and exclusions are retained in resources/.

New-cell scenario: all qualified extra identities can train each bank; they have already been excluded if related to any original 608 identity. Tissue scenario: require uniquely mapped original tissue and exclude every tissue represented among original 421 cells outside the current fit (outer held and, for inner banks, inner held). SIDM00271 has unresolved tissue and is excluded from all tissue banks. No selection by drug coverage or performance, no added test cells, no reallocation of original folds. Identity metadata excludes currently known relationships, not a claim that every unknown derivative relationship has been resolved.

## Frozen representation and objective

Keep every current-fit M/FM standardization moment, bandwidth, original Gram/cross-kernel block and the same three saved M→FM generators. No generator retraining. Original fit FM points stay their saved OOF vectors. Each extra sample has three saved-generator FM views. Use their mean feature-map embedding in the original RBF kernel: extra–old average 3 kernels; extra–extra and query–extra average 9 kernels. Do not average vectors before RBF or reset the new diagonal to one. Base remains 0.5 M kernel + 0.5 FM kernel. This is a consistent PSD extension of the old kernel, not new measured test-time omics.

Each old graph is embedded as diag(L_old,0_extra). New cells lack measured P; they receive no fabricated protein edges. Keep trace(L)=n_old, not n_total. Append extra true response rows to the same mean-centered masked KRR objective. Drugs with zero additional response labels reuse their exact old grids: unlabeled zero-penalty nodes cannot change their objective. Existing low-label mean fallback (<20 observed) is unchanged. Alpha={0.1,1,10,100}; mu={0,0.1,1,10,100,1000}, identical across graph arms. No sample weights, new tuning grids or post-hoc mixtures.

## Comparison and selection

Core factorial: original data vs added observations × direct vs P-graph, for both M and virtual-FM bases. Retain all original mask/shuffled-P/M graph controls too: 10 old arms + 10 added-data arms per scenario, 200 fold metrics total. All added-data arms receive identical extra pools. The original 10 arm predictions must remain bit-identical.

Retain original inner truth, original-fit inner SD and old selection rule. Extra response labels enter fitting for that bank, not its validation set. Outer evaluation keeps original truth, drug flags and original train_sd across all arms. Main starts continue tissue virtual-FM and new-cell M, chosen from previous development and disclosed. Both bases reported, no retrospective winner routing.

## Readout and boundary

Report full-panel five-fold equal-mean sRMSE, within-drug Spearman and centered MSE. Compare new P-graph with old strongest corresponding P-graph, with the same added-data direct baseline and other graph controls. Quantify the data contribution separately from the graph contribution. Since the original outer results have informed prior development, this remains candidate_only, not independent external confirmation or a new-algorithm claim.

Freeze after source/implementation parity and before outer readout. No modification of sample eligibility, representation aggregation, graph scale, drug panel or search after scores. RNA–M and RNA–GDSC assets may be separately qualified in parallel, but do not enter this fixed comparison. Dataset counts for those assets must not be called additional M–response training samples.
