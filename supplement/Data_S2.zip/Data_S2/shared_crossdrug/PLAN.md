# 共享跨药物细胞敏感性因子（方向 B）：预先登记

登记时间：2026-10-09。本文件在计算任何新臂（shared*/sharedLR*/sharedPerm*）的外折分数之前写成，并与代码一起记入服务器 `SHA256SUMS`。之后不修改本文件；如有错误需要改代码，只在文末追加 ADDENDUM，并重跑全部臂。

写本文件前已经做过、且只做过这些事：
1. 读了台账 H030、H050 行，H050 的 README（`handoff_20261009/evidence/experiments/execution_20261008_functional_operator/README.md`）和 H030 在 `ALGORITHM_IMPLEMENTATION_LEDGER.md`、`PROJECT_HISTORY.md` 中的描述（H030 的服务器 run 不在本次可读范围内，只按文档比对）。
2. 用合成数据跑了单元测试（`code/test_synthetic.py`，无真实标签）。
3. 用 `repro` 模式只重算了已存在的基线臂（不计算任何新臂），复现检查全部通过，见第 6 节。
4. 看过训练标签的缺失结构（每药观测数、每细胞观测数、缺失模式个数），没有看任何新臂的内折或外折损失。

## 1. 与 H030、H050 的区别（先判断是否重复）

| | H030 task-metric | H050 functional operator | 本次 shared cross-drug factor |
|---|---|---|---|
| 改动位置 | 输入/表征侧：用药敏残差监督学 rank16 ridge 方向，投影后重算 RBF 核（改变核几何） | 神经网络：225 维 M + 药物描述 → 药物条件化功能状态；训练用实测 P 的 Reactome 模块与 OOF 误差协方差约束 | 输出/标签侧：核完全不变（直接用已存 bank 的 M 核、M+组织核、虚拟 FM 核、P 图有效核） |
| 跨药物共享方式 | 共用一个被监督改过的输入度量；之后每个药仍独立 KRR、同一套 alpha | 共享网络参数、药物描述做条件 | 在标准化标签矩阵上显式估计细胞级共享因子 s（逐药标准化后跨药平均，或缺失值迭代填补的 rank-1/2/3 SVD），用同一核单独以 alpha_s 做 KRR 预测；每个药只拟合载荷 beta_d；剩余残差再按原逐药 KRR（alpha_r） |
| 是否用 P / 药物描述 / 神经网络 | 否 / 否 / 否 | 是 / 是 / 是 | 否 / 否 / 否（P 只在可选的 P 图叠加臂里，以原有方式出现） |
| 与基线的关系 | 换了核，不嵌套原基线 | 不嵌套 | gamma=0 时与原基线逐位相同（同一选择规则、同一回退索引 1），即严格嵌套 |
| 能利用的新信息 | 无新的标签信息 | 无 | (a) 共享分量用很小的 alpha_s 预测，药物特异分量仍可大幅收缩，两者收缩强度分开；(b) 某细胞缺某药的标签时，该细胞仍通过其他药物的标签参与共享因子的学习（含 19 个额外样本） |

结论：本次与 H030、H050 **不是同一方法**。H030 改的是输入几何，本次不碰输入几何、只在标签空间共享；H050 是药物条件化神经网络加 P 教师，本次是闭式核回归、无 P 教师。需要如实说明的重叠：本方法属于熟悉的“多任务低秩/降秩回归”方法族，与 H030 同属“跨药物低秩共享”这一大类，不主张方法新颖性，只检验输出侧共享是否带来可部署增益。

## 2. 假设

GDSC2 的 AUC 有很强的“一般敏感性”成分（同一细胞对很多药都敏感或都不敏感）。逐药 KRR 每个药只用自己的约 300 个标签去学这一成分，并且为了压住药物特异噪声常常选大 alpha，把一般敏感性也一起收缩了。把一般敏感性作为跨 295 个药平均出来的低噪声目标单独预测，再由每个药的载荷分配，应能降低误差。预期增益小（零点几个百分点量级），在整组织场景（未见组织）可能更小或为负。

## 3. 数据、划分、评价（全部沿用 extra-supervision-20261008-0001）

- 421 开发细胞、同一 5 外折 × 3 内折（各 bank 的 fit/query 索引）、同一药物面板（新细胞 295；整组织每折 281–285）、同一 +19 额外样本（按 bank 已存的 `extra_indices`），同一评价（各折 `predictions.npz` 中的 truth、train_sd、evaluated）。
- 核：读取各 bank 已存的 `m_only_kernel/cross`、`virtual_fm_kernel/cross`、`L_protein`。组织核 T 与参考实现 `tissue_kernel.py` 相同。整组织场景的“原数据”臂取已存扩展核的前 n_fit 块（run_extra.py 已断言其与原核逐位相同）。
- 不读 64/123/CTRP/GBM99/原始 CSV；不修改任何旧 run。服务器 run 目录：`/public/home/mengxl/creed-research-runs/shared-crossdrug-20261009-0001/`。

## 4. 模型

每个 bank 的训练行 = fit 细胞（+额外样本），标签 Y（n×D，有缺失）。

1. 逐药标准化（只用训练行）：mu_d = 观测均值，sd_d = 观测 nanstd（下限 1e-8），Z = (Y − mu)/sd。只有观测数 ≥ 20 的药参与因子估计（与原基线 <20 回退到训练均值的规则一致；这些药在所有配置下都回退到训练均值）。
2. 共享因子 F（n×r），在训练行内估计：
   - `mean`：s_c = 细胞 c 所有已观测合格药物的 Z 的平均（r=1）。
   - `svd{r}`，r ∈ {1,2,3}：合格药物列的 Z，缺失处初值 0，迭代“rank-r SVD 重建 → 只替换缺失项”至相对变化 < 1e-7 或 300 次；F = U_r S_r。只在训练行内填补，不碰 query。
   - `perm`（对照）：把 `mean` 因子在训练细胞间按固定种子 20261009 随机置换，破坏细胞对应关系。
   - 没有任何合格观测的训练细胞不进入因子估计与因子 KRR。
3. 每药载荷：在该药的观测细胞上，Z_d 对 F 做带截距的最小二乘，得 B_d 与 Fbar_d（观测细胞上的 F 均值）。
4. 预测：
   `ŷ_qd = mu_d + sd_d · [ gamma · (F̂_q − Fbar_d)·B_d + KRR_{alpha_r}( Z_d − gamma·(F − Fbar_d)·B_d ) ]`
   其中 F̂_q 是用与基线相同的核（含组织核 / P 图有效核）对 F 做均值中心化 KRR（alpha_s），残差 KRR 与原基线的掩码均值中心化 KRR 完全相同。
5. 网格（每个核设置内的配置顺序）：先 4 个 gamma=0 配置（alpha_r ∈ {0.1,1,10,100}，即原基线），再对每个因子类型：gamma ∈ {0.5,1} × alpha_s ∈ {0.1,1,10,100} × alpha_r ∈ {0.1,1,10,100}（32 个）。多核设置时按参考实现的顺序拼接（w 外层、mu 内层）。因此回退索引 1 = (w=0, mu=0, gamma=0, alpha_r=1)，与原基线回退相同。

## 5. 臂

新细胞场景（+19 数据，M 核 bank）：

| 臂 | 部署输入 | 核设置 | 因子族 | 配置数 |
|---|---|---|---|---:|
| base_m（复现 extra__m_only） | M | K_M | — | 4 |
| base_mP（复现 extra__m_only__protein） | M | K_M + P 图 mu | — | 24 |
| base_mt（复现 m_tissue） | M+组织 | K_M + w·T | — | 12 |
| base_mtP（复现 m_tissue__protein） | M+组织 | K_M + w·T + P 图 | — | 72 |
| tissue_only（复现） | 组织 | T | — | 4 |
| **shared_m** | M | K_M | mean | 36 |
| sharedLR_m | M | K_M | svd1/2/3（逐药选 r） | 100 |
| sharedPerm_m（对照） | M | K_M | perm | 36 |
| **shared_mt** | M+组织 | K_M + w·T | mean | 108 |
| sharedLR_mt | M+组织 | K_M + w·T | svd1/2/3 | 300 |
| sharedPerm_mt（对照） | M+组织 | K_M + w·T | perm | 108 |
| shared_mP | M | K_M + P 图 | mean | 216 |
| shared_mtP | M+组织 | K_M + w·T + P 图 | mean | 648 |

整组织场景（M-only 部署；“FM”= 已存虚拟 FM 核，即 0.5·M 核 + 0.5·由 M 生成的虚拟 FM 核；部署只测 M）：

| 臂 | 数据 | 核设置 | 因子族 | 配置数 |
|---|---|---|---|---:|
| base_m（复现 extra__m_only） | +19 | K_M | — | 4 |
| base_fm（复现 extra__virtual_fm） | +19 | K_FM | — | 4 |
| base_fmP（复现 extra__virtual_fm__protein） | +19 | K_FM + P 图 | — | 24 |
| base_fm_orig（复现 original__virtual_fm） | 原数据 | K_FM | — | 4 |
| base_fmP_orig（复现 original__virtual_fm__protein） | 原数据 | K_FM + P 图 | — | 24 |
| shared_m | +19 | K_M | mean | 36 |
| **shared_fm** | +19 | K_FM | mean | 36 |
| sharedLR_fm | +19 | K_FM | svd1/2/3 | 100 |
| sharedPerm_fm（对照） | +19 | K_FM | perm | 36 |
| shared_fmP | +19 | K_FM + P 图 | mean | 216 |
| shared_fm_orig | 原数据 | K_FM | mean | 36 |
| shared_fmP_orig | 原数据 | K_FM + P 图 | mean | 216 |

另附零模型 null_drug（逐药训练均值，含额外样本）。

## 6. 选择规则与复现检查

- 选择：只用已存的 3 个内折 bank。每个配置、每个药：各内折 query 上标准化平方误差的均值（用该内折 fit 集（不含额外样本）的逐药 nanstd，下限 1e-8），3 个内折求和后除以有信息的内折个数，逐药取 argmin；无内折信息时回退索引 1。外折每套冻结的臂只评价一次。
- 复现检查（已在 repro 模式完成，只算了基线臂）：base_m、base_mP 与已存 grids（全部内外 bank）及 predictions 比较，最大差分别为 2.2e-14 / 4.2e-11；base_mt、base_mtP、tissue_only 与 tissue-kernel run 的外折预测差为 0；整组织场景 base_m、base_fm、base_fmP、base_fm_orig、base_fmP_orig 的 grids 与预测最大差 ≤ 3.9e-11。全部 ≤ 1e-8，通过。full 模式会再次重算并记录；若 full 模式中任一复现差 > 1e-8，则不报告新臂结论。另外 full 模式检查 z 空间实现的 gamma=0 预测与原始空间基线网格一致（记录 consistency）。

## 7. 主比较与判据（全部以 5 折均值 sRMSE，越低越好）

主比较（3 个）：
- **PC1 新细胞 M-only**：shared_m 对 base_m（extra__m_only，1.010662）。
- **PC2 新细胞 M+组织**：shared_mt 对 base_mt（m_tissue，0.996534）。
- **PC3 整组织 M-only**：shared_fm 对 base_fm（extra__virtual_fm，1.115144；同部署输入、同训练数据）。另外报告 shared_fm 对 base_fm_orig（original__virtual_fm，1.113467，同部署输入下最强的直接基线，但训练数据不同）；整组织场景要声称过推进线，两者都须满足。

每个比较报告：两臂 5 折分数、逐折相对改善、胜折数、均值相对改善 =(基线−新)/基线、Nadeau–Bengio 校正配对 t 检验（对 5 个逐折相对改善%；方差因子 1/5 + n_test/n_train，n_train = fit 细胞数 + 额外样本数，取 5 折平均；df=4；双侧）及 95% CI、留一折（去掉任一外折后的均值改善）、分组自助法 95% 区间（2000 次，种子 20261009；新细胞按细胞、整组织按组织在各测试折内重抽，药物在全部折上共同重抽）、Spearman 与 centered MSE。整组织场景另报五折共同 281 药面板的改善与胜折。

判定（与原推进线一致）：
- 改善 ≥ 1% 且胜折 ≥ 4/5：**过推进线（核心条件）**；
- 改善 > 0 但不满足上条：**小幅正向，未过线**；
- 改善 ≤ 0：**无增益**。
- 完整推进线还需同时满足：留一折改善全部 > 0；分组自助法 95% 区间下界 > 0；（整组织）281 面板改善 > 0 且 ≥ 4/5 折；对照 shared 对 sharedPerm 也改善且 ≥ 4/5 折（即增益不是由多出来的网格配置带来的）。任何一条不满足就如实写出。
- 3 个主比较的 NB p 值另报 Holm 校正。p < 0.05 才称“统计上显著”。
- “数值臂优于掩码臂”与“匹配蒸馏不能解释全部增益”两条针对 P/教师类方法，本方法不涉及，只在 P 图叠加臂中按原有 P 图结果说明，不另声称。

次要比较（只描述，不改变主判定）：sharedLR_m/mt/fm 对相应基线；P 图叠加 shared_mP 对 base_mP、shared_mtP 对 base_mtP、shared_fmP 对 base_fmP、shared_fm_orig 对 base_fm_orig、shared_fmP_orig 对 base_fmP_orig；整组织 shared_m 对 base_m。背景比较：shared_m 对当前候选 base_mP（1.006284）、shared_mt 对 tissue_only、shared_mtP 对 base_mt、shared_fmP(_orig) 对 base_fm_orig。对照：sharedPerm_* 对基线、shared_* 对 sharedPerm_*。

## 8. 不做的事

不删药、不删折、不删组织、不换指标、不加种子、不在外折上调任何东西。若结果为负，原样报告。所有结果都是反复使用过的开发外折上的 candidate_only 证据，不是独立确认。
