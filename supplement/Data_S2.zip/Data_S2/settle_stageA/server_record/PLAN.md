# SETTLE-F 第一阶段（功能度量）预注册协议

协议编号：SETTLE_STAGEA_V1
运行目录：`/public/home/mengxl/creed-research-runs/settle-stageA-20261011-0001`
注册时间：见 `PLAN_REGISTERED_AT.txt`。本文件、`code/` 全部文件与 `SHA256SUMS` 在任何外层（outer）分数产生之前写定；之后只允许在文末追加 ADDENDUM。
依据：`settle_proposal/TECH_SPEC.md` §3（2026-10-11）。偏离之处在 §7 逐条列出。

## 1. 问题

CREED 的免费虚拟层（H086：M→RNA / M→P 交叉拟合 KRR 生成器，512 个目标列）只追回约 1/3 的功能空间，且追回与重建 R² 不对应。本阶段检验两件事：

1. **度量假说**：把虚拟层按"对功能预测有用的方向"（教师模型的梯度外积 G，EGOP）表示后，追回份额能否明显提高；
2. **流程假说**：CREED 的 `kernel_state` 在送入预测头前逐列重新标准化虚拟列，抹掉了生成器的收缩。只去掉这一步（A2）能否带来同等提升。

## 2. 数据与边界（与 CREED 完全相同）

- 421 个开发细胞系；两个场景（new_cell 新细胞系、tissue 留出组织）；每场景 5 个外层折 × 4 个 bank（inner-0/1/2、outer），几何文件来自 `extra-supervision-20261008-0001/output`。
- 输入：`gdsc-metabolite-full-protein-20260908-0001/output/result/source-inputs.npz`（sha 52d71517…）、`rna421-20260906-0002`、extra19（sha d4e7dc60…），全部由冻结的 `crosslayer.py`（sha c1095b94…）的 `load_ctx()` 读取并校验。
- 终点：GDSC2 AUC（295 药）。CRISPR 终点见 §5。
- 64 验证集、123 封存集（已用过一次）、CTRP、GBM 一律不读取。
- 不下载任何数据。

## 3. 模型（预测头不变）

- 预测头：CREED 逐药均值中心化 masked KRR，核 = 0.5·K_M + 0.5·K_state，α ∈ {0.1, 1, 10, 100}，按 3 个 inner bank 的损失和逐药选择（回退索引 1），观测 < 20 时预测训练均值。全部调用冻结 `crosslayer.py` 的函数。
- 生成器：H086 的交叉拟合 KRR（M→Y，3 折 OOF，λ 按 OOF MSE 选），与 CREED 相同种子；训练行用 OOF 预测，查询行用全拟合预测。
- 教师：在每个 bank 的 fit 集上拟合 0.5·K_M + 0.5·K_Z（Z = 实测 512 目标列，CREED 的标准化与 `kernel_state`）；标签除以该 bank 的训练标准差；α_d 在 fit 集内部用与生成器相同的 3 折划分做交叉验证选出。
- EGOP：G = (1/(n·D)) Σ_i Σ_d ∇_z f_d(z_i) ∇_z f_d(z_i)ᵀ（只对 z 求导，M 固定；只用观测 ≥ 20 的药）。特征分解 G = UΣUᵀ，W_r = U_r Σ_r^{1/2}。
- 状态核：除 H086 与 T512 外，状态核一律为 RBF，**单一全局宽度**（fit 行两两平方距离正值的中位数），**不逐列标准化**。

## 4. 评估臂（Y ∈ {RNA, P}；两个场景；r ∈ {4, 8, 16, 32, 64}）

| 臂 | 送入预测头的状态 | 作用 |
|---|---|---|
| M | 只用 M | 参照 |
| H086 | M + vY（CREED 逐列标准化） | 要超过的基线；必须逐值复现 CREED |
| T512 | M + 实测 Z（512 列，CREED 标准化） | 教师空间 |
| CREED_M+Y | CREED 实测参照臂（RNA 3000 基因；P 值 + 缺失掩码） | 计算 room 与 share |
| **A1_r** | M + W_rᵀ ẑ | **主臂** |
| A2 | M + ẑ（不逐列标准化，恒等度量） | 流程假说 |
| A3_r | M + PCA_r(ẑ)（PCA 拟合于 fit 行实测 Z） | 压缩对照 |
| A4_r_s | M + 随机正交 r 维子空间（5 个种子） | 子空间对照 |
| A5_r_s | M + 标签行置换教师的 W_r（5 个种子） | 功能特异性对照 |
| A6_r | M + W_rᵀ z_measured | 压缩教师（不可部署，用于选 r） |
| A7_r | 配对打乱的生成器（与 CREED 相同打乱种子）+ 真实 W_r | 配对对照 |

**r 的选择（只用教师，不看任何学生臂）**：每个外层折、每个 Y，用 3 个 inner bank 的损失（各臂在 inner 上按 CREED 规则选 α 后的逐药损失均值，取所有臂都有值的药）计算 inner 分数；room_full = S(M) − S(T512)，room_r = S(M) − S(A6_r)。取满足 room_r ≥ 0.9 × room_full 的最小 r；都不满足则 r = 64。带 * 的臂（A1*、A3*、A4*、A5*、A6*、A7*）指该折选出的 r。

## 5. CRISPR 终点（第二步，本协议一并注册）

药敏终点完成后，以相同代码（替换为 `crispr-endpoint-20261009-0001` 的 bank 与标签）对 A1*、H086、A3*、A4*、A5*、A7* 运行一次；另加 A9b：用药敏 G 迁移到 CRISPR 头。判据见 §6 GO-A5。CRISPR 代码在运行前另行追加 ADDENDUM 并记 sha。

## 6. 预注册判据（结果一律报告，不设事后调整）

指标：sRMSE（CREED 定义）；Δ% = (S_H086 − S_arm)/S_H086 × 100，逐折计算后取 5 折均值；胜折数 = Δ > 0 的折数；Nadeau–Bengio 校正 t 检验作为辅助。share = 5 折平均 gain(arm vs M) ÷ 5 折平均 gain(CREED_M+Y vs M)。

- **GO-A1（新细胞系）**：对该 Y，A1* 的 5 折平均 Δ ≥ +0.25%，且 Δ > 0 的折 ≥ 4/5。
- **GO-A2（留出组织）**：5 折平均 Δ ≥ +0.15%，且 ≥ 4/5 折为正。
- **GO-A3（对照）**：新细胞系中，A1* 分别优于 A3*、A4* 种子均值、A5* 种子均值，各 ≥ 4/5 折。
- **GO-A4（配对）**：新细胞系中，A7* 相对 M 的增益 ≤ 0.5 × A1* 相对 M 的增益。
- **GO-A5（CRISPR）**：A1* 相对 H086 的 Δ > 0，≥ 4/5 折（两个场景分别报告）。
- **GO-A** = 某个 Y 上 GO-A1 至 GO-A5 全部成立。
- **PARTIAL**：若 GO-A1 成立但 |Δ(A2) − Δ(A1*)| < 0.05 个百分点，只报告"保留收缩的流程修正"，不报告"功能度量"。
- **NO-GO-A**：两个 Y 的 GO-A1 都不成立。
- **诊断 G0**（外层 bank，5 折平均；不作为 GO 条件）：
  - G0a：在 room > 0.3% 的格子上（6 个有序层对 × 2 场景），Spearman(FR², share) ≥ 0.5 且大于 Spearman(R², share)；少于 3 个格子时报告"不可评估"；
  - G0b：两个场景中 FR²(M→RNA) > FR²(P→RNA)；
  - G0c：W_r 拆半（药物随机分两半）子空间 cos² 在 r* 处 ≥ 0.5。

## 7. 与 TECH_SPEC 的偏离（运行前声明）

1. **G 不在 inner OOF 折内再交叉拟合**：每个 bank 只用其 fit 集计算一个 G，同时用于 fit 行与查询行状态。原因：不同折的特征向量存在符号与近简并旋转的不确定性，逐折不同的 W_r 会让同一核中的状态坐标互不可比。查询行（含外层测试行）的标签从不进入 G，因此外层分数无泄漏；这等同于"在训练集上做有监督降维再训练回归器"。
2. 教师 α_d 在 fit 集内部 3 折交叉验证选出（TECH_SPEC 写"inner-selected"，未指明方式）。
3. 教师的状态是 512 个 Z 列，不是 CREED 实测 RNA 臂的 3000 个基因；room 与 share 的分母仍用 CREED 的实测臂。
4. "Δ ≥ +0.25%，≥ 4/5 折"按 5 折均值 ≥ 阈值且 ≥ 4 折为正解释。
5. A9 的 CRISPR 部分放在第二步（§5）。

## 8. 运行规则

- 先跑 dryrun（只用 fold-0 的 inner bank，不产生外层分数）：要求 M、H086_RNA、H086_P 的 inner 损失与 CREED 保存值之差 ≤ 1e-10，EGOP 梯度有限差分相对误差 < 1e-5。
- 主运行：每个（场景，折）一个进程，`OMP_NUM_THREADS=4`。每折开始时断言 M、H086_RNA、H086_P 的外层预测与 CREED 保存值之差 ≤ 1e-8（写入 `fold_result.json`；不符则该折结果作废并报告）。
- 若在产生外层分数之前因软件错误崩溃：允许修复后重跑，先追加 ADDENDUM（原因、改动、前后 sha）。产生外层分数之后不得改任何臂、指标或判据。
- 结果写入 `output/`；台账行 H095 起。

## 9. 不做的事

不用 64/123；不加臂、不扩 r 网格、不换种子救结果；不把开发折结果称为外部验证。

---

## ADDENDUM 1（）：CRISPR 第二步的代码登记

- 按 §5，CRISPR 代码在运行前登记。、 均在药敏外层结果被读取之前写完； 于药敏运行期间上传并完成 dryrun（fold-0 inner-0，无外层分数）：分组 EGOP 与逐靶标循环相对差 1.05e-15；生成器 λ 与 R² 与 CREED CRISPR 运行完全一致（差 0）；2,461 个靶标；157 个臂。
- 药敏终点结果（§6）已产生：NO-GO-A（见 ）。按 §6，GO-A 已不可能成立；CRISPR 仍按 §5 运行一次并全部报告。
- 臂与 §4 相同（CRISPR 头），另加 A9b（同一 bank 的药敏 G 迁移到 CRISPR 头）。每折断言 M、H086_RNA、H086_P 外层预测与  保存值之差 ≤ 1e-8。
- 本 ADDENDUM 不改动 §4–§6。

## ADDENDUM 2（2026-10-11T12:50+0800）：更正 ADDENDUM 1 的文字

ADDENDUM 1 在追加时因 shell 引号把反引号内容当作命令执行，丢失了时间戳和文件名（内容事实不变）。完整文字如下：

- ADDENDUM 1 追加时间：2026-10-11T12:47:4x+0800（CRISPR 主运行于 12:47:44 开始，`run_crispr.log` 首行）。
- 登记的文件：`code/crispr_endpoint.py`（CREED CRISPR 运行的冻结副本，sha 58f7e0a5…）、`code/stageA_crispr.py`（sha 9a74d2a4…）、`code/analyze_crispr.py`（sha 5c5cddbf…）、`code/run_crispr.sh`（sha 5ebdf352…）；见 `SHA256SUMS_CRISPR`（其中 PLAN.md sha b2a06e7b… 对应含 ADDENDUM 1 的版本）。
- 药敏结果见 `output/RESULT_AUTO.md`；外层预测断言的比对对象是 `crispr-endpoint-20261009-0001/output/<scenario>/fold-<f>_predictions.npz`。
- 本 ADDENDUM 只更正文字，不改动任何代码、臂、指标或判据。
