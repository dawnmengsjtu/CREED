# "功能价值是低维的"前瞻性检验：预注册协议（草案）

协议编号：PROSPECTIVE_LOWDIM_V1
运行目录：`/public/home/mengxl/creed-research-runs/prospective-lowdim-20261022-0001`（必须原本不存在）
状态：已登记
注册时间：见 `PLAN_REGISTERED_AT.txt`（服务器 `date -Is`，UTC+08:00，即新加坡时间）。本文件、`INPUTS.env`、`code/` 全部文件与 `SHA256SUMS` 在任何外层（outer）预测与分数产生之前写定；之后只允许在文末追加 ADDENDUM（§10.4）。
本地草稿：`prospective_lowdim_20261022/`（2026-10-22 起草；未在服务器上运行过任何一行）。

---

## 0. 目的与要回答的问题

N6（`settle-stageA-20261011-0001`，预注册，结论 NO-GO）之后，对其已登记各臂的**事后**分析发现：把实测层投影到每个 bank 的 fit 集上学到的 4 个功能加权方向（教师 EGOP 的前 4 个特征方向，W₄ = U₄Σ₄^½），新细胞系药敏终点上仍保留 91%（RNA）/ 96%（P）的空间，跨两个终点、两个场景为 69%–137%；而虚拟层投影到同样 4 个方向只追回 20%–40%（Note S3；Table S15 最后两列）。论文将以"功能价值是低维的"为中心重写，这一发现必须变成**前瞻性、预注册**的结果。本 run 回答两个问题：

- **A（第三终点）**：在一个没有参与发现的终点——GDSC1 药物 AUC——上，预先写下的数值预测（空间存在、标准虚拟层份额、4 个方向的保留与追回、二者之差、面板律）是否成立？
- **B（方向引导面板）**：只用 fit 集学到的功能加权方向选分子（每个分子在前 4 个方向上的加权载荷），这样的面板在相同 k 下是否不劣于现有的监督求和面板、并优于随机面板？在药敏（GDSC2）与 CRISPR 两个终点、两个场景上检验。

本 run 不引入新的预测头、新的层编码、新的折、新的超参网格。只换标签（A）或只换"选哪些分子"（B）。

**诚实边界（写在最前面）**：B 部分以及 A 部分中药敏/CRISPR 的对照臂使用的是**已经被多次使用过的同一批 421 个开发细胞系和同一批 5 个外折**；"前瞻"只指"规则与判据在打分之前登记"，不是新数据。A 部分的 GDSC1 标签是新的，但细胞系、折、特征层不变，而且 GDSC1 与 GDSC2 有大量同名化合物（§3.3 D5、§7.4 的敏感性分析）。两者都不能称为外部验证。

## 1. 已知事实（来自已完成的运行；写本计划前已从本地镜像逐项核对）

### 1.1 N6 各格（drug = GDSC2 AUC；8 格 = 终点 × 场景 × 借用层）

来源：`settle_stageA_20261011/output{,_crispr}/<scenario>/fold-<f>/fold_result.json`（20 个文件，SHA-256 与 `server_record/OUTPUT_SHA256SUMS_server.txt` 一致；汇总脚本 `prospective_lowdim_20261022/figure_2H/build_fig2h_data.py`，其 r = 4 两列与 Table S15 完全一致）。share = 5 折平均 gain(臂 vs M) ÷ 5 折平均 room，room = gain(CREED 实测臂 M+Y vs M)。

| 终点 | 场景 | Y | room | 标准虚拟层份额 (H086) | 实测投影 r=4 (A6) | 虚拟投影 r=4 (A1) | 差 A6−A1 | 实测全 512 列 (T512) |
|---|---|---|---:|---:|---:|---:|---:|---:|
| drug | 新细胞系 | RNA | +3.079% | 0.343 | 0.909 | 0.297 | 0.612 | 0.963 |
| drug | 新细胞系 | P | +2.401% | 0.291 | 0.957 | 0.200 | 0.756 | 1.141 |
| drug | 留出组织 | RNA | +2.195% | 0.326 | 0.990 | 0.401 | 0.589 | 0.898 |
| drug | 留出组织 | P | +2.207% | 0.331 | 1.086 | 0.361 | 0.725 | 1.015 |
| CRISPR | 新细胞系 | RNA | +1.934% | 0.337 | 0.693 | 0.294 | 0.399 | 0.938 |
| CRISPR | 新细胞系 | P | +1.225% | 0.317 | 0.992 | 0.296 | 0.696 | 1.164 |
| CRISPR | 留出组织 | RNA | +1.282% | 0.304 | 0.938 | 0.312 | 0.626 | 0.997 |
| CRISPR | 留出组织 | P | +0.831% | 0.303 | 1.372 | 0.344 | 1.028 | 1.193 |
| **8 格均值 ± SD** | | | | 0.319 ± 0.018 | 0.992 ± 0.190 | 0.313 ± 0.059 | 0.679 ± 0.179 | 1.039 ± 0.112 |

- 实测投影 r = 4 相对 M 的增益：8 格全部 5/5 折为正。虚拟投影 r = 4：7 格 5/5，drug 新细胞系 P 为 4/5。
- 留一折（去掉一折重算份额）范围：A6 r=4 最低 0.636（CRISPR 新细胞系 RNA），A1 r=4 为 0.162–0.422。
- 拆半稳定性（药物随机分两半，前 r* 个方向的平均 cos²）：0.46–0.55。药敏学到的度量迁移到 CRISPR 头（A9b）比标准虚拟层差 0.12–0.24%。
- **N6 没有为"实测层投影"设任何对照**（PCA、随机子空间、标签置换度量只做在虚拟层上）。因此"4 个方向保留 91%/96%"目前不能区分"功能加权方向特殊"与"任何 4 维压缩都够"——本 run 补上（§5.1、§7.3）。

### 1.2 面板律与监督 vs 随机（现有面板 run）

| 终点 | 场景 | 蛋白 R(32) / R(64) | 基因 R(32) / R(64) | 监督 vs 随机（k = 16、32 合并的逐折相对差均值，NB se，胜折，双侧 p） |
|---|---|---|---|---|
| drug | 新细胞系 | 0.65 / 0.72 | 0.72 / 0.76 | 蛋白 +0.431%（0.108，5/5，0.016）；基因 +0.462%（0.248，4/5，0.136） |
| drug | 留出组织 | 0.66 / 0.74 | 0.78 / 0.76 | 蛋白 +0.320%（0.134，5/5，0.076）；基因 +0.471%（0.418，4/5，0.32） |
| CRISPR | 新细胞系 | 0.606 / 0.748 | 0.560 / 0.713 | 蛋白 +0.295%（0.172，4/5，0.16）；基因 +0.023%（0.134，3/5，0.87） |
| CRISPR | 留出组织 | 0.663 / 0.890 | 0.563 / 0.700 | 蛋白 +0.123%（0.080，4/5，0.20）；基因 +0.099%（0.134，4/5，0.50） |

来源：`protein_panel_20261009/fold_metrics_{new_cell,tissue}.csv`、`rna_panel_20261009/fold_metrics.csv`、`crispr_endpoint_20261009/fold_metrics.csv`、`crispr_endpoint_20261009/RESULT.md` §5；最后一列按 §6.3 的 NB 公式（r = 0.25）在本地重算。R(32) 8 格均值 0.650 ± 0.075，R(64) 0.754 ± 0.059。

## 2. 数据与边界（与 CREED、N6 完全相同）

- 421 个开发细胞系；两个场景（new_cell 新细胞系、tissue 留出组织）；每场景 5 个外层折 × 4 个 bank（inner-0/1/2、outer），几何文件 `extra-supervision-20261008-0001/output/<scenario>/fold-<f>/<bank>/geometry.npz`。
- 输入：`gdsc-metabolite-full-protein-20260908-0001/output/result/source-inputs.npz`（sha 52d71517…）、`rna421-20260906-0002`、extra19（sha d4e7dc60…，由冻结 `crosslayer.load_ctx()` 校验，不参与任何臂）、`crispr310-prepare-20260908-0001/output/result`（CRISPR）、GDSC2 原始表 `GDSC2_fitted_dose_response_24Jul22.csv`（sha 9d6dc82b…，只用于 §3.3 D0）、GDSC1 原始表（release 27Oct23，位于 `/public/home/mengxl/creed-assets/` 之下；确切路径与 sha256 在登记前写入 `INPUTS.env`，§12）。
- 只读的已保存输出（复现门与参照臂）：`crosslayer-matrix-20261009-0001/output`、`settle-stageA-20261011-0001/output{,_crispr}`、`crispr-endpoint-20261009-0001/output`、`protein-panel-20261009-0001/output/<scenario>_main`、`rna-panel-20261009-0001/output/<scenario>`。
- **64 个验证集细胞系、123 个封存 internal-final 细胞系、CTRP、GBM 一律不读取**。GDSC1 抽取的白名单就是 421 个开发 `sample_ids`（精确 SANGER_MODEL_ID），白名单之外的行只计数、不解析数值。
- 不下载任何数据；不安装任何软件包（xlsx 若无 openpyxl，用标准库读取器，§3.1）。
- 只写：运行目录（必须原本不存在）。

## 3. GDSC1 终点（A 部分）

### 3.1 抽取

`code/prepare_gdsc1.py` 的抽取函数是冻结 GDSC2 准备脚本（`gdsc421-20260906-0001/code/scripts/prepare_gdsc421.py` 的 `extract`）的逐行移植，只把 `DATASET` 的取值改成参数：精确 SANGER_MODEL_ID / DRUG_ID 连接；AUC、LN_IC50、MIN_CONC、MAX_CONC 必须有限且 0 < MIN_CONC ≤ MAX_CONC；冲突的重复键整对剔除、不取平均；缺失保持缺失；AUC 取原生拟合值，不做任何变换；药物列按 DRUG_ID 数值排序。文件可以是 .csv 或 .xlsx（有 openpyxl 用 openpyxl，否则用标准库按第一张工作表读取；整数单元格按 CSV 的写法转成不带 ".0" 的字符串）。

### 3.2 面板（可评估药物）规则，逐折、只看 fit

与主分析药敏端点相同：某药进入该外折的面板，当且仅当 outer fit 中观测 ≥ 80、outer fit SD > 1e-8，且 3 个 inner bank 的 fit 集中各观测 ≥ 20（保证 4 个 bank 都能拟合每个面板药）。同一外折的 4 个 bank 用同一面板。外层打分的"已评估药物" = 面板中 outer query 观测 ≥ 5 的药物。train_sd = max(outer fit nanstd, 1e-8)。

### 3.3 数据门（在任何模型拟合之前；D0–D4 任一不过 → A 部分不运行、如实报告，B 部分照常）

| 项 | 内容 | 通过条件 |
|---|---|---|
| D_sha | GDSC1 文件 sha256 | 等于 `INPUTS.env` 中登记的值 |
| **D0** | 抽取器复现：用同一移植函数重新抽取 GDSC2 24Jul22 | 药物 ID 序列与 `source-inputs.npz` 的 295 个相同；NaN 模式完全相同；最大绝对差 ≤ 1e-12（同一字符串解析，预期 0.0） |
| **D1** | 421 个开发细胞系中至少有 1 个有限 GDSC1 AUC 的细胞系数 | ≥ 300（CRISPR 终点为 310） |
| **D2** | 每个场景 × 外折：面板药物数、已评估药物数 | 两者都 ≥ 100 |
| **D3** | 每个场景 × 外折：带 ≥ 1 个 GDSC1 标签的测试细胞系数 | ≥ 40（CRISPR 为 49–68） |
| **D4** | 文件完整性：白名单行全部 DATASET = GDSC1；冲突重复键 / 观测对 | ≤ 5%（多名药物 ID、无效行如实报告） |
| D5 | 与 GDSC2 的重叠（只报告） | 相同 DRUG_ID 数；规范化药名（小写、去掉非字母数字）重叠数；同名药物对在共同细胞系上的 AUC Spearman 中位数 |
| D6 | 药名不重叠子集（只决定 §7.4 敏感性是否可评估） | 每个外折的面板中药名不在 GDSC2 面板里的药物 ≥ 50 |

预计值（未核实，不作为判据）：GDSC1 约 400 个 DRUG_ID、约 970 个细胞系；421 个开发系大部分有 GDSC1。

## 4. 冻结代码（原样导入，不改一个字节）

| 文件（`code/frozen/`） | SHA-256 | 来源 |
|---|---|---|
| crosslayer.py | c1095b941bdb92b335175291fc5a039f99d7c62b0fdb339e80db2817d11f0da3 | crosslayer-matrix / N6 |
| crispr_endpoint.py | 58f7e0a5125095b1facde16ce8a04b6db1ae70ca33a96076a4aa023670059b56 | crispr-endpoint / N6 |
| stageA.py | f94ab897588ab58cbec2adf4197553ae9b8eb730f8164c4c46563e165cb8dfc6 | N6（药敏） |
| stageA_crispr.py | 9a74d2a4288c8f79b2861e69eeba08f82b7a893d5b00f240f262ed4e3d21f397 | N6（CRISPR） |
| protein_panel.py | c38955610489c859d7c7b7d9c49de0c6bedf94427ff785f228cd6194d3b4f1dc | protein-panel-20261009-0001 |
| rna_panel.py | dea8e99d553382ab693cf03249696761aaa43f6fbcc956d4af215d8b4c8ffa39 | rna-panel-20261009-0001 |

这些哈希与各原 run 服务器 `SHA256SUMS` 中登记的值相同（`code/FROZEN_SHA256SUMS`）。新代码（哈希在登记时写入 `SHA256SUMS`）：`code/prepare_gdsc1.py`（§3）、`code/lowdim.py`（逐折：dryrun / main / score）、`code/analyze.py`（§6–§8）、`code/run.sh`（唯一调用）、`code/register.sh`（登记）、`code/preflight.sh`（登记前检查输入是否齐全，不读数值）。

`lowdim.py` 只调用冻结函数：层编码 `layer_inputs`、生成器 `generator`、核 `rbf_pair`、头 `predict_grid`、内折损失 `bank_losses`、选择 `choose`/`take`、指标 `metrics`、`measured_z`、`egop`、`wr`、`gw_pair`、`rand_orth`、面板规则 `candidates`/`spearman_scores`/`spearman_scores_dense`/`protein_kernel`/`rbf_pair`（药敏）与 `p_candidates`/`panel_weights`/`protein_panel_kernel`/`gene_panel_kernel`（CRISPR）、`evaluated_mask`、`stable_seed`。药敏与 GDSC1 走 crosslayer.py / stageA.py 路径，CRISPR 走 crispr_endpoint.py / stageA_crispr.py 路径（与 N6 相同）。新写的只有：GDSC1 标签与面板规则（§3）、实测层投影的三个对照（§5.1）、方向引导面板的选择规则（§5.2）。

## 5. 臂（预注册，不增不减；每个 bank 都按同一规则构建，α 按 3 个 inner bank 逐靶标选择，回退索引 1）

所有臂的头：逐靶标均值中心化 masked KRR，核 = 0.5·K_M + 0.5·K_状态。功能加权方向：每个 bank 在其 fit 集上计算一次 EGOP G（教师 0.5·K_M + 0.5·K_Z，Z = 实测 512 目标列，只对 z 求导，只用观测 ≥ 20 的靶标；N6 §3 的定义，`stageA.egop` / `stageA_crispr.egop`），G = UΣUᵀ，W_r = U_rΣ_r^½。查询行（含外层测试行）的标签从不进入 G。投影臂的状态核为单一全局宽度 RBF、不逐列标准化（N6 规则）。

### 5.1 低维臂（三个终点、两个场景、Y ∈ {RNA, P}）

| 臂 | 状态 | 作用 |
|---|---|---|
| M | 只用 M | 参照 |
| H086_Y | M + 虚拟 Y（CREED 逐列标准化） | 标准虚拟层；药敏/CRISPR 为复现臂 |
| A6_Y_r（r ∈ {4, 8, 16, 32, 64}） | 实测 Z 投影到 W_r | 实测保留（N6 同名臂） |
| A1_Y_r（同上） | 虚拟 Z 投影到同一 W_r | 虚拟追回（N6 同名臂） |
| **A6pca_Y_r4** | 实测 Z 投影到 fit 行实测 Z 的前 4 个主成分 | **新**：无监督 4 维压缩对照 |
| **A6rand_Y_r4_s**（5 种子） | 实测 Z 投影到随机正交 4 维子空间（与 N6 A4 相同种子、相同子空间） | **新**：子空间对照 |
| **A6perm_Y_r4_s**（5 种子） | 实测 Z 投影到标签行置换教师的 W₄（与 N6 A5 相同种子） | **新**：功能特异性对照 |
| A5_Y_r4_s（5 种子） | 虚拟 Z 投影到置换 W₄ | N6 同名臂（药敏/CRISPR 为复现臂） |
| A9b_Y_r4（仅 CRISPR） | 虚拟 Z 投影到药敏标签学到的 W₄ | N6 同名臂（复现臂） |
| 仅 GDSC1：M+RNA、M+P、M+Pval、H086_Y_shuf、T512_Y | crosslayer 编码的实测参照、配对置乱生成器、全 512 列实测 | GDSC1 的 room 分母、面板教师、置乱对照 |

room 的分母（CREED 实测臂 M+Y）：药敏取 crosslayer 保存的 `pred__M+RNA` / `pred__M+P`（与 N6 相同），CRISPR 取 crispr-endpoint 保存的同名预测，GDSC1 在本 run 中用同一编码计算。

### 5.2 面板臂（三个终点、两个场景；层 t ∈ {P 蛋白, G 基因}；k ∈ {8, 16, 32, 64}）

| 臂 | 选择规则（只用该 bank 的 fit 行） | 候选池 |
|---|---|---|
| SUP_t_k | 现有监督求和规则：w_j = Σ_d \|Spearman(分子 j, 靶标 d)\|（逐对完整观测，< 10 对计 0），取前 k。药敏/GDSC1 用 protein_panel.py / rna_panel.py 的实现，CRISPR 用 crispr_endpoint.py 的实现（靶标 = 该 bank 的可评估基因） | 现有池：蛋白 = fit 观测率 ≥ 90% 且方差 > 0；基因 = fit 方差前 3,000 |
| RND_t_k_s（5 种子） | 现有随机配方，扩展到 k = 8、64：药敏/GDSC1 为 `default_rng([20261009, 场景, 折, bank, s]).permutation(池)` 取前 k（种子内嵌套）；CRISPR 为 `default_rng([20261009, 场景, 折, bank, s, 层]).choice(池, k, replace=False)` | 现有池 |
| **DIR_t_k** | **方向引导**：对实测 Z 的每一列 j 计算 ℓ_j = Σ_{i≤4} λ_i U_{ji}²（= W₄ 第 j 行的平方范数，即该分子在前 4 个功能加权方向上的加权载荷），取 ℓ 最大的 k 个；稳定排序；t = P 用 Y = P 的 G，t = G 用 Y = RNA 的 G；G 来自该终点自己的标签 | Z 的 512 列（RNA：fit 方差前 512 基因；P：fit 观测率 ≥ 50% 中均值填补后方差前 512 蛋白） |
| SUP512_t_k | 监督求和规则，但限制在 DIR 的 512 列池内 | 512 列池 |
| RND512_t_k_s（5 种子） | `default_rng([20261022, 场景, 折, bank, s, 层]).permutation(512 列池)` 取前 k | 512 列池 |
| DIRx_t_k（仅 CRISPR） | 同 DIR，但 ℓ 来自同一 bank 上用药敏标签学到的 G | 512 列池 |

面板核：所选分子上的 RBF（蛋白先 fit 均值填补；fit z-score、fit 中位数宽度），头在 0.5·K_M + 0.5·K_panel 上重训——与现有面板 run 逐字相同（药敏蛋白面板用保存的 M 核块，基因面板与 CRISPR 用重算的 M 核，与各原 run 一致）。教师：蛋白面板 = 药敏为 protein-panel 保存的"M + 实测 P 值"教师、CRISPR 与 GDSC1 为 M+Pval；基因面板 = M+RNA。

池的不同（SUP 用现有池，DIR 只能在 512 列中选）是 SUP 与 DIR 比较的混杂因素；SUP512 / RND512 把"规则"与"池"分开（§8.2 次要比较）。

## 6. 指标与统计（与论文相同）

### 6.1 指标
sRMSE（CREED 定义：逐靶标 MSE 按 train_sd 标准化，对已评估靶标取均值后开方；5 折算术平均）。次指标：同靶标跨细胞 Spearman、centered MSE。缺失从不置零。

### 6.2 相对改善与份额
逐折 d_f = (S_base,f − S_arm,f)/S_base,f × 100；gain = 5 折均值；胜折 = d_f > 0 的折数。room = gain(M+Y vs M)；share(arm) = gain(arm vs M) ÷ room，**只在 room ≥ 0.3% 时定义**（与 Figure 2 相同），否则该格的份额类预测记为"不可评估"并按未通过计。R(k) = (S̄_M − S̄_panel,k)/(S̄_M − S̄_teacher)，S̄ 为 5 折均值。

### 6.3 Nadeau–Bengio 校正配对 t
se = sqrt((1/5 + n_test/n_train) · var(d, ddof=1))，n_test/n_train 取 5 个外折 query 与 fit 细胞数均值之比（≈ 0.25；与 N6 analyze.py 相同），t = mean(d)/se，df = 4。报告双侧 p、单侧 p 与 95% 区间。不做多重比较校正（如实声明）。

## 7. 预注册预测 A：GDSC1（4 个格 = 2 场景 × Y ∈ {RNA, P}；P6 的 4 个格 = 2 场景 × 面板层）

### 7.1 阈值的统一规则
区间类阈值 = §1.1 中 8 个已知格的"均值 ± 2 SD"，向外取整到 0.05；当 8 格的 SD 小于 0.05（单格份额的抽样噪声量级：A1 r=4 的留一折半幅约 0.01–0.06）时，SD 取 0.05。单侧阈值取同一规则的一侧。理由：阈值只由已知结果按一条事先写定的规则产生，不挑选；±2 SD 给一个新终点留出跨终点差异的余地，同时仍可能被数据否定。

### 7.2 预测与理由

| 编号 | 预测（每格判定） | 阈值的来源 |
|---|---|---|
| **P1 空间在 M 行** | room > 0 且 ≥ 4/5 折为正 | 8 个已知格全部 5/5（+0.83% 至 +3.08%）；与 CRISPR 计划 R1 相同 |
| **P2 标准虚拟层约追回三分之一** | H086 份额 ∈ [0.20, 0.45]，H086 对 M ≥ 4/5 折胜，且对自己的配对置乱对照 ≥ 4/5 折胜 | 0.319 ± 2×0.05（SD 0.018 取下限 0.05）= [0.219, 0.419] → [0.20, 0.45]；比封存集 F4 的 [0.15, 0.55] 窄 |
| **P3 4 个功能加权方向保留大部分空间** | A6 r=4 份额 ≥ 0.60，且 A6 r=4 对 M ≥ 4/5 折胜 | 0.992 − 2×0.190 = 0.611 → 0.60；8 格最小 0.693，留一折最小 0.636 |
| **P4 虚拟层在同样 4 个方向上只追回少部分** | A1 r=4 份额 ∈ [0.15, 0.45] | 0.313 ± 2×0.059 = [0.195, 0.432] → [0.15, 0.45] |
| **P5 缺口在"从代谢物预测少数方向"** | A6 r=4 份额 − A1 r=4 份额 ≥ 0.30 | 0.679 − 2×0.179 = 0.322 → 0.30；8 格最小 0.399 |
| **P6 面板律** | 现有监督面板 R(32) ≥ 0.50 且 R(64) ≥ 0.50（蛋白、基因各自判定） | R(32)：0.650 − 2×0.075 = 0.50；R(64) 沿用 CRISPR 计划 R4 与封存集 F5 的 0.50（同一规则会给 0.60，此处取已登记过的较宽值以保持跨 run 一致） |

**每个预测的判定**：4/4 格成立 → 确认；2–3/4 → 部分；0–1/4 → 未确认。
**A 部分总判定**：P1、P3、P5 三项都"确认" → "低维规律在 GDSC1 上复现"；同时报告"n/6 项确认"。P2、P4、P6 不影响这一总判定，但必须全部报告。

### 7.3 次要预测（三个终点都算；对药敏与 CRISPR 是新臂，对 GDSC1 是新终点）

- **S1（对照）**：在每个格（3 个终点 × 2 场景 × 2 层 = 12 格），A6 r=4 的 sRMSE 低于随机 4 维子空间的种子均值（≥ 4/5 折），也低于标签置换度量的种子均值（≥ 4/5 折）。≥ 10/12 格成立 → 确认。依据：虚拟层的同类对照（N6）在药敏 4 个格中 A1* 胜随机子空间 5/5、5/5、5/5、4/5 折，胜置换度量 4 格都是 5/5 折；8 个格中随机与置换的份额只有 5–22%（Table S15）。
- **S2（PCA）**：A6 r=4 对 A6pca r=4 **不作方向性预测**，只报告胜折与 NB t。依据：虚拟层上功能加权方向与 PCA 方向打平（N6 新细胞系 2/5 折）。若实测层上也打平，"4 个方向"的说法须改为"4 维压缩"，"功能加权"不能写进标题。
- **S3（描述）**：r 曲线（r = 4…64）、GDSC1 拆半 cos²、GDSC1 与 GDSC2 前 4 方向子空间的 cos²、CRISPR 与药敏的 cos²。

### 7.4 敏感性（GDSC1，只报告）
只用"药名不在 GDSC2 面板中"的 GDSC1 药物（D6 可评估时）重算 P1–P5 的数值（逐靶标 MSE 重新汇总，α 选择不变）。若主结果成立而这一子集不成立，只能写"在 GDSC1 上成立，主要由与 GDSC2 共有的化合物承载"。

## 8. 预注册预测 B：方向引导面板

### 8.1 主比较（8 个格 = {药敏, CRISPR} × 2 场景 × {蛋白, 基因}）
每折在相同 k 下配对：d^sup_{f,k} = (S_SUP,k − S_DIR,k)/S_SUP,k × 100，d^rnd_{f,k} = (S̄_RND,k − S_DIR,k)/S̄_RND,k × 100（S̄_RND 为 5 个种子的折分数均值）。主检验把每折的 4 个 k 取平均（d̄_f = mean_k d_{f,k}，每个 k 都是等 k 配对），再做 NB 校正 t（df = 4）。逐 k 的检验作为次要结果全部报告。

- **B1 不劣于监督面板**：非劣效界 δ = 0.25 个百分点。
  - PASS：d̄^sup 的单侧 90% 下界（mean − t₀.₉₀,₄·se）> −0.25；
  - WORSE：未 PASS 且单侧 95% 上界（mean + t₀.₉₅,₄·se）< 0（显著更差）；
  - INCONCLUSIVE：其余。另对每格报告"是否显著更低"。
  - **B1 总判定**：任何一格 WORSE → "劣于监督面板"；无 WORSE 且 PASS ≥ 4/8 格 → "不劣于监督面板（确认）"；其余 → "不确定（功效不足）"。
- **B2 优于随机面板**：d̄^rnd 均值 > 0、≥ 4/5 折为正、NB 双侧 p < 0.10（即预测方向上单侧 p < 0.05）。
  - **B2 预测**：在药敏的两个蛋白格（新细胞系、留出组织）PASS；两格都 PASS → "在预测之处优于随机（确认）"。另报告方向性：d̄^rnd 均值 > 0 的格 ≥ 6/8 → "方向确认"。
  - 其余 6 格**不预测**显著性：现有监督面板本身在药敏基因格（双侧 p 0.14、0.32）与 4 个 CRISPR 格（0.16–0.87）都没有显著优于随机（§1.2；CRISPR 上为已登记阴性 N5）。

**δ 与 ≥ 4/8 的理由**：δ = 0.25 pp 约为药敏上监督相对随机的合并优势（0.32–0.47 pp）的一半到四分之三——方向引导若损失超过这个量，就丢掉了"挑选"带来的大部分好处。功效：按 §1.2 的 NB se，若 DIR 与 SUP 真实相等（均值 0），只有 se < 0.163 的格能 PASS；8 格中有 5 格的 se 在 0.080–0.134，3 格在 0.172–0.418。故"≥ 4/8 PASS"是在 DIR ≡ SUP 时可以达到、而 DIR 明显更差时难以达到的门槛；se 大的格预计为 INCONCLUSIVE，这要如实写出。

### 8.2 次要比较（全部报告，不设判定）
逐 k 的 DIR vs SUP、DIR vs RND；SUP vs RND（现有结论在 k = 8…64 上的重复）；DIR vs SUP512、DIR vs RND512、SUP512 vs RND512（规则 vs 池）；DIRx vs DIR（CRISPR：药敏方向迁移）；各臂 R(k)；GDSC1 上的 B1/B2（描述）；DIR 所选前 64 个分子与 SUP 前 64 的重叠数（逐 bank 写入 `bank_info.json`）。

## 9. 复现门（硬门；先过门，后打分）

| 门 | 阶段 | 内容 | 容差 |
|---|---|---|---|
| G0 | 开始 | `sha256sum -c SHA256SUMS`（PLAN、INPUTS.env、全部代码，含冻结文件） | 全部 OK |
| G1 | 每个 bank | M 核块与保存的 `m_only_kernel` / `m_only_cross` | rtol 1e-11、atol 1e-12（冻结代码的断言） |
| G1 | 每个 bank | 生成器 M→RNA、M→P（GDSC1 另含两个置乱生成器）的 λ、OOF R² 均值/中位数、虚拟核宽度 vs crosslayer `bank_info.json` | λ 完全相同；其余 ≤ 1e-9 |
| G2 | dryrun | 药敏 fold-0 inner-0：M、H086_RNA、H086_P 的内折损失 vs crosslayer `fold-0_inner_losses.npz`；EGOP 有限差分（`stageA.fd_test`）；CRISPR：分组 vs 逐靶标 EGOP（`stageA_crispr.fd_test`）；监督面板的选择（药敏蛋白前 64、基因 k = 8…64 面板、CRISPR 前 8）vs 保存值 | 损失 ≤ 1e-10；相对误差 < 1e-5 / < 1e-8；选择完全相同 |
| **G3** | 每个外折（药敏） | 外层预测 vs 保存值：M、H086_RNA、H086_P（crosslayer）；A6_Y_r4、A1_Y_r4、A5_Y_r4_s0–4（N6）；SUP_P_k8–64、RND_P_k16/32_s0–4（protein-panel）；SUP_G_k8–64、RND_G_k16/32_s0–4（rna-panel） | 最大绝对差 ≤ 1e-8 |
| **G4** | 每个外折（CRISPR） | 外层预测 vs crispr-endpoint 保存值：M、H086、SUP_{P,G}_k8–64、RND_{P,G}_k16/32_s0–4；外层分数 vs N6 `fold_result.json`：A6/A1/A9b_Y_r4、A5_Y_r4_s0–4 | 预测 ≤ 1e-8；分数 ≤ 1e-10 |

**9.1** 门的顺序：`main` 阶段只产生外层**预测**并做 G1/G3/G4；它不读取任何新臂与真值的比较。只有当药敏与 CRISPR 的 20 个外折全部过门，`score` 阶段才对任何臂打分；GDSC1 只有在其 10 个外折的 G1 也全部通过时才打分。
**9.2** 不符则停：写 `GATE_FAILED.json`，不打分，报告最大差异。允许的唯一处理是 §10.4 的 ADDENDUM（例如线程数导致的 1e-8 以上差异，改为原 run 的线程数后重跑），不允许放宽容差。
**9.3** 线程数与原 run 相同：每个进程 `OMP_NUM_THREADS = OPENBLAS_NUM_THREADS = MKL_NUM_THREADS = 4`（N6 `code/run.sh` 的设置），以免 BLAS 线程数改变末位舍入、经近简并的 EGOP 特征向量放大后破坏 G3/G4。

## 10. 运行规则

**10.1 一次调用**：唯一入口 `bash code/run.sh`（在 tmux/screen 中），按固定顺序：G0 → GDSC1 数据门（§3.3）→ dryrun（每个终点 × 场景的 fold-0 inner-0；无外层 bank）→ main（30 个"终点 × 场景 × 折"任务：外层预测 + 门）→ score → analyze → `OUTPUT_SHA256SUMS`。无自动重试。
**10.2 资源**：每个任务 `OMP_NUM_THREADS = OPENBLAS_NUM_THREADS = MKL_NUM_THREADS = 4`（与 N6 相同）；同时运行 `JOBS` 个任务（默认 10，即 40 线程，与 N6 的 10 × 4 线程相同）。Python：`/public/home/mengxl/.conda/envs/CellFM/bin/python`（与 N6 及各面板 run 相同；internal-final 回执记录为 numpy 2.0.2 / scipy 1.13.1，运行时版本写入 `logs/env.txt`）。
**10.3** 数据门失败只停 A 部分；dryrun 任一失败 → 全部停止（没有任何外层预测）；药敏或 CRISPR 任一外折过不了门 → 不打任何分。
**10.4 ADDENDUM**：只能追加于文末；只允许用于**打分之前**的软件错误、路径错误或环境问题；每条注明时间（新加坡时间）、原因、改动文件与前后 sha256，并保留失败日志。打分之后不得改任何臂、指标、阈值或判定规则；崩溃时已产生的分数即为最终结果，未产生的报告为"未计算"。
**10.5** 所有结果无论方向一律报告；阴性结果按论文"预注册阴性"的写法处理。

## 11. 产出

服务器 `prospective-lowdim-20261022-0001/`：`PLAN.md`、`PLAN_REGISTERED_AT.txt`、`INPUTS.env`、`SHA256SUMS`、`code/`、`run.log`、`logs/`、`data_gdsc1/`（GDSC1 矩阵、面板、`data_gate.json`、同名药物对表）、`dryrun/<终点>-<场景>/summary.json`、`output/<终点>/<场景>/fold-<f>/{protocol.json, gate.json, bank_info.json, predictions.npz, fold_result.json, per_target.npz}`（CRISPR 的 predictions.npz 每折约 250–300 MB）、`analysis/{analysis.json, RESULT_AUTO.md, figure_2H_prospective.csv, panel_comparisons.csv, cells_A.csv}`、`OUTPUT_SHA256SUMS`。本地 `prospective_lowdim_20261022/`：取回 `analysis/`、`dryrun/*/summary.json`、各折 `gate.json` 与 `fold_result.json`、`data_gdsc1/data_gate.json`，写中文 `RESULT.md`。

## 12. 登记前必须完成的事（顺序不可颠倒）

1. `bash code/preflight.sh`：所需输入与已保存输出齐全（`missing files: 0`），6 个冻结文件与原 run 的服务器副本逐字节相同。
1b. **登记前冒烟测试（工程检查，不产生任何外层预测或分数）**：把 `code/` 复制到单独目录 `creed-research-runs/prospective-lowdim-20261022-smoke/`，以 `LOWDIM_RUN` 指向该目录、每进程 4 线程，只对 drug 与 crispr 两个终点 × 两个场景运行 `lowdim.py … dryrun`（fold-0 inner-0）。这两个终点的数据与 inner bank 已在此前的 run 中全部用过，不带来任何新信息；GDSC1 不参与。目的只是在登记前发现代码错误（新代码此前未执行过）。冒烟目录的日志与 `summary.json` 保留，在 RESULT 中报告；冒烟后若改动任何代码，改动在登记前完成并在本节记录。
1c. GDSC1 文件只读表头（列名）与行数，用于确认 `prepare_gdsc1.py` 所需的列存在；不解析任何数值。
   **登记前已发现并修正（2026-10-22 新加坡时间上午）**：GDSC1 27Oct23 的 xlsx 不含工作表尺寸信息，openpyxl 只读模式只返回 A1，`prepare_gdsc1.py` 会把它当作表头不符而让数据门失败。已在 `iter_records` 中读之前调用 `ws.reset_dimensions()`；修正后只统计读取器产出的记录条数（不输出、不分析数值），应等于表头之后的 333,161 行。
   **冒烟测试结果**（`prospective-lowdim-20261022-smoke/`，2026-10-22T08:54:50+08:00 至 08:56:25+08:00，每进程 4 线程）：drug 与 crispr × 两个场景的 dryrun 全部通过——生成器 λ/R²/宽度差 0.0；药敏内折损失对 crosslayer 最大差 ≤ 1.1e-14；EGOP 有限差分最大相对误差 ≤ 2.0e-7；CRISPR 分组与逐靶标 EGOP 相对差 ≤ 1.1e-15；监督面板选择与保存值完全相同。修正 xlsx 读取后读取器产出 333,161 条记录。冒烟之后代码未再改动。
2. 在服务器上找到 GDSC1 27Oct23 文件，填 `INPUTS.env`（`GDSC1_FILE`、`GDSC1_SHA256`、`GDSC2_FILE`）。只看文件名、大小、sha256，**不打开数值**。
3. 本文件状态行改为"已登记"并删去括注，改名 `PLAN.md`（register.sh 会检查括注已删除）。
4. `bash code/register.sh`：校验冻结文件哈希与两个原始表的 sha，写 `SHA256SUMS` 与 `PLAN_REGISTERED_AT.txt`，把计划、输入与代码设为只读。
5. 之后才运行 `bash code/run.sh`。

## 13. 预先声明的局限（结果好坏都要写）

1. **非独立数据**：同一 421 个细胞系、同一 5 个外折、同一特征层；B 部分与药敏/CRISPR 的对照臂是在已用过多次的折上做的新分析。
2. **GDSC1 不是独立终点**：同一实验室、同一批细胞系的早期筛选，大量化合物与 GDSC2 同名（D5 报告重叠，§7.4 做药名不重叠的敏感性）。
3. **方向是有监督的**：W₄ 用了 fit 行的标签。A6 r=4 的高保留可能部分来自"有监督降维 + 头"的组合本身；S1/S2 的对照用来区分，S2 打平时措辞必须降级。
4. **核不同**：投影臂用单一宽度 RBF，room 的分母用逐列标准化 RBF；份额 > 1 的格说明分母保守（N6 已见 110–137%）。T512 与 A6 r=64 一并报告。
5. **池不同**：DIR 只能在 512 列中选，SUP 在约 1,800 个蛋白 / 3,000 个基因中选；SUP512/RND512 用来区分规则与池。
6. **功效有限**：5 折、df = 4；B1 在 se 大的格预计不确定；不做多重比较校正。
7. **线程数**：与原 run 相同（每进程 4 线程，§9.3）。
8. 留出组织场景的 F1 折（造血与淋巴等）主导 5 折均值（Note S2）；CRISPR 留出组织场景中 M 与 null 无差（crispr-endpoint RESULT §3）。
9. 阈值来自已知 8 格的离散度；若 GDSC1 的真实份额与已知格系统不同，区间预测会失败——这是预注册想要的可证伪性，不是缺陷。

## 14. 不做的事

不用 64/123；不加臂、不扩 r 或 k 网格、不换种子救结果；不在看到分数后更换 δ、阈值或判定规则；不把开发折结果称为外部验证；不把 B 部分的结论推广到"测哪些分子是生物学上最重要的"（只是预测意义上的选择规则）。

---

## ADDENDUM 1（2026-10-22，新加坡时间下午追加；打分之前）

**原因**：`run.sh` 于 2026-10-22T09:33:55+08:00 报告 `GATES_PASSED … scoring: drug crispr gdsc1`，即三个终点、两个场景、30 个外折的 main 阶段全部过门（G1/G3/G4），没有任何 `GATE_FAILED.json`。随后 score 阶段的 30 个任务全部在 `lowdim.py` `score_fold` 的第一行断言处以 `KeyError: 'passed'` 退出：`main_fold` 把判定写在 `gate.json` 的 `gate.passed` 之下，而 `score_fold` 读取顶层键 `passed`。`run.sh` 的 `set -e` 使脚本在不打印 STOP 的情况下终止。**没有产生任何 `fold_result.json` 或 `per_target.npz`，即没有计算任何外层分数**；分析（`analysis/`）与 `OUTPUT_SHA256SUMS` 也未产生。失败日志原样移至 `logs/failed_score_attempt1/`。

**改动（属 §10.4 允许的"打分之前的软件错误"）**：
- `code/lowdim.py` 一行：`assert g['passed'] is True …` → `assert g['gate']['passed'] is True …`。sha256：`9ddd2ca6d3906253b4dc876df18485e2067cb2f43d74bdc2eb0b9b09a674a9ed` → `ff5a5d3381bd34dcbba71b86e7db1dfef2503afc3c08b3ce4372972f1ca01958`。
- 其余代码（含 `analyze.py`、`run.sh`、全部冻结文件）、臂、指标、阈值、判定规则一律不变。
- 新增 `code_addendum1/resume_after_addendum1.sh`：重新核对 30 个 `gate.json` 的 `gate.passed` 后，原样执行 `run.sh` 的第 4–6 阶段（score → analyze → `OUTPUT_SHA256SUMS`），线程与并行数同 `run.sh`（每进程 4 线程、JOBS = 10），每个失败点都打印 STOP。输出写入 `run_resume.log`，`run.log` 保持原样。
- 新增 `code_addendum1/synthetic_test.py`（工程检查，见下）。

**续跑前的工程检查（未使用任何真实分数）**：在冒烟目录 `prospective-lowdim-20261022-smoke/synthetic_addendum1/` 中，2026-10-22T17:22:07+08:00 至 17:24:54+08:00：
- (A) 三个终点各取 new_cell fold-0，把 `predictions.npz` 中的真值矩阵换成同形状、同缺失模式的随机数，运行修正后的 `score_fold`：drug、crispr、gdsc1 均正常写出 `fold_result.json` 与 `per_target.npz`。
- (B) 用 `gate.json` 的臂列表与 `predictions.npz` 的列表（只读 `cols`、`evaluated` 两个成员）生成 30 折随机 `fold_result.json` / `per_target.npz`，运行未改动的 `analyze.py`：正常写出 `analysis.json`、`RESULT_AUTO.md`、`cells_A.csv`、`figure_2H_prospective.csv`、`panel_comparisons.csv`；仅在 room < 0.3% 的格中出现 nan，符合 §6.2"份额只在 room ≥ 0.3% 时定义"。

**登记**：`ADDENDUM1_SHA256SUMS` 记录追加本节后的 `PLAN.md`、修正后的 `code/lowdim.py` 与 `code_addendum1/` 全部文件；时间见 `ADDENDUM1_REGISTERED_AT.txt`。原 `SHA256SUMS` 与 `PLAN_REGISTERED_AT.txt` 不变（其中 `code/lowdim.py` 与 `PLAN.md` 两行对应登记时的原始版本）。
