# RNA 学习曲线与 354 RNA–GDSC 加标签门控（方向 C 第一步），附第二步伪标签蒸馏：预先登记

登记时间：2026-10-09。在计算任何新臂的外折分数之前写下。写完后计算 sha256，并复制到服务器 run 目录。之后不按结果修改本文件；如果出现 bug，只在文末追加 ADDENDUM，说明原因，并重跑全部臂。

服务器 run 目录：`/public/home/mengxl/creed-research-runs/rna-learning-curve-20261009-0001/`
本地目录：`/Users/xlzhexue/Desktop/proj/creed/rna_learning_curve_20261009/`

## 0. 要回答的问题

1. 在与 M 系结果完全相同的外折、内折和面板上，RNA-only 的 sRMSE 是多少？它比 M 直接基线（original__m_only，新细胞 1.012045，整组织 1.120206）好还是差？这也用来核对台账 H067 的 RNA-only 1.089676 是否能和 M 系结果直接比较。
2. RNA-only 的学习曲线（原 fit 的 25/50/75/100%）是否还在下降？
3. 在 100% 原 fit 之上，再加入允许使用的 354 个 RNA–GDSC 细胞，RNA-only 能否改善？这是方向 C 的门控。
4. 第二步：用加了 354 的 RNA 教师给 48 个"有 M、有 RNA、无 GDSC 标签"的细胞生成伪标签，作为 M 学生的附加训练行。它能否改善 M-only 部署？

## 1. 数据与身份核查（已完成，未计算任何分数）

预检脚本 `preflight_identity.py`，输出 `output/preflight_identity.json`。只用了身份字段，没有拟合模型。

- 421 开发集：RNA 行序与 source-inputs 完全一致；367 Broad、54 Sanger。
- 354 RNA–GDSC 包：332 Sanger、22 Broad；组织已知 266，未知 88；全部 354 行至少有 1 个 AUC。
- 与 421 的重叠：sample_id 0；包自带 patient_id 与 421 的 PatientID（经 privileged-geometry run 中 Model.csv 身份元数据映射，421 中 420 个有唯一记录）0；ModelID(ACH) 0；StrippedCellLineName 0。
- 66 M–RNA 包同样与 421 无 sample/patient/ACH/名称重叠。其中 18 个也在 19 个 M–GDSC 包里（且也在 354 包里），它们已有真实标签，不当伪标签细胞。剩下 **48 个伪标签候选**（44 Broad、4 Sanger，组织已知 45）。
- 48 个伪标签候选中有 20 个与 354 包中的某个细胞同 PatientID。两者都只出现在训练侧，不影响外折评价的独立性；但这 20 个细胞的伪标签会受到同患者细胞真实标签的强烈影响，结果中要单独说明。
- 354 包与 421 用同一组 34,985 个基因、同一 ln(1+CPM) 变换。

## 2. 固定不变的设定

- 折：读取 `extra-supervision-20261008-0001/output/<scenario>/fold-f/{inner-0,inner-1,inner-2,outer}/geometry.npz` 的 fit、query、panel。新细胞 5 外折 × 3 内折，295 药；整组织 5 外折 × 3 内折，每折面板 281–285 药（沿用保存的 panel）。
- 评价：每个外折使用保存的 `fold-f/predictions.npz` 中的 truth、train_sd、evaluated。逐药 mse_j = 该药在测试细胞上 ((pred−truth)/train_sd)² 的均值；折分数 = sqrt(被评价药物 mse_j 的均值)；主指标 = 5 折均值。同时报告药内 Spearman（被评价药物上取平均，跳过常数向量）与 centered MSE，算法与参考实现相同。
- 模型族：逐药均值中心化的掩码 KRR，alpha ∈ {0.1, 1, 10, 100}；某药 fit 中观测标签 < 20 时，所有 alpha 都退回 fit 均值。
- 超参选择：只用 3 个内折 bank。对每个配置，在每个内折 bank 上计算逐药平均标准化平方误差（用该内折 bank **完整原 fit**（不含额外细胞、不做子抽样）的逐药 nanstd，下限 1e-8），把 3 个 bank 的损失相加，逐药取 argmin；某药在内折完全没有信息时，回退到配置 index 1。外折每个冻结臂只评一次。
- 计算：服务器上 OMP/OPENBLAS/MKL 线程数均为 8，同一时间只跑一个重进程。

## 3. 特征（全部只用当前 bank 的训练行统计）

训练行 = 当前臂在当前 bank 的训练细胞（子抽样后的原 fit；或原 fit + 允许的额外细胞）。

1. 批次校正（两种，都报告）：
   - **c（校正，主分析）**：逐来源（Broad / Sanger）中心化。在训练行中按来源求每个基因的均值；训练行、query 行、伪标签细胞行都减去其来源对应的训练均值。某来源在训练行中少于 10 行时，该来源的行改减全部训练行的总体均值（相当于不对它做来源校正）。
   - **u（不校正，次要分析）**：不做来源处理。
2. 基因筛选：在（校正后的）训练行上按方差从大到小取前 k 个基因（稳定排序）；k ∈ {2000, 5000}，作为超参在内折选择。
3. 标准化：用训练行的均值和标准差（标准差 < 1e-8 时记为 1）。
4. 核：RBF，exp(−d²/(2·width))，width = 训练行两两平方距离中正值的中位数（与 M 核的 kernel_state 规则相同）。

配置顺序：index = k_index × 4 + alpha_index，所以回退 index 1 = (k=2000, alpha=1)。

## 4. 学习曲线子集

对每个 (scenario, fold, bank)，用固定种子 `sha256("rna_lc|scenario|fold|bank")` 的前 8 字节生成原 fit 的一个随机排列；比例 p ∈ {25, 50, 75, 100}% 取排列的前 ceil(p·n) 个位置，再按原 fit 顺序排序。因此子集嵌套：25 ⊂ 50 ⊂ 75 ⊂ 100。内折 bank 和外折 bank 都按同一比例子抽样，选择也在子抽样后的内折上完成。不加入额外细胞。

## 5. 额外细胞的允许规则（逐 bank）

- 354 RNA–GDSC：要求该行在当前面板至少有 1 个有限 AUC。
  - 新细胞场景：其余全部允许，包括组织未知的 88 个。
  - 整组织场景：组织未知的排除；组织出现在"当前 bank fit 之外的原 421 细胞"中的也排除（与 extra-supervision run 的 allowed_extra 规则相同）。
- 48 个伪标签细胞（第二步）：新细胞场景全部允许；整组织场景按同一组织规则排除。
- 19 个 M–GDSC 额外细胞（第二步的 M 学生）：直接使用保存的 geometry.npz 中的 extra_indices。

## 6. 第一步的臂

所有臂逐 bank 训练，在内折选择，外折评一次。

| 臂 | 部署输入 | 训练行 | 网格 | 作用 |
|---|---|---|---|---|
| m_f100 | M | 原 fit | alpha（4） | **复现检查**：必须等于保存的 original__m_only |
| m_f25 / m_f50 / m_f75 | M | 原 fit 子集 | alpha（4） | M 学习曲线参照 |
| null_f100 | 无 | 原 fit | 无 | 逐药训练均值 |
| null_extra354 | 无 | 原 fit + 允许的 354 | 无 | 检查额外标签是否改变药物均值 |
| rna_c_f25 / f50 / f75 / f100 | RNA | 原 fit 子集 | k × alpha（8） | RNA 学习曲线（校正） |
| **rna_c_extra** | RNA | 原 fit + 允许的 354 | k × alpha（8） | **门控臂**（校正） |
| rna_u_f25 / f50 / f75 / f100 | RNA | 同上 | k × alpha（8） | 学习曲线（不校正） |
| rna_u_extra | RNA | 原 fit + 允许的 354 | k × alpha（8） | 门控（不校正，次要） |
| tissue_f100 | 组织标签 | 原 fit | alpha（4） | 组织参照 |
| tissue_extra | 组织标签 | 原 fit + 允许的 354 | alpha（4） | 额外标签对组织模型的作用（区分"更多组织×药物均值信息"与"RNA 信息"） |
| rnat_c_f100 | RNA + 组织 | 原 fit | w ∈ {0, 0.25, 1} × k × alpha（24） | 次要：RNA 核 + w·组织核 |
| rnat_c_extra | RNA + 组织 | 原 fit + 允许的 354 | 同上（24） | 次要 |

组织核：T_ij = 1（同组织），否则 0；组织未知的细胞只与自己相似（与 tissue-kernel run 相同）。rnat 的配置 index = w_index × 8 + k_index × 4 + alpha_index，回退 index 1 = (w=0, k=2000, alpha=1)。

## 7. 第二步（ADDENDUM-A，与第一步同时预先登记）

按原任务，第二步只有门控通过才做。用户要求"都得做"，所以无论门控是否通过都运行第二步；**门控未通过时，第二步结果一律标为"门控未通过后的探索性结果"**，不能作为方向 C 成立的证据。

- 教师：rna_c_extra（校正、加 354）。对外折 bank，教师配置用 3 个内折 bank 的损失逐药选择（与 rna_c_extra 臂相同）；对内折 bank j，教师配置只用另外两个内折 bank 的损失选择（这两个 bank 的 query 都在 bank j 的 fit 内，不碰 bank j 的 query 标签）。教师在当前 bank 的"原 fit + 允许的 354"上训练，预测当前 bank 允许的伪标签细胞。这些细胞从未进入教师训练，所以伪标签是样本外预测。
- 学生：M-only RBF KRR。训练行 = 原 fit + 允许的 19 个 M–GDSC + 允许的伪标签细胞。M 核的标准化和带宽只用原 fit 的 M（与 extra-supervision run 相同），所以 19 个额外行和伪标签行不改变旧核块。
- 加权：伪标签行权重 w_p ∈ {0, 0.25, 1}，真实标签行权重 1。逐药求解 (K_oo + alpha·W⁻¹) c = y − ȳ，ȳ 为加权均值；w_p = 0 时伪标签行完全不参与，精确等于 extra__m_only。观测数 < 20 的判断只数真实标签。配置 index = w_index × 4 + alpha_index，回退 index 1 = (w_p=0, alpha=1)。
- 臂：
  - m_extra19：w_p 固定为 0，**复现检查**，必须等于保存的 extra__m_only。
  - **m_pseudo**：教师伪标签。
  - m_pseudo_shuffle：同一批伪标签向量在伪标签细胞之间整行置换（种子 `sha256("pseudo_shuffle|scenario|fold|bank")`），检查 M–RNA 的细胞对应是否重要。
  - m_pseudo_mean：伪标签 = 教师训练标签（原 fit + 允许的 354）的逐药均值，检查是否只是收缩效应。
  - mP_extra19：P 图版本（L_protein，mu ∈ {0, 0.1, 1, 10, 100, 1000}），w_p = 0，**复现检查**，必须等于保存的 extra__m_only__protein（包括原代码中"19 个额外行在该药无标签时用原 grid"的规则）。
  - mP_pseudo：P 图 + 伪标签。w_p = 0 的部分等于 mP_extra19；w_p > 0 的部分在"原 fit + 19 + 伪标签细胞"节点上计算，伪标签节点在 L 中补零行零列。配置 index = w_index × 24 + mu_index × 4 + alpha_index，回退 index 1。
- 整组织场景同样运行，但该场景当前候选是 virtual-FM 系（FM 生成器不在可读范围内），本实验只能做 M 底座，结果作为次要结果，并同时报告与最强同输入基线 original__virtual_fm__protein（1.110667）的比较。

## 8. 预先写好的比较与判据

改善% = (基线 − 新臂) / 基线，逐折计算，报告 5 折均值、逐折值、胜折数、Nadeau–Bengio 校正配对 t 检验（逐折相对改善；方差因子 1/5 + n_test/n_train，n_test/n_train 取各外折原 query 数/原 fit 数的平均；df = 4；双侧 p 和 95% CI）。

**第一步（新细胞场景为主，整组织为次要）**

- **主比较 G（门控）**：rna_c_extra 对 rna_c_f100。改善 ≥ 0.5% 且 ≥ 4/5 折 → "门控通过"；否则 "门控未通过"。
- **主比较 R**：rna_c_f100 对 m_f100（= original__m_only）。只描述，不设阈值：报告 RNA-only 比 M 直接基线好还是差。
- 次要：rna_u_extra 对 rna_u_f100（同判据，仅报告）；rna_c_f100 对 rna_u_f100（校正的作用）；学习曲线（RNA 与 M 各比例的 5 折均值，75%→100% 是否仍在下降）；tissue_extra 对 tissue_f100；rnat_c_extra 对 rnat_c_f100；rna_c_extra 对 tissue_extra 和对 null_extra354。
- 如果 rna_c_extra 的增益不超过 tissue_extra 相对 tissue_f100 的增益，要如实写"额外标签的增益可能主要来自组织×药物均值信息"。

**第二步**

- **主比较 S（新细胞）**：m_pseudo 对保存的 extra__m_only（1.010662）。≥ 1% 且 ≥ 4/5 折 → "过推进线"；> 0 但不足 → "小幅"；否则 "无增益"。
- **归因**：m_pseudo 必须在 5 折均值上好于 m_pseudo_shuffle 和 m_pseudo_mean，且各 ≥ 4/5 折，才能把增益归因于 RNA 教师的细胞对应信息；否则写"对照可以解释增益"。
- 次要：mP_pseudo 对保存的 extra__m_only__protein（1.006284，当前候选）；整组织场景的 m_pseudo 对 extra__m_only（1.121349），以及对 original__virtual_fm__protein（1.110667）。

**附加稳健性分析（对主比较 G、R、S 及 mP_pseudo 对当前候选）**

- 去掉任意一个外折后的平均改善（5 种）。
- 成组重采样区间：每个外折内按测试细胞的组织整组重采样，药物按 drug_id 整体重采样（各折共用同一组药物权重），2000 次，种子 20261009，报告 5 折均值相对改善的 2.5%/97.5% 分位数。
- 共同药物面板敏感性：取整组织场景 5 个面板的交集（预期 281 药），两个场景都在该面板上重算主比较。

## 9. 复现检查（先于一切结论）

用我自己的实现（从原始 M 重算核）：m_f100 对保存的 original__m_only、m_extra19 对 extra__m_only、mP_extra19 对 extra__m_only__protein，两个场景、全部外折预测的最大绝对差都要 ≤ 1e-8。任一失败，就只报告失败，不报告新臂结论。

## 10. 报告规则

- 报告全部臂、全部 5 折分数、Spearman、centered MSE；不删药、不删折、不删组织，不换指标，不加种子。
- 部署输入不同的臂（M、RNA、组织、RNA+组织）分开写，不混称。
- 本实验用的是已反复用于开发的外折，所有结果都是 candidate_only，不是独立确认。
- RESULT.md 用简体中文写在本地目录。
