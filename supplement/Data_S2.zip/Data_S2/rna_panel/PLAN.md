# 少量实测 RNA 基因面板部署（"面板律"跨层验证）：预先登记

登记时间：2026-10-09（服务器 `PLAN_REGISTERED_AT.txt` 为准）。本文件在计算任何新臂的外折分数之前写下、上传服务器并记录 sha256。外折分数出现后不再修改本文件；若因程序错误必须改动，只在文末追加 ADDENDUM 说明原因，并重跑全部臂。

## 1. 问题与假设

protein-panel-20261009-0001 显示：部署时在 M 之外再实测 k 个按训练内药敏相关性挑出的蛋白并重训头部，可收回实测全蛋白组教师增益的 47–63%（k=8）到 70–74%（k=64），且好于随机面板。crosslayer-matrix-20261009-0001 显示 M→RNA 这一格的空间比 M→P 更大：实测 M+RNA = 0.981097（新细胞）/ 1.097448（整组织），M 直接 1.012045 / 1.120206，即 +3.06% / +2.03%。

本实验问：**借用层换成 RNA（实测 k 个基因）时，同一条"面板律"是否成立？** 所有面板臂的部署输入都是"M + k 个实测基因"（新细胞另有免费的组织标签），与"仅 M"是不同的部署输入，结果一律如此标注。

假设：
- H1（面板价值）：M + 监督挑选的小基因面板，sRMSE 低于同数据 M 直接基线。
- H2（挑选有效）：监督挑选的面板好于同大小的随机面板。
- H3（收回教师增益）：小面板收回实测 M+RNA 教师增益的相当一部分；R(k) 随 k 单调上升。
- H4（跨层比较，描述性）：在相同 k 下，RNA 面板与蛋白面板的 R(k) 与绝对 sRMSE 的异同。
- H5（新细胞）：M + 组织 + 基因面板好于 M + 组织、好于只用组织。

本 run **不含任何图正则（L_protein / L_mask / L_shuffle）臂**；CREED 训练期图正则在少层部署下的增量已在 protein-panel run 判为无增益，这里不重复。

## 2. 数据、划分与边界

- 只用原始 421 个开发细胞：source-inputs.npz（M 225 维、AUC、P、组织、sample_ids），RNA 取 rna421-20260906-0002/rna_log_cpm.npy（421 × 34985 log CPM），按 sample_ids 与 source-inputs 完全对齐（断言）。**不用额外 19 个样本。**
- 划分：沿用 extra-supervision-20261008-0001 每个 bank（fold-f/inner-0..2、outer）保存的 fit/query 索引与药物面板；评价沿用每折 predictions.npz 中保存的 truth、train_sd、evaluated。
- M 核：按 crosslayer.py 的方式从原始 M 重算（fit 均值/标准差标准化，RBF，带宽 = fit 两两正平方距离中位数），并断言与保存核的左上 n_fit 块 allclose(rtol 1e-11, atol 1e-12)，记录最大差。
- 教师：crosslayer-matrix run 保存的实测 M+RNA 外折预测（`pred__M+RNA`），其 5 折均值 0.981097 / 1.097448。
- 蛋白面板对照：protein-panel run 保存的 `output/{scenario}_main/fold_metrics.csv` 与 `fold-f_predictions.npz`（m_panel_k{8,16,32,64}、teacher_saved、m_tissue、tissue_only、vfm），只读，不重算。
- 只读上面列出的目录；不读 64/123 保护集、CTRP、GBM、原始 CSV；不修改任何旧 run。新 run 目录：`/public/home/mengxl/creed-research-runs/rna-panel-20261009-0001/`；本地 `~/Desktop/proj/creed/rna_panel_20261009/`。

## 3. 候选池、面板选择与编码（严格只用每个 bank 的 fit 细胞）

1. **候选池 = crosslayer-matrix run 的 RNA 特征集**：fit 细胞上方差最大的 3000 个基因，`np.argsort(-var, kind='stable')[:3000]`（与 crosslayer.py 相同）。全候选核 K_RNA3000 用这 3000 个基因（按 crosslayer.py 的顺序）、fit z-score、RBF 中位带宽构造；**m_allcand = 0.5·K_M + 0.5·K_RNA3000 必须把 crosslayer run 的实测 M+RNA 外折预测复现到 ≤ 1e-8（硬门槛），这样教师 = m_allcand = 矩阵 M+RNA**。
2. **相关性打分**：对该 bank 药物面板中每个药物 d，在 fit 细胞中取 AUC_d 观测的行，计算基因 j 与 AUC_d 的 Spearman（平均秩）；成对观测数 < 10 或任一侧常数时该项记 0。w_j = Σ_d |ρ_jd|。实现与 protein-panel run 的 `spearman_scores` 同一公式（RNA 无缺失，走无缺失快速路径，在 dryrun 中断言两条路径结果一致）。
3. **面板** = w_j 前 k 名，k ∈ {8, 16, 32, 64, 128}；同分按基因列号升序（候选池先按列号升序排列，再做稳定降序排序）。
4. **面板核**：k 个基因 fit z-score，RBF 带宽 = fit 两两正平方距离中位数；K = 0.5·K_M + 0.5·K_panel（cross 核同样组合）。
5. **随机面板对照**：k = 16 和 32，种子 s ∈ {0..4}：`np.random.default_rng([20261009, 场景号, 折号, bank号, s])` 对同一候选池（按列号升序）做一次置换，取前 16 / 前 32（同种子下 16 ⊂ 32）。场景号 new_cell=0、tissue=1；bank 号 inner-0/1/2=0/1/2、outer=3。
6. **描述性双层臂（无判据）**：m_panel_pg_k32 = 0.5·K_M + 0.25·K_P32 + 0.25·K_RNA32。32 个蛋白按 protein-panel run 的规则（fit 观测比例 ≥ 90% 且方差 > 1e-12 为候选；fit 均值填补 fit 与 query 的缺失；fit 标准化；Σ|Spearman| 前 32，同分按蛋白列号升序；RBF 中位带宽），32 个基因按上面第 3 条。两场景都算，只用 alpha 网格（新细胞不加组织核）。

## 4. 模型

逐药、均值中心化的 masked KRR（与前几个 run 相同代码）：alpha ∈ {0.1, 1, 10, 100}；某药 fit 观测 < 20 时所有 alpha 都返回 fit 均值。

- 组织核（仅新细胞）：K + w·T，w ∈ {0, 0.25, 1}；T_ij = 1 当且仅当同组织（空组织标签视为各自独立）。
- 整组织场景另加 virtual-FM 底座：K_V 为保存的 `virtual_fm_kernel` 左上块；vfm 面板核 = 0.5·K_V + 0.5·K_panel；vfm_allcand = 0.5·K_V + 0.5·K_RNA3000。

## 5. 全部臂（每个场景）

配置顺序决定回退索引 1 的含义（列表中靠外的维度在前，alpha 在最内层；索引 1 = 第一个配置、alpha = 1）。

| 臂 | 部署输入 | 网格（外→内） |
|---|---|---|
| m_only | M | alpha（复现 original__m_only） |
| m_panel_k{8,16,32,64,128} | M + k 基因 | alpha |
| **m_panel_sel** | M + ≤64 基因 | k ∈ {8,16,32,64} × alpha |
| random_k{16,32}_s{0..4} | M + k 随机基因 | alpha |
| m_allcand | M + 3000 基因（教师，复现矩阵 M+RNA） | alpha |
| m_panel_pg_k32 | M + 32 蛋白 + 32 基因（描述性） | alpha |
| null_drug | 无 | 逐药 fit 均值 |

仅新细胞（组织标签免费）：

| 臂 | 部署输入 | 网格 |
|---|---|---|
| tissue_only | 组织 | alpha（复现 protein-panel run） |
| m_tissue | M + 组织 | w × alpha（复现 protein-panel run） |
| m_panel_tissue_k{8,16,32,64,128} | M + 组织 + k 基因 | w × alpha |
| **m_panel_tissue_sel** | M + 组织 + ≤64 基因 | k ∈ {8,16,32,64} × w × alpha |
| random_tissue_k{16,32}_s{0..4} | M + 组织 + k 随机基因 | w × alpha |
| m_allcand_tissue | M + 组织 + 3000 基因（参照） | w × alpha |

仅整组织：

| 臂 | 部署输入 | 网格 |
|---|---|---|
| vfm | M（虚拟 FM 底座） | alpha（复现 original__virtual_fm） |
| vfm_panel_k{8,16,32,64,128} | M + k 基因 | alpha |
| vfm_panel_sel | M + ≤64 基因 | k ∈ {8,16,32,64} × alpha |
| vfm_allcand | M + 3000 基因（参照） | alpha |

另把 crosslayer run 保存的 `pred__M+RNA` 作为 `teacher_saved` 一并评分（只读入，不重算）。

## 6. 选择规则（与原规则相同）

只用 3 个内折 bank：每个配置、每个药物的损失 = 该 bank query 细胞上 ((pred − truth)/sd)² 的均值，sd = 该内折 fit 集逐药 nanstd（下限 1e-8）；对有信息的 bank 求和后取平均；逐药 argmin；三个 bank 都无信息时回退到索引 1。外折每个冻结臂只评估一次。

## 7. 复现检查（先于一切新结论）

1. **门槛 A**：m_only 的全部内外折网格与 `grids.npz['original__m_only']`、外折选择后预测与 `predictions.npz['original__m_only']` 最大绝对差 ≤ 1e-8（整组织另加 vfm 对 `original__virtual_fm`）。
2. **门槛 B（硬）**：m_allcand 外折预测与 crosslayer run `fold-f_predictions.npz['pred__M+RNA']` 最大绝对差 ≤ 1e-8，两场景、5 折全部满足。另核对 M 与 M+RNA 的 3 个内折 bank 损失向量与 crosslayer run `fold-f_inner_losses.npz` 的差。**不通过则只报告失败，不报告任何新臂。**
3. 复核（报告，不作门槛）：新细胞 m_tissue、tissue_only 外折预测与 protein-panel run 保存值的最大差（预期 ≤ 1e-8，差异来源仅为 M 核重算 vs 保存块，约 1e-16）；用保存的 `pred__M+RNA` 重新评分应得 0.981097 / 1.097448。
4. dryrun：fold-0 inner-0 bank（两场景），只做内折网格复现、内折损失与 crosslayer 保存值比对、Spearman 两条路径一致性断言与计时；不计算任何外折分数。dryrun 之后才固定 SHA256SUMS。

## 8. 指标

逐外折：mse_j = 观测测试细胞上 ((pred − truth)/train_sd)² 的均值；折分数 = sqrt(被评价药物上 mse_j 的均值)；主指标 = 5 折均值。同时报告同药物跨细胞 Spearman（跳过常数向量）和 centered MSE（与参考实现相同）。

## 9. 主比较与判据

记 改善% = (基线 5 折均值 − 新臂 5 折均值) / 基线 5 折均值 × 100；胜折 = 新臂折分数更低的折数；逐折相对改善 d_f = (b_f − n_f)/b_f。Nadeau–Bengio 校正配对 t：t = mean(d) / sqrt((1/5 + r)·var(d, ddof=1))，r = 各折 n_test/n_train 的均值，df = 4，双侧 p；同时给 95% 区间。

判定标签（统一）：改善 ≥ 1% 且胜折 ≥ 4/5 →"过推进线"；改善 > 0 但不满足 →"小幅"；改善 ≤ 0 →"无增益"。

- **P1 面板价值（不同部署输入，故意的）**：m_panel_sel 对 m_only（两场景）。**P1b**：m_panel_tissue_sel 对 m_tissue（新细胞，同数据、都用组织）。
- **P2 监督挑选 vs 随机**：m_panel_k16 对 random_k16 种子均值、m_panel_k32 对 random_k32 种子均值（两场景；随机臂每折分数 = 5 个种子折分数的平均）。两种 k 都满足"胜折 ≥ 4/5 且改善 > 0"记为"监督挑选优于随机"，否则"未优于随机"。新细胞的组织版本（m_panel_tissue_k 对 random_tissue_k 均值）同样报告（描述性）；另报 m_panel_sel 对两个随机均值中更强者（描述性）。
- **P3 收回教师增益比例**：R(k) = (S_m_only − S_panel_k)/(S_m_only − S_teacher)，S_teacher 取 (i) 保存的矩阵 M+RNA（teacher_saved，0.981097 / 1.097448）与 (ii) 本 run 复现的 m_allcand；对 k ∈ {8,16,32,64,128}、m_panel_sel、m_panel_pg_k32（新细胞另加 m_panel_tissue_* ，整组织另加 vfm_panel_*）给 5 折均值版本与逐折版本。
- **P5（新细胞）**：m_panel_tissue_sel 对 m_tissue（同 P1b）、对 tissue_only（本 run 重算；protein-panel run 为 1.002166）。
- **跨层比较（描述性，论文中心表）**：k = 8, 16, 32, 64 在两场景下 R_RNA(k)（本 run，教师 = 矩阵 M+RNA）与 R_P(k)（protein-panel run 的 m_panel_k，教师 = 0.986172 / 1.094881）并列；M + k 基因 与 M + k 蛋白 的绝对 sRMSE 及同折配对比较（改善%、胜折、NB p）；双层臂 m_panel_pg_k32 对本 run 的 m_panel_k32、m_panel_k64 以及 protein-panel run 的 m_panel_k32、m_panel_k64。不设判据。

次要比较（描述性）：m_panel_k128 对 m_panel_k64；m_panel_sel 对 m_panel_k64；m_allcand 对 m_panel_sel；teacher_saved 对 m_panel_sel；整组织 vfm_panel_sel 对 vfm、vfm_allcand 对 vfm；入选 k / w 的分布；各折面板基因的重叠（Jaccard）与高频基因。

## 10. 稳健性（对 P1、P1b、P2、P5）

1. 去一折：去掉任一外折后剩余 4 折的改善%，报告最小值。
2. 成组重采样区间（描述性，事先固定）：B = 2000，种子 20261009（新细胞）/ 20261010（整组织），与 protein-panel run 相同的生成方式：药物按药物 ID 有放回重采样（各折共用同一组药物权重）；细胞在新细胞场景按"折内组织簇"有放回重采样，在整组织场景按"折内、每个留出组织内"分层有放回重采样。每次重算两臂 5 折均值与改善%，报告 2.5%/97.5% 分位与改善 > 0 的比例。
3. 整组织场景共同药物面板敏感性：只用 5 个外折都被评价的药物（预期 281 个，实际数目以数据为准）重算折分数和主比较。

## 11. 不做的事与注意事项

不加种子、不扩网格、不删药物/折/组织、不换指标；负结果原样报告；不做多重比较校正。所有数字都来自已被反复用于开发的 5 个外折，属于 candidate_only，不是独立确认。面板基因的"实测值"直接取自完整 RNA 矩阵（没有模拟单独测定 k 个基因的测量噪声）。只有 1 个队列。

## 12. 运行流程与资源

`code/rna_panel.py SCENARIO STAGE OUT`（STAGE ∈ dryrun / repro / main）与 `code/analyze.py RUN_DIR`。顺序：PLAN 登记 → dryrun（fold-0 inner-0）→ 固定 SHA256SUMS（PLAN + code）→ repro 阶段（只算复现臂，两场景，确认门槛 A/B）→ main（全部臂）→ analyze → OUTPUT_SHA256SUMS → RESULT.md。两场景并行，各 4 线程（合计不超过 8 线程）。
