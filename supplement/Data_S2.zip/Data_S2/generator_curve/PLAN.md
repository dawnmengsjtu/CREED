# 虚拟层生成器的训练规模学习曲线（M 行：M+vRNA、M+vP；新细胞 / 整组织，相同折）：预先登记

登记时间：2026-10-09。本文件在计算任何新臂的外折分数之前写下，上传服务器 run 目录并记录 sha256（`PLAN_REGISTERED_AT.txt`、`SHA256SUMS`）。之后不按结果修改；若因程序错误必须改动，只在文末追加 ADDENDUM 说明原因，并重跑全部臂。

服务器 run 目录：`/public/home/mengxl/creed-research-runs/generator-curve-20261009-0001/`
本地目录：`/Users/xlzhexue/Desktop/proj/creed/generator_curve_20261009/`

## 0. 要回答的问题

跨层矩阵（crosslayer-matrix-20261009-0001）的结论是：部署只测 M 时，借入实测 RNA / P 的空间为 2.2–3.1%，而用 M→Y 交叉拟合 KRR 生成的"免费虚拟层"只收回约三分之一（新细胞 M+vRNA 34%、M+vP 29%；整组织 33%、33%）。审稿人会问：**这个三分之一是不是被生成器的训练样本量限制了？** 全面扩容做不到（M∩P 的 608 条几乎就是全部 609；M∩RNA 在 608 之外只有 66 条身份安全的额外线落盘，原始源对本账户不可读，见 `generator_scaleup_20261009/INVENTORY.md`），所以改为测**生成器训练规模的学习曲线**：

1. **L1（421 内曲线）**：生成器只用 bank fit 细胞的 50% / 75% / 100% 训练时，M+vY 对 M 的增益是否随规模单调上升？上升 → "到 n = fit 仍在上升"（数据敏感，更多配对样本有望收回更多）；否则 → "在可用范围内已饱和"。
2. **L2（额外线，仅 RNA）**：在 100% fit 之上再加入 66 条身份审计过的额外 M+RNA 线训练生成器，M+vRNA 是否改善？
3. 描述性：恢复份额 share 随 n 的斜率；生成器 OOF R² 是否随 n 上升、share 是否跟随 R²。

**唯一变化的是生成器的训练集。** 头（逐药 masked KRR）、评价细胞、药物、核、bank、alpha 选择、指标全部与矩阵 run 相同。

## 1. 数据、划分与边界

- 只读：`gdsc-metabolite-full-protein-20260908-0001/output/result/source-inputs.npz`（sha256 `52d71517…`；M 225 维、AUC 295 药、P 6,692 蛋白、组织、sample_ids）；`rna421-20260906-0002/{rna_log_cpm.npy, sample_ids.npy, gene_ids.npy}`；`extra-supervision-20261008-0001/output/<scenario>/fold-f/<bank>/{geometry.npz, grids.npz}` 与 `fold-f/predictions.npz`（折、保存核块、评价量）；`extra-supervision-20261008-0001/resources/m_rna_extra66.npz`（sha256 `bd8d13f5…`）与 `rna_config.json`（sha256 `995a42ab…`，其 `m_rna_ids` 必须与 66 包 sample_ids 一致）；`crosslayer-matrix-20261009-0001/output/<scenario>/{fold-f_predictions.npz, bank_info.json}`（复现门的参照）。运行前断言全部 sha256 与登记值一致、RNA 行序与 source-inputs 一致、66 包基因面板与 rna421 的 34,985 个 gene_id 完全一致、66 与 421 及 608 无交集、组织空值恰为 `SIDM00015, SIDM00037, SIDM00248, SIDM00271`。
- 不读 64/123 保护集、CTRP、GBM99、原始 CSV；不修改任何旧 run；新建的服务器目录只有上面那一个；8 线程串行。
- 划分：读取 geometry.npz 的 fit、query、panel（新细胞 5 外折 × 3 内折，295 药；整组织 5 外折 × 3 内折，面板 281–285 药）。评价用保存的 `predictions.npz` 的 truth、train_sd、evaluated，并断言与矩阵 run 保存的一致。

## 2. 固定不变的设定（与矩阵 run 完全相同）

- 层编码：M = 225 代谢物 fit 标准化 RBF 中位带宽；RNA = fit 方差前 3000 基因、fit 标准化、RBF；P = fit 观测 ≥ 50% 的候选蛋白，值核（fit 均值填补、fit 标准化、RBF）与掩码核（0/1 RBF）各 0.5。多层实测臂等权平均。
- 虚拟层臂：K = 0.5·K_M + 0.5·K_vY，K_vY = RBF(Ẑ_fit)（`kernel_state`：标准化 + 中位带宽），H_vY = RBF(Ẑ_q, Ẑ_fit)。
- 头：逐药均值中心化 masked KRR，alpha ∈ {0.1, 1, 10, 100}；fit 观测 < 20 的药退回 fit 均值。alpha 在 3 个内折 bank 上按逐药损失求和取 argmin，无信息时回退 index 1。外折每臂评一次。
- 指标：sRMSE = sqrt(被评价药物上 ((pred − truth)/train_sd)² 细胞均值的均值)，主指标 5 折均值；同时报告 Spearman 与 centered MSE。
- 代码：`code/gencurve.py` 的 `predict_grid / bank_losses / choose / take / metrics / kernel_state / rbf / rbf_pair / binary_rbf / average` 与生成器交叉拟合逐字复制矩阵 run 的 `code/crosslayer.py`（sha256 `c1095b94…`）；`layer_inputs` 同一计算，只是额外返回原始目标矩阵。

## 3. 生成器与它的训练集（本实验唯一的变量）

### 3.1 生成器配方（与矩阵 run 相同）
- 目标 Z_Y：Y 层的标准化特征取 fit **原始值方差**前 512 列（RNA：前 3000 基因中方差最高的 512 个；P：候选蛋白中填补后方差最高的 512 个）。**目标列集合对所有规模都用该 bank 的全部 fit 细胞计算**（与矩阵 run 相同），使不同规模的虚拟层可比；**标准化统计量（均值、sd，sd<1e-8 置 1）用生成器训练集的行**计算（在全部特征列上算再取目标列，与矩阵 run 的算法顺序相同，所以 f100 时与矩阵 run 逐位一致）。P 的填补均值沿用头所用的 fit 均值（填补只是把 P 值矩阵补齐，不是生成器训练统计量）。
- 输入核 K_M：**始终用头的 M 核状态**（fit 的均值、sd、中位带宽，与保存的 `m_only_kernel` 一致），生成器训练子集取其子块；加入额外线时用同一状态把核扩到额外行。即 M 层几何对所有规模不变，只变配对样本数。
- 交叉拟合：生成器训练索引表（按 fit 顺序排序的子集；extra 时为 fit 行后接额外行）按固定种子 `sha256("oof|scenario|fold|bank")` 的前 8 字节随机分 3 份（**同一种子规则作用在生成器训练索引表上**），每份由其余两份训练的 KRR 预测得到训练行的 OOF 虚拟特征；λ ∈ {0.1, 1, 10, 100} 在训练集内按全部目标列 OOF MSE 均值选一个；再用全部训练行、同 λ 拟合最终生成器。
- 虚拟特征：训练集内的 fit 行用 OOF 预测；**训练集外的 fit 行（f50/f75 才有）和 query 行用最终生成器预测**。额外行不是 fit 细胞，不进入头。f100 无额外时与矩阵 run 的 `generator` 完全相同。
- 每 bank 每规模记录：生成器训练 n（含其中 fit 行数、额外行数）、λ、OOF R²（目标列均值与中位数）、虚拟核带宽。

### 3.2 训练集（每 bank 一个随机排列）
- 排列：`np.random.default_rng([20261009, scenario_id, fold, bank_id, 7]).permutation(n_fit)`，scenario_id：new_cell=0、tissue=1；bank_id：inner-0/1/2 = 0/1/2，outer = 3。
- **f50 / f75 / f100** = 排列前 ceil(0.5·n)、ceil(0.75·n)、n 个位置（再按 fit 顺序排序），嵌套 f50 ⊂ f75 ⊂ f100；f100 = 全部 fit。新细胞 fit 336–337（内折 bank fit 约 224–225），整组织 fit 328–340。
- **extra（仅 M→RNA）** = f100 ∪ 允许的额外 M+RNA 线：
  - 新细胞：全部 66 条（含 4 条组织空值）。
  - 整组织：排除 4 条组织空值，并排除组织出现在**该 bank query 细胞**中的额外线（外折 bank 即该折留出组织；内折 bank 即该内折留出组织）。按 INVENTORY.md §3.2，外折可用 51/44/52/51/50，内折 bank 可用 fold0 42/49/44、fold1 51/47/44、fold2 48/42/44、fold3 46/40/49、fold4 51/40/45；运行时断言逐 bank 计数与此完全一致。每折实际使用的 sample_id 写入 `output/extra_ids_<scenario>_fold-f.txt`。
- 额外线的 M 直接取 66 包的 `m`（与 421 同源同列），RNA 取 `rna_log_cpm`（同 34,985 基因面板、同 ln(1+CPM) 变换），按该 bank 的前 3000 基因索引取列。

### 3.3 配对置乱对照（extra 专用）
- **M+vRNA_extra_shuf（主对照）**：只把**额外行**的 RNA 目标在额外行之间置乱（种子 `sha256("pair_shuffle_extra|scenario|fold|bank")`），fit 行配对保持。它分离"66 条额外线的真实配对"与"仅仅多了 66 行 M 输入分布"的贡献。
- **M+vRNA_extra_shufall（次要对照）**：矩阵 run 口径的全部行配对置乱（种子 `sha256("pair_shuffle|scenario|fold|bank")`，作用在生成器训练索引表上）。

## 4. 全部臂（每场景 12 个网格臂 + null）

| 组 | 臂 | 部署输入 | 生成器训练集 | 作用 |
|---|---|---|---|---|
| 复现 | M | M | — | 必须等于矩阵 run `pred__M` |
| 实测参照（复现） | M+RNA、M+P | M + 实测 Y | — | headroom；必须等于矩阵 run `pred__M+RNA`、`pred__M+P` |
| 曲线 RNA | M+vRNA_f50、M+vRNA_f75、**M+vRNA_f100** | 仅 M | fit 的 50% / 75% / 100% | f100 必须等于矩阵 run `pred__M+vRNA` |
| 额外线 | M+vRNA_extra | 仅 M | f100 ∪ 允许的额外线 | L2 |
| 对照 | M+vRNA_extra_shuf、M+vRNA_extra_shufall | 仅 M | 同 extra，配对置乱 | L2 对照 |
| 曲线 P | M+vP_f50、M+vP_f75、**M+vP_f100** | 仅 M | fit 的 50% / 75% / 100% | f100 必须等于矩阵 run `pred__M+vP` |
| 参照 | null_drug | 无 | — | 逐药 fit 均值；必须等于矩阵 run `pred__null_drug` |

## 5. 复现门（先于一切结论；任一失败只报告失败，不报告曲线）

1. 从原始 M 重算的 K_M 与保存 `m_only_kernel` 左上块 allclose(1e-11, 1e-12)；M 臂内外折网格与 `grids.npz['original__m_only']` 最大绝对差 ≤ 1e-8。
2. **硬门**：两场景全部 5 折，M、M+RNA、M+P、M+vRNA_f100、M+vP_f100、null_drug 的外折预测与矩阵 run `fold-f_predictions.npz` 对应 `pred__` 的最大绝对差 ≤ 1e-8；alpha 选择索引也应完全一致（记录）。
3. 每个 bank 的 f100 生成器：λ 与矩阵 run `bank_info.json` 的 `M->RNA` / `M->P` 相同，OOF R²（均值、中位数）与虚拟核带宽的绝对差 ≤ 1e-9。
4. 工程顺序：PLAN 登记 → dryrun（只算 fold-0 的 inner-0 bank：f100 生成器 λ/R²/带宽复现、M 内折网格核对、两场景全部 fold/bank 的额外线计数核对；不算外折）→ 固定 SHA256SUMS → main。dryrun 不产生任何外折分数。

## 6. 读出与判据（预先写好）

记 gain%(A 对 B) = mean_f (b_f − a_f)/b_f × 100（逐折相对改善的 5 折均值，矩阵 run 定义）；同时报告 5 折均值之比 1 − mean(a)/mean(b)；胜折 = a_f < b_f 的折数；Nadeau–Bengio 校正配对 t：t = mean(d)/sqrt((1/k + r)·var(d, ddof=1))，r = 外折 n_query/n_fit 的均值，df = k − 1（全部折 k = 5），双侧 p，95% 区间。

**每场景、每借用层 Y ∈ {RNA, P}：**
- headroom = gain(M+Y 对 M)；recovered(size) = gain(M+vY_size 对 M)；share(size) = recovered(size)/headroom（headroom > 0.3% 时；否则记"无空间"）；同时给均值比版本与逐折 share。
- **L1（主判据）**：gain(M+vY_f75 对 M+vY_f50) 在 ≥ 4/5 折为正 **且** gain(M+vY_f100 对 M+vY_f75) 在 ≥ 4/5 折为正 → "still rising at n=fit"；否则 → "flat"。（逐折比较等价于逐折分数 f75 < f50、f100 < f75。）
- 描述性斜率：对每折，以外折生成器训练 n 为横轴、逐折 share 为纵轴，最小二乘直线过 3 个点（f50/f75/f100；RNA 另给含 extra 的 4 点版本）的斜率（每 100 个训练细胞的 share 百分点），报告逐折值、均值 ± sd；另给 gain 对 n 的斜率（更稳，逐折 headroom 为负时 share 无定义）。
- **L2（仅 RNA，主判据）**：gain(M+vRNA_extra 对 M+vRNA_f100) > 0、胜折 ≥ 4/5、NB p < 0.10 → "extra lines help"；否则 "no detectable help from extra lines"。同时报告：extra 对 extra_shuf（主对照：> 0 且 ≥ 4/5 折才可把 L2 的改善归因于额外线的真实配对）、extra 对 extra_shufall、extra_shuf 对 f100、extra_shufall 对 M、extra 对 M 的 share。
- **判定用语（预设）**：某层若 L1 在至少一个场景通过 → 该层 "data-sensitive"；两个场景都不通过 → "saturated within the available range"。L2 单独报告，不并入层判定。
- **R² 对 share**：每规模给生成器 OOF R²（5 个外折 bank 均值与 20 个 bank 均值）与 share 并列，描述 share 是否跟随 R² 上升（层内）。

**稳健性：**
- 去一折（leave-one-fold-out）：L1 的两步在余下 4 折各 ≥ 3/4 为正才记 rising；L2 在余下 4 折胜 ≥ 3/4 且 NB p（df = 3）< 0.10 才记通过。报告 5 次去一折的结果与所有对比的去一折 gain 范围。
- 成组 bootstrap（B = 2000，种子 20261009，与 rna-learning-curve run 相同：药物按并集多项式重采样、测试细胞按组织成组多项式重采样，各对比共用随机数）：L1 两步与 L2 三个对比的 95% 区间与正的比例。

**对比个数**：主判据对比每场景 RNA 2（L1）+ 1（L2）、P 2（L1），两场景共 10 个；其余（headroom、recovered×size、对照、斜率、R²）描述性。不做多重比较校正，RESULT 中写明个数。

## 7. 预期与解读规则（写在结果之前）

- 矩阵 run 已知：新细胞 M 1.012045、M+RNA 0.981097、M+P 0.987973、M+vRNA 1.001331、M+vP 1.004923；整组织 M 1.120206、M+vRNA 1.112436、M+vP 1.111658；生成器 OOF R² M→RNA 0.25–0.29、M→P 0.14–0.15。f100 臂必须复现这些数字。
- 预期 OOF R² 随 n 上升（KRR 学习曲线）；功能恢复是否跟随未知。f50 的头仍用全部 fit 标签，只是虚拟特征更差，所以 f50 的 M+vY 仍可能优于 M。
- 若 L1 两步都是正但只有 3/5 折，按预设记 "flat"，并写明方向；若 f50 > f100（更差的生成器反而更好）也照实报告。
- L2 的额外线组织构成（Haem 17、Lung 11、Large Intestine 8 等）与 421 不同，且整组织场景每折仅 44–52 条；增益小属预期，负值照实报告。
- 本实验的全部数字来自反复用于开发的 5 个外折，属 candidate_only。

## 8. 输出

服务器 run 目录：`PLAN.md`、`PLAN_REGISTERED_AT.txt`、`SHA256SUMS`（PLAN + code）、`code/{gencurve.py, analyze_curve.py, run.sh}`、`dryrun/<scenario>/`、`logs/`、`run.log`、`output/<scenario>/{fold-f_predictions.npz, fold-f_inner_losses.npz, fold-f_bank_info.json, fold_metrics.csv, per_drug_metrics.csv, bank_info.json, protocol.json, extra_counts.json, summary.json}`、`output/extra_ids_<scenario>_fold-f.txt`、`output/{fold_metrics.csv, comparisons.csv, summary.json, curve_tables.md}`、`OUTPUT_SHA256SUMS`。
本地：`PLAN.md`、`code/`、`fold_metrics.csv`、`comparisons.csv`、`summary.json`、`RESULT.md`（简体中文：复现门；逐 bank/规模的生成器 n；全部臂逐折；两层两场景的 share 对 n 表；L1/L2 与稳健性；R² 对 share；局限：单一种子的嵌套子集、66 条额外线组织构成不同、开发折复用）。

## 9. 不做的事

不改头、核、alpha 网格、λ 网格、目标列数、OOF 折数；不调虚拟核权重；不用额外线的标签训练头；不加种子（子集只有一个随机排列）；不删药/折；不换指标；不在看到外折分数后改任何臂或判据。

## ADDENDUM-A（2026-10-09 17:15，程序错误修正，不改任何臂与判据）

第一次 main 在 new_cell fold-0 外折评价前的一致性断言处中止（`np.array_equal(MX['truth'], P['truth'])`：truth 含 NaN（未观测），NaN ≠ NaN，断言恒假；矩阵 run 保存的 truth 与 extra-supervision 保存的 truth 本是同一数组）。中止发生在计算任何外折分数之前（run.log 只有 fold-0 的 4 个 bank_done，无 fold_done），没有看到任何外折分数。修正：对 truth、train_sd 使用 `equal_nan=True`（`code/gencurve.py` 第 430 行），其余代码不变。失败尝试的部分输出移至 `logs/failed_attempt_1/`；重新固定 SHA256SUMS 并从头重跑全部臂。
