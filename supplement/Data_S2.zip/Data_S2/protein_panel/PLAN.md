# 少量实测蛋白面板部署（方向 D）：预先登记

登记时间：2026-10-09。本文件在计算任何新臂的外折分数之前写下并上传服务器、记录 sha256。外折分数出现后不再修改本文件；若因程序错误必须改动，只在文末追加 ADDENDUM 说明原因，并重跑全部臂。

## 1. 问题与假设

CREED 的设定是"训练时多层组学，部署时只测一层或少数几层"。前面所有可部署臂都只用 M（新细胞场景另有免费的组织标签）。实测全 P 教师（0.5 M 核 + 0.5 实测 P 核，约 3350 个蛋白）在新细胞为 0.986172、整组织为 1.094881，明显好于 M 直接基线（1.012045 / 1.120206），但部署时要做全蛋白组。

方向 D：部署时除了 M（新细胞另有组织标签）之外，**再实测一个很小的蛋白面板（8–64 个蛋白）**。这是一个**不同于"仅 M"的部署输入**，所有结果都会标注为"M + k 个实测蛋白"，不与"仅 M"的结果混称。

假设：
- H1（面板价值）：按训练内药敏相关性挑出的小面板，与 M 一起输入，sRMSE 低于同数据 M 直接基线。
- H2（挑选有效）：监督挑选的面板好于同大小的随机面板。
- H3（收回教师增益）：小面板能收回实测全 P 教师增益的相当一部分。
- H4（CREED 在少层部署下的增量）：训练期全 P 样本图正则（L_protein）在"M + 面板"之上仍能降低误差。
- H5（新细胞）：M + 组织 + 面板好于 M + 组织、好于只用组织。

## 2. 数据、划分与边界

- 只用原始 421 个开发细胞（source-inputs.npz：M、AUC、P、组织）。**不用额外 19 个样本**（它们没有 P）。
- 划分：沿用 extra-supervision-20261008-0001 每个 bank（fold-f/inner-0..2、outer）保存的 fit/query 索引与药物面板。原始数据的 M 核取保存核的左上 n_fit 块；L_protein / L_mask / L_shuffle 取保存图的左上 n_fit 块（额外样本部分为零）。
- 评价沿用该 run 每折 predictions.npz 中保存的 truth、train_sd、evaluated。
- 不读 64/123 保护集、CTRP、GBM、原始 CSV；不修改任何旧 run。新 run 目录：`/public/home/mengxl/creed-research-runs/protein-panel-20261009-0001/`。
- 实测 P 教师复现只读取 privileged-geometry run 每个 bank 保存的 `protein_indices`（教师自己的蛋白入选名单）和 strong-teacher run 保存的外折预测，仅作复现核对，不用于任何新臂。

## 3. 面板选择（严格只在每个 bank 的 fit 细胞内）

1. 候选蛋白：在该 bank 的 fit 细胞中观测比例 ≥ 90%，且观测值方差 > 1e-12。
2. 打分：对该 bank 药物面板中的每个药物 j，在 fit 细胞中取蛋白与 AUC 同时观测的行，计算 Spearman 相关（平均秩处理并列）；成对观测数 < 10 或任一侧为常数时该项记 0。蛋白得分 = Σ_j |ρ_ij|。
3. 面板 = 得分前 k 个（降序，同分按蛋白列号升序），k ∈ {8, 16, 32, 64}。
4. 编码：面板蛋白在 fit 和 query 中的缺失值都用 fit 观测均值填补；再用填补后 fit 矩阵的均值/标准差标准化（sd<1e-8 置 1）；RBF 核，带宽 = fit 两两正平方距离的中位数（与教师和 M 核同一构造）。
5. 随机面板对照：k = 16 和 32，5 个固定种子 s ∈ {0..4}。每个 bank 用 `np.random.default_rng([20261009, 场景号, 折号, bank号, s])` 对同一候选池做一次置换，取前 16 / 前 32 个（同种子下 16 ⊂ 32）。只用 fit 信息。
6. 全候选参照（非少层部署，只作参照）：用该 bank 全部候选蛋白（约 1800 个）构造同样的核。

## 4. 模型

逐药、均值中心化的 masked KRR（与原代码相同）：alpha ∈ {0.1, 1, 10, 100}；某药 fit 观测 < 20 时所有 alpha 都返回 fit 均值。

- 面板核：K = 0.5·K_M + 0.5·K_panel（cross 核同样组合）。
- 组织核（仅新细胞）：K + w·T，w ∈ {0, 0.25, 1}；T_ij = 1 当且仅当同组织。
- P 图正则（与原代码相同公式）：root = K^{1/2}，A = I + μ·root·L·root，K_eff = root·A⁻¹·root，H_eff = H − μ·H·L·K_eff；μ ∈ {0, 0.1, 1, 10, 100, 1000}（μ=0 即直接模型）。L 取 L_protein（数值臂），对照为 L_mask、L_shuffle。
- 整组织场景另加 virtual-FM 底座（当前候选所用底座）：K_V 为保存的 0.5 M + 0.5 FM 核的左上块；vfm 面板核 = 0.5·K_V + 0.5·K_panel。

## 5. 全部臂（每个场景）

配置顺序决定回退索引 1 的含义（列表中靠外的维度在前，alpha 在最内层）。

| 臂 | 部署输入 | 网格（外→内） |
|---|---|---|
| m_only | M | alpha（复现 original__m_only） |
| m_only__protein | M | μ × alpha（复现 original__m_only__protein） |
| m_panel_k{8,16,32,64} | M + k 蛋白 | alpha |
| **m_panel_sel** | M + ≤64 蛋白 | k × alpha |
| m_panel_sel__protein | M + ≤64 蛋白 | k × μ × alpha（L_protein） |
| m_panel_sel__mask / __shuffle | M + ≤64 蛋白 | 同上，L_mask / L_shuffle |
| random_k{16,32}_s{0..4} | M + k 随机蛋白 | alpha |
| m_allcand | M + 全候选约 1800 蛋白（参照） | alpha |
| teacher_repro | M + 教师约 3350 蛋白（复现） | alpha |
| null_drug | 无 | 逐药 fit 均值 |

仅新细胞（组织标签免费）：

| 臂 | 部署输入 | 网格 |
|---|---|---|
| tissue_only | 组织 | alpha |
| m_tissue | M + 组织 | w × alpha |
| m_tissue__protein | M + 组织 | w × μ × alpha |
| m_panel_tissue_k{8,16,32,64} | M + 组织 + k 蛋白 | w × alpha |
| **m_panel_tissue_sel** | M + 组织 + ≤64 蛋白 | k × w × alpha |
| m_panel_tissue_sel__protein / __mask / __shuffle | M + 组织 + ≤64 蛋白 | k × w × μ × alpha |
| random_tissue_k{16,32}_s{0..4} | M + 组织 + k 随机蛋白 | w × alpha |
| m_allcand_tissue | 参照 | w × alpha |

仅整组织：

| 臂 | 部署输入 | 网格 |
|---|---|---|
| vfm | M（虚拟 FM） | alpha（复现 original__virtual_fm） |
| vfm__protein | M | μ × alpha（复现 original__virtual_fm__protein，当前候选 1.110667） |
| vfm_panel_k{8,16,32,64} | M + k 蛋白 | alpha |
| vfm_panel_sel | M + ≤64 蛋白 | k × alpha |
| vfm_panel_sel__protein / __mask / __shuffle | M + ≤64 蛋白 | k × μ × alpha |
| vfm_allcand | 参照 | alpha |

## 6. 选择规则（与原规则相同）

只用 3 个内折 bank：每个配置、每个药物的损失 = 该 bank query 细胞上 ((pred − truth)/sd)² 的均值，sd = 该内折 fit 集逐药 nanstd（下限 1e-8）；对有信息的 bank 取平均；逐药 argmin；三个 bank 都无信息时回退到索引 1。外折每个冻结臂只评估一次。

## 7. 复现检查（先于一切新结论）

1. 用我的实现在原始数据上重算 original__m_only、original__m_only__protein（整组织另加 original__virtual_fm、original__virtual_fm__protein）的全部内外折网格及外折预测，与保存值的最大绝对差须 ≤ 1e-8。不通过则只报告失败，不报告新臂。
2. 教师复现（额外核对，不作为门槛）：用教师自己的蛋白名单重算 0.5 M + 0.5 实测 P 教师，与 strong-teacher run 保存的外折 measured_p 预测比较，报告最大差与分数；不能复现则如实报告。

## 8. 指标

逐外折：mse_j = 观测测试细胞上 ((pred − truth)/train_sd)² 的均值；折分数 = sqrt(被评价药物上 mse_j 的均值)；主指标 = 5 折均值。同时报告同药物跨细胞 Spearman（跳过常数向量）和 centered MSE（与参考实现相同）。

## 9. 主比较与判据

记 改善% = (基线 5 折均值 − 新臂 5 折均值) / 基线 5 折均值 × 100；胜折 = 新臂折分数更低的折数；逐折相对改善 d_f = (b_f − n_f)/b_f。Nadeau–Bengio 校正配对 t 检验：t = mean(d) / sqrt((1/5 + r)·var(d, ddof=1))，r = 各折 n_test/n_train 的均值，df = 4，双侧 p；同时给 95% 区间。

判定标签（所有比较统一）：改善 ≥ 1% 且胜折 ≥ 4/5 →"过推进线"；改善 > 0 但不满足 →"小幅"；改善 ≤ 0 →"无增益"。

- **P1 面板价值（不同部署输入，故意的）**：m_panel_sel 对 m_only（两场景）；新细胞另加 m_panel_tissue_sel 对 m_tissue（同数据、都用组织）。
- **P2 监督挑选 vs 随机**：m_panel_k16 对 random_k16 种子均值、m_panel_k32 对 random_k32 种子均值（随机臂每折分数 = 5 个种子折分数的平均）；另报 m_panel_sel 对两个随机均值中 5 折均值更低的那个（偏保守）。两种 k 都满足"胜折 ≥ 4/5 且改善 > 0"记为"监督挑选优于随机"，否则"未优于随机"。新细胞的组织版本同样报告（描述性）。
- **P3 收回教师增益比例**：R = (S_m_only − S_panel)/(S_m_only − S_teacher)，S_teacher 用保存的 0.986172（新细胞）/ 1.094881（整组织），同时用我复现的教师；给 5 折均值版本和逐折版本。对 m_panel_sel 为主，其余面板臂描述性报告。
- **P4 CREED 方法在少层部署下的增量（同输入、同数据）**：m_panel_sel__protein 对 m_panel_sel；新细胞另加 m_panel_tissue_sel__protein 对 m_panel_tissue_sel；整组织另加 vfm_panel_sel__protein 对 vfm_panel_sel。推进线判断时，基线还要换成"部署输入 ⊆ 该方法输入的全部直接臂（不含随机、全候选、教师）里 5 折均值最低者"（偏保守），两种都报告。数值图须好于 mask 图和 shuffle 图（同网格）。
- **P5（新细胞）**：m_panel_tissue_sel 对 m_tissue、对 tissue_only；m_panel_tissue_sel__protein 对 m_tissue__protein（均为原始数据重算）。tissue-kernel run 的 0.996534 / 0.994376 用了额外 19 个样本，只作参照列出，不作同数据比较。

次要比较（描述性）：m_panel_sel 对同数据最强"仅 M"可部署臂（新细胞 m_only__protein，整组织 vfm__protein 与 vfm）；m_allcand 对 m_panel_sel（小面板损失多少）；入选 k / w / μ 的分布；各折面板的重叠。

## 10. 稳健性（对每个主比较）

1. 去一折：去掉任一外折后剩余 4 折的改善%，报告最小值（"去掉任一折优势不完全消失"即全部 > 0）。
2. 成组重采样区间（描述性，事先固定）：B = 2000，种子 20261009。药物按药物 ID 有放回重采样（各折共用同一组药物权重）；细胞在新细胞场景按"折内组织簇"有放回重采样，在整组织场景按"折内、每个留出组织内"分层有放回重采样细胞（整组织各折只有 1–6 个组织，无法按组织簇重采样）。每次重算两臂 5 折均值与改善%，报告 2.5%/97.5% 分位与改善 > 0 的比例。
3. 整组织场景 281 药共同面板敏感性：只用 5 个外折都被评价的药物重算折分数和主比较（实际数目以数据为准）。
4. 本实验没有蒸馏，"匹配蒸馏不能解释全部增益"一项不适用。

## 11. 不做的事

不加种子、不扩网格、不删药物/折/组织、不换指标。负结果原样报告。所有数字都来自已被反复用于开发的外折，属于 candidate_only，不是独立确认。
