# 跨层"空间 × 可恢复性"矩阵（新细胞 / 整组织，相同折）：预先登记

登记时间：2026-10-09。本文件在计算任何新臂的外折分数之前写下，上传服务器 run 目录并记录 sha256。之后不按结果修改；若因程序错误必须改动，只在文末追加 ADDENDUM 说明原因，并重跑全部臂。

服务器 run 目录：`/public/home/mengxl/creed-research-runs/crosslayer-matrix-20261009-0001/`
本地目录：`/Users/xlzhexue/Desktop/proj/creed/crosslayer_matrix_20261009/`

## 0. 要回答的问题

论文的框架图需要一张统一的矩阵：**行 = 部署时实测的层 X，列 = 训练时可借用的层 Y**。对每个有序对 (X, Y) 回答两件事：

1. **空间（headroom）**：如果部署时把 Y 也测了，相对只测 X 能改善多少？= gain%(X + 实测 Y 对 X)。
2. **可恢复性（recovered）**：只测 X，但训练时用 X→Y 生成器把 Y 当作"虚拟层"带进核（CREED 的虚拟层基线），能收回多少？= gain%(X + 虚拟 Y 对 X)。
3. **恢复份额** = recovered / headroom（headroom > 0.3% 时才算；否则记"无空间"）。

全部在**完全相同的 5 外折 × 3 内折、相同药物面板、相同保存的评价量、相同的 4 配置超参预算**上完成。这样矩阵里每个格子都可直接比较。两场景：新细胞（new_cell）与整组织留出（tissue）。新细胞另加免费的组织标签 T 作为上下文层行列。

## 1. 数据、划分与边界

- 只用原始 421 个开发细胞：`source-inputs.npz`（M 225 维、AUC 295 药、P 6,692 蛋白含缺失、组织标签 22 类无缺失）；RNA 用 `rna421-20260906-0002/rna_log_cpm.npy`（421 × 34,985，ln(1+CPM)），运行前断言其 `sample_ids.npy` 与 source-inputs 的 `sample_ids` 完全一致；运行前断言 source-inputs 与 19 包的 sha256 与登记值一致。
- **不用额外 19 / 66 / 354 个样本**训练任何矩阵臂。19 包只在复现检查里用来重算保存的 `extra__m_only`（见第 7 节），该臂不进入矩阵。
- 划分：读取 `extra-supervision-20261008-0001/output/<scenario>/fold-f/{inner-0,inner-1,inner-2,outer}/geometry.npz` 的 fit、query、panel。新细胞 5 外折（fit 336–337、query 84–85、295 药）；整组织 5 外折（fit 328–340、query 81–93、每折面板 281–285 药）。
- 评价：每折用保存的 `fold-f/predictions.npz` 中的 truth、train_sd、evaluated；运行前断言其 fit/held/panel 与 outer bank 的 geometry 一致。
- 不读 64/123 保护集、CTRP、GBM、原始 CSV；不修改任何旧 run；不碰其他用户目录。新建的服务器目录只有上面那一个。

## 2. 各层的编码（全部只用当前 bank 的 fit 行统计；query 行只被变换，不参与任何统计）

| 层 | 特征 | fit-only 预处理 | 核 |
|---|---|---|---|
| M | 225 代谢物 | fit 均值/标准差标准化（sd<1e-8 置 1） | RBF，带宽 = fit 两两正平方距离的中位数（`kernel_state`，与原代码相同）。应与保存的 `m_only_kernel` 左上 n×n 块一致 |
| RNA | 34,985 基因 ln(1+CPM) | 按 fit 行方差降序（稳定排序）取前 **3000** 个基因；fit 标准化 | RBF 中位带宽 |
| P | 6,692 蛋白（含缺失） | 候选 = 在 fit 中观测比例 ≥ 50% 的蛋白（预计约 3,350 个）；值：fit 观测均值填补 → fit 标准化 → RBF 中位带宽 = K_val；掩码：候选蛋白的 0/1 观测指示向量 → RBF（不标准化；带宽 = fit 两两正平方距离（即 Hamming 距离）的中位数；无正距离时核取全 1）= K_mask | **K_P = 0.5·K_val + 0.5·K_mask**（cross 核同样组合） |
| T（仅新细胞） | 组织标签 | 无 | T_ij = 1 当且仅当同组织；当前 421 中无未知组织 |

说明：
- RNA 不做 Broad/Sanger 来源校正（rna-learning-curve run 显示校正无益且在整组织略负）。k = 3000 固定不调，使每一层都只有 alpha 一个维度（4 个配置），各层预算相同；这也回应了此前"RNA 网格预算是 M 的两倍"的批评。
- 项目的实测 P 教师用的是 0.5·K_M + 0.5·RBF(值)，没有掩码核。本实验 K_P 显式含掩码信息，因为单层 P 部署时缺失结构本身也是可观测的。为了分解掩码的贡献，另设次要臂 Pval（只用 K_val）。
- 多层实测臂一律**等权平均**：(K_a + K_b)/2、(K_a + K_b + K_c)/3、(K_a + K_b + K_c + T)/4；cross 核同样。所有核对角线为 1，平均后仍为 1。不调权重。

## 3. 虚拟层生成器（CREED 虚拟层基线，每个有序对 X→Y）

- **目标 Z_Y**：Y 层的标准化特征（与 Y 核相同的 fit 标准化），按 fit 行**原始值方差**降序取前 **512** 个：M 全部 225 个；RNA 为前 3000 基因中方差最高的 512 个；P 为候选蛋白中填补后方差最高的 512 个（填补位置标准化后为 0）。
- **生成器**：以 K_X（与预测相同的 X 核）为核的 KRR，目标逐列中心化，λ ∈ {0.1, 1, 10, 100}。
- **交叉拟合**：fit 行按固定种子 `sha256("oof|scenario|fold|bank")` 的前 8 字节随机分 3 份；每份由其余两份训练的生成器预测，得到全部 fit 行的样本外（OOF）虚拟特征 Ẑ_fit。λ 在 fit 内按全部目标列的 OOF MSE 均值选一个（只用 fit 信息，不碰 query 标签）。query 行由全 fit 训练的同 λ 生成器预测得 Ẑ_q。
- **虚拟核**：对 Ẑ_fit 用 `kernel_state`（标准化 + 中位带宽），K_vY = RBF(Ẑ_fit)，H_vY = RBF(Ẑ_q, Ẑ_fit)。这与项目 virtual-FM 核的做法一致（run_extra.py：`fs = kernel_state(fm_train)`）。
- **臂 X+vY**：0.5·K_X + 0.5·K_vY（cross 核同样）。
- **配对置乱对照 X+vY_shuf**：每个 bank 一个固定置换 π（种子 `sha256("pair_shuffle|scenario|fold|bank")`，6 个有序对共用），生成器学 X_i → Z_Y[π(i)]，其余步骤（OOF 划分、λ 选择、核构造、alpha 选择）完全相同。它检验"X+vY 的增益是否只是给 K_X 叠加了一个由 X 导出的一般平滑核"。
- **描述性诊断**：每 bank 每对的 OOF R²（目标列均值与中位数）和选中的 λ，写入 bank_info.json。它表示"特征层面 Y 能被 X 预测多少"，与"功能层面收回多少"对照。

## 4. 模型与超参选择（与原规则相同）

逐药、均值中心化的 masked KRR：alpha ∈ {0.1, 1, 10, 100}；某药在 fit 观测 < 20 时所有 alpha 都返回 fit 均值。每个臂只有 alpha 一个维度（4 个配置）。

选择只用 3 个内折 bank：每个配置、每个药物，损失 = 内折 query 细胞上 ((pred − truth)/sd)² 的均值，sd = 该内折 fit 逐药 nanstd（下限 1e-8）；对有信息的 bank 取平均（等价于求和取 argmin）；逐药 argmin；三个 bank 都无信息时回退到 index 1（alpha = 1）。外折每个臂只评估一次。

## 5. 全部臂（每场景）

| 组 | 臂 | 部署输入 | 核 |
|---|---|---|---|
| (a) 单层 | M, RNA, P | 对应单层 | K_M / K_RNA / K_P |
| (b) 实测多层 | M+RNA, M+P, RNA+P, M+RNA+P | 多层实测 | 等权平均 |
| (c) 虚拟层 | M+vRNA, M+vP, RNA+vP, RNA+vM, P+vM, P+vRNA | 仅 X | 0.5 K_X + 0.5 K_vY |
| (c') 置乱对照 | 上述 6 个的 `_shuf` 版本 | 仅 X | 同上，配对置乱 |
| 次要 | Pval, M+Pval, RNA+Pval | 含 P 值 | 只用 K_val |
| 参照 | null_drug | 无 | 逐药 fit 均值（无网格） |
| 复现 | repro_M_extra19 | M（+19 样本） | 保存的 `m_only_kernel/cross` 全块 + 19 包标签；不进矩阵 |

仅新细胞（组织标签免费）：

| 臂 | 部署输入 | 核 |
|---|---|---|
| T | 组织 | T |
| M+T, RNA+T, P+T | X + 组织 | (K_X + T)/2 |
| M+RNA+P+T | 全部 + 组织 | 四核等权 |

新细胞共 29 个网格臂 + null；整组织 24 个网格臂 + null。

## 6. 指标（与保存值完全一致）

逐外折：mse_j = 观测测试细胞上 ((pred − truth)/train_sd)² 的均值；折分数 = sqrt(被评价药物上 mse_j 的均值)；主指标 = 5 折均值。同时报告同药物跨细胞 Spearman（跳过常数向量，被评价药物上取均值）和 centered MSE（与参考实现 `metrics` 相同）。不删药、不删折、不删组织、不换指标。

## 7. 复现检查（先于一切结论；任一失败只报告失败，不报告矩阵）

1. 从原始 M 重算的 K_M 与保存 `m_only_kernel` 左上 n×n 块 `allclose(rtol=1e-11, atol=1e-12)`，cross 核同样。
2. M 臂（原始数据）的全部内外折 4-alpha 网格与 `grids.npz['original__m_only']` 的最大绝对差 ≤ 1e-8；按选择规则得到的外折预测与 `predictions.npz['original__m_only']` 的最大绝对差 ≤ 1e-8。两场景。
3. repro_M_extra19（保存核全块 + 19 包标签）的内外折网格与 `grids.npz['extra__m_only']`、外折预测与 `predictions.npz['extra__m_only']` 的最大绝对差 ≤ 1e-8。两场景。
4. 工程检查顺序：先用合成数据做 smoke test（dev/，不读真实数据）；再在真实数据上做 dryrun（只算 fold-0 的 3 个内折 bank，核对内折网格，不算外折）；都通过后固定 SHA256SUMS，再跑 main。dryrun 不产生任何外折分数。

## 8. 读出与判据（预先写好）

记 gain%(A 对 B) = mean_f (b_f − a_f)/b_f × 100（逐折相对改善的 5 折均值）；胜折 = a_f < b_f 的折数；Nadeau–Bengio 校正配对 t 检验：t = mean(d)/sqrt((1/5 + r)·var(d, ddof=1))，r = 5 个外折 n_query/n_fit 的均值，df = 4，双侧 p，并给 95% 区间。

**矩阵（每场景；行 X ∈ {M, RNA, P}，列 Y ∈ {M, RNA, P}\{X}）**：
- headroom_meas = gain(X+Y 对 X)（X+Y 用第 5 节的实测臂名，如 X=RNA、Y=M 即 M+RNA）
- recovered = gain(X+vY 对 X)
- shuf = gain(X+vY_shuf 对 X)；virt_vs_shuf = gain(X+vY 对 X+vY_shuf)
- share = recovered / headroom_meas，仅当 headroom_meas > 0.3%；否则记"无空间"
- 三层：gain(M+RNA+P 对 X)
- 每格报告：gain、逐折值、胜折、NB p 与 95% CI

**新细胞 T 行**：gain(X+T 对 X)，X ∈ {M, RNA, P, M+RNA+P}；T 单独作参照。

**次要**：headroom_val = gain(X+Pval 对 X)，X ∈ {M, RNA}；share_val = recovered(X+vP) / headroom_val；Pval 对 P（掩码贡献）。

**标签（统一规则）**
- 空间：headroom ≥ 1% 且胜折 ≥ 4/5 → "有空间"；0.3% ≤ headroom < 1%，或 ≥ 1% 但胜折 < 4/5 → "小幅空间"；headroom < 0.3% → "无空间"。
- 恢复：须同时满足 (i) recovered > 0 且胜折 ≥ 4/5；(ii) virt_vs_shuf > 0 且胜折 ≥ 4/5 → "有恢复"。(i) 成立而 (ii) 不成立 → "增益可由一般平滑解释"。(i) 不成立 → "无恢复"。
- 份额（仅"有空间"或"小幅空间"时）：share ≥ 50% → "大部分收回"；10% ≤ share < 50% → "部分收回"；share < 10% → "基本未收回"。
- 主要（primary）对比 = 两场景各 6 个有序对的 headroom 与 recovered，共 24 个；不做多重比较校正，但在 RESULT 中明确写出对比个数。其余（shuf、三层、T 行、次要）为描述性。

## 9. 预期与解读规则（写在结果之前）

已知（同折）：RNA 单层最强（rna-lc：新细胞 ≈ 0.971，整组织 ≈ 1.088），M 单层最弱（1.012 / 1.120），实测 P 教师 0.5M+0.5P 为 0.986 / 1.095。预期 M→RNA、M→P 有空间；RNA→M、RNA→P 的空间可能很小。无论结果如何，全部格子都报告。

解读规则：
- "有空间 + 有恢复"：虚拟层有价值，写出收回份额。
- "有空间 + 无恢复 / 可由平滑解释"：该层必须实测，虚拟不能替代；写明。
- "无空间"：借用该层对该部署层没有功能价值，CREED 不应在这一格发力；写明。
- 若 virt_vs_shuf 为负或接近 0 但 recovered 为正，必须写"增益来自一般平滑"而不是"来自 Y 的信息"。
- 整组织场景测试组织未在训练中出现，T 不适用；fold 1 的零模型约 1.99，会主导 5 折均值，结果中要提醒。

## 10. 输出

服务器 `output/<scenario>/`：`fold-f_predictions.npz`（压缩：truth、train_sd、evaluated、panel、drug_ids、held、fit、pred__<臂>、sel__<臂>）、`fold-f_inner_losses.npz`、`fold_metrics.csv`、`per_drug_metrics.csv`、`bank_info.json`、`protocol.json`、`summary.json`；`output/analysis.json`、`output/matrix_<scenario>.csv`、`output/comparisons.csv`、`output/matrix_tables.md`。run 目录含 `PLAN.md`、`code/`、`SHA256SUMS`、`run.log`。本地 `RESULT.md`（简体中文）含两场景矩阵表、T 行、诚实解读，并明确标注：这些是反复用于开发的外折（candidate_only），不是独立确认。

## 11. 不做的事

不调核权重；不加 P 图正则；不用 19/66/354 训练；不删药/折；不换指标；不加种子；不在看到外折分数后改任何臂或判据。
