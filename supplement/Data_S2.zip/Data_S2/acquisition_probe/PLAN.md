# 自适应蛋白采集探测（acquisition probe）：预先登记

登记时间：2026-10-09。本文件在计算任何新臂的外折分数之前写好、上传服务器并记录 sha256（服务器 `SHA256SUMS` 同时登记代码哈希）。外折分数出现后不再修改本文件；若必须改动，只在文末追加 ADDENDUM 并说明原因。

## 1. 问题

部署层 M（225 个代谢物），借用层 P（蛋白）。在**每个查询细胞只允许实测 k 个蛋白**的同等预算下，**逐样本自适应地选择测哪 k 个蛋白**，是否比全局静态面板或随机面板收回更多"实测多层"的功能预测价值？这是一个探测实验（probe），目的是判断"自适应采集"这条线值不值得继续投入；判据预先登记，负结果照实报告。

两个场景：new_cell（extra-supervision run 的 output/new_cell banks）和 tissue（output/tissue banks）。**只用原始 421 个开发细胞，不用额外 19 个样本**（它们没有 P）。

## 2. 数据、划分与边界

- 输入：`gdsc-metabolite-full-protein-20260908-0001/output/result/source-inputs.npz`（m、auc、p、tissues、sample_ids、drug_ids、protein_ids）。
- 划分与 M 核：沿用 `extra-supervision-20261008-0001/output/{scenario}/fold-f/{inner-0,inner-1,inner-2,outer}/geometry.npz` 的 fit/query/panel 索引；M 核取保存的 `m_only_kernel` 左上 n_fit 块、`m_only_cross` 左侧 n_fit 列（额外样本行列不用）。
- 评价：每折 `predictions.npz` 的 truth、train_sd、evaluated；不删药物/折/组织。
- 复现门槛（先于一切新结论）：用本实现重算 new_cell 的 `extra__m_only`（含额外 19 行，保存核整块 + 额外 AUC）与 `original__m_only`、tissue 的 `original__m_only` 的内外折网格和外折选择后预测，与保存值最大绝对差 ≤ 1e-8；同时用本实现的指标重算保存预测的折分数，与保存的 fold_metrics.csv 一致。不通过则只报告失败。
- 只读上述 run、protein-panel-20261009-0001（候选规则与 m_allcand 分数交叉核对）、strong-teacher-recoverability-20261008-0001（保存的实测全 P 教师外折预测，仅作参照列）、tissue-kernel-20261009-0001（参照）。不读 privileged-geometry、64/123、CTRP、GBM、原始 CSV；不改任何旧 run。写入只到新目录 `/public/home/mengxl/creed-research-runs/acquisition-probe-20261009-0001/` 与本地 `acquisition_probe_20261009/`。
- 现成虚拟蛋白生成器（gdsc run 各 bank 的 generator-*.npz）的蛋白面板是 3361 个"合格"蛋白、划分也是它自己的，与本实验的候选池（见 §3）不一致，**不复用**；本实验自建生成器（§4）。

## 3. 候选池与编码

- 候选池（每个 bank 单独定）：在该 bank 的 fit 细胞中观测比例 ≥ 90% 且观测方差 > 1e-12 的蛋白（与 protein-panel run 同一规则，约 1750–1950 个）。
- 缺失：候选蛋白在 fit 与 query 中的缺失都用 fit 观测均值填补（query 细胞里"采集"到的若是缺失值，得到的就是 fit 均值）。
- 标准化：用填补后 fit 矩阵的均值/标准差（sd < 1e-8 置 1）。下文"标准化单位"均指此。

## 4. 虚拟 P 生成器（填补未采集的蛋白）

- 模型：多输出、均值中心化的 KRR，M → 标准化候选 P；核 = 保存的 M RBF 中位数核（即 `m_only_kernel` fit 块、`m_only_cross`）。
- 子生成器：把 fit 细胞用固定种子 `default_rng([20261009, 场景号, 折号, bank号, 7])` 置换后均分 3 份；子生成器 g 用其余 2 份训练。
  - fit 行的虚拟值 = 留出它的那个子生成器的预测（3 折 OOF）。
  - query 行保留 3 个子生成器的预测：均值 = 虚拟值 v_j(i)；三者标准差（ddof=0）= 该细胞该蛋白的不确定度 u_j(i)。
- 生成器 alpha（每折一个标量，网格 {0.1, 1, 10, 100}）：只在 3 个内折 bank 上选——对每个内折 bank，用其 fit 细胞训练 3 个子生成器，取均值预测内折 query 细胞的标准化 P，在 query 的**观测**条目上算均方重建误差；三个 bank 的误差相加，取 argmin。选出的 alpha 用于该折全部 4 个 bank。

## 5. 响应头（每个 bank 固定一次，不按策略重训）

逐药、均值中心化的 masked KRR（与原代码相同；某药 fit 观测 < 20 时返回 fit 均值），alpha 网格 {0.1, 1, 10, 100}。

- H_meas：核 = 0.5·K_M + 0.5·K_P，K_P 为 fit 细胞**实测**（填补后）候选 P 的 RBF 中位数核（fit 矩阵标准化、带宽 = fit 两两正平方距离中位数；与 protein-panel 的 `protein_kernel` 同构造）。k = all 时它就是 protein-panel run 的 m_allcand（实测候选 P 教师）。
- H_virt：同上，但 fit 侧 P 用 OOF 虚拟 P（按虚拟矩阵自身的 fit 矩估计标准化、自身中位数带宽）。k = 0 时它就是"虚拟 P 臂"。
- 查询时：查询细胞的 P 向量 = 虚拟均值，其中被采集的 k 个蛋白换成实测值（标准化单位）；对 H_meas 把它换回原始单位后走 H_meas 的标准化与带宽；对 H_virt 走虚拟矩阵的标准化与带宽；算与 fit 细胞的交叉核，用固定的头预测。
- 逐药 alpha：每个头在 3 个内折 bank 上按原规则各选一次（§6）：H_meas 用**实测**候选 P 作为内折 query 输入（即 k = all）；H_virt 用 **k = 0 的虚拟均值**作为内折 query 输入。外折该头的系数由此固定，所有策略共用。

## 6. 选择规则（与原规则相同）

只用 3 个内折 bank：配置 × 药物的损失 = 该 bank query 细胞上 ((pred − truth)/sd)² 的均值，sd = 该内折 fit 集逐药 nanstd（下限 1e-8）；三个 bank 的损失相加、计数相加，逐药取平均后 argmin；三个 bank 都无信息时回退到索引 1（alpha = 1）。策略本身没有超参数。

## 7. 策略与预算

k ∈ {0, 8, 16, 32, 64, all}。k = 0 为全虚拟输入，k = all 为全实测输入；两端在两个头下都报告。中间 k 的策略（都只用候选池）：

| 策略 | 定义 | 性质 |
|---|---|---|
| random | 5 个固定种子 s∈{0..4}，`default_rng([20261009, 场景号, 折号, 3, s])` 置换候选池取前 k（同种子下嵌套），所有细胞相同 | 对照；报告 5 种子均值（random_mean，折分数 = 5 个种子折分数的平均）与范围 |
| variance | fit 观测值方差（原始单位）最大的前 k 个 | 无监督静态 |
| static | 任务相关性 w_j = Σ_药物 \|Spearman(P_j, AUC)\|（fit 细胞、成对完整、成对数 < 10 或任一侧常数记 0）前 k 个 | 与 protein-panel run 相同 |
| **adaptive** | 每个查询细胞 i 单独取 w_j · u_j(i) 前 k 个（既重要又预测不准的蛋白） | 主方法 |
| adaptive_surprise | 每个细胞取 w_j · \|v_j(i)\| 前 k 个（标准化单位下 fit 均值为 0，即"预测偏离均值"） | 次要 |
| oracle_static | w_j 用全部 421 个细胞算（泄漏），再取前 k | **仅作静态选择上界的参照，不是方法** |

同分按候选列号升序（stable argsort）。

## 8. 指标

与参考实现相同：逐外折逐药 mse_j = 观测测试细胞上 ((pred − truth)/train_sd)² 的均值；折分数 = sqrt(被评价药物上 mse_j 的均值)；主指标 = 5 折均值。同时报告同药物跨细胞 Spearman（跳过常数向量）与 centered MSE。

另报告每个（头, 策略, k）的收回比例 R = (S_h(k=0) − S_h(策略, k)) / (S_h(k=0) − S_teacher)，其中 S_h(k=0) 是该头 k=0（全虚拟）的 5 折均值，S_teacher = H_meas 在 k=all 的 5 折均值（实测候选 P 教师）。

## 9. 全部臂（每个场景）

- 参照/复现：m_only（original__m_only 复现）、null_drug（逐药 fit 均值）、teacher_saved（strong-teacher run 保存的全 P 教师 measured_p，约 3350 蛋白，仅参照）。
- 两个头 × {k=0 虚拟、k=all 实测、k∈{8,16,32,64} × {random_s0..4, random_mean, variance, static, adaptive, adaptive_surprise, oracle_static}}。
- 交叉核对（非门槛）：H_meas k=all 的折分数与 protein-panel run 保存的 m_allcand 折分数的最大差。

## 10. 主比较与通过判据（预先登记）

统计：改善% = (基线 5 折均值 − 新臂 5 折均值)/基线 × 100；胜折 = 新臂折分数更低的折数；逐折相对改善 d_f = (b_f − n_f)/b_f；Nadeau–Bengio 校正配对 t：t = mean(d)/sqrt((1/5 + r)·var(d, ddof=1))，r = 各折 n_test/n_train 的均值，df = 4，双侧 p；给 95% 区间。不做多重比较校正。

主比较（k = 16 与 k = 32 各做一次；H_meas 为主头，H_virt 为次头，两者都报告）：
- C1 adaptive vs static
- C2 adaptive vs random_mean
- C3 adaptive vs variance

**通过判据（PASS）**：在**至少一个场景**下，**主头 H_meas** 满足全部四项：
1. k=16 与 k=32 两处，adaptive 的 5 折均值都低于 static，胜折 ≥ 4/5，校正 p < 0.10；
2. k=16 与 k=32 两处，adaptive 的 5 折均值都低于 random_mean，胜折 ≥ 4/5，校正 p < 0.10；
3. adaptive 的收回比例曲线在 k ∈ {0, 8, 16, 32, 64, all} 上单调非减（等价于 H_meas 下 adaptive 的 5 折均值 sRMSE 随 k 非增；k=all 为教师）；
4. 以上均用预先登记的指标、折与臂，不做任何改动。

否则 FAIL，并逐条写明哪一项未满足。H_virt 下同样的四项只作次要报告（标注"次头"），不改变 PASS/FAIL。

次要比较（描述性）：adaptive_surprise 对 static / random_mean；static 对 random_mean（应与 protein-panel 的 P2 一致）；oracle_static 对 static（静态选择的上界距离）；adaptive 对 oracle_static；H_virt 与 H_meas 在同策略同 k 下的差；两头 k=all 与 k=0 的两端。

## 11. 计算与输出

- 服务器：8 线程，前台命令 < 9 分钟，长任务 nohup + 等待循环；预计每场景 < 30 分钟，故保留 5 个随机种子。
- 阶段：repro（复现门槛）→ dryrun（fold-0 内折 bank，生成器 alpha 与头 alpha 选择，不碰外折）→ main（两场景）→ analyze。
- 输出：`output/{scenario}_main/fold_metrics.csv`（scenario, head, policy, k, fold, score, spearman, centered_mse）、`bank_info.json`、`fold-f_predictions.npz`（主臂的外折预测，压缩）、`fold-f_selection.npz`；`output/analysis/summary.json`；`run.log`、`SHA256SUMS`、`PLAN.md`。本地 RESULT.md（中文）含全部臂、全部折、收回曲线表、主比较、PASS/FAIL 与注意事项。

## 12. 不做的事

不加种子、不扩网格、不换头、不删药物/折/组织、不在看到外折分数后改判据或指标。所有数字来自已被反复用于开发的外折，属于 candidate_only，不是独立确认。面板的"实测值"取自全蛋白组数据中的对应列，不是独立的靶向检测。
