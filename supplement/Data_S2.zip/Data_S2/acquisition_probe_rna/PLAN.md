# 自适应 RNA 基因面板采集探测（acquisition probe，RNA 版）：预先登记

登记时间：2026-10-09。本文件在计算任何新臂的外折分数之前写好、上传服务器并记录 sha256（服务器 `SHA256SUMS` 同时登记代码哈希）。外折分数出现后不再修改本文件；若必须改动，只在文末追加 ADDENDUM 并说明原因。

本探测与同日的蛋白版探测 `acquisition-probe-20261009-0001`（PLAN.md sha256 `26974b9b…98bb45`）**设计完全镜像，只换借用层**：蛋白 → RNA。两者可直接对照。

服务器 run 目录：`/public/home/mengxl/creed-research-runs/acquisition-probe-rna-20261009-0001/`
本地目录：`/Users/xlzhexue/Desktop/proj/creed/acquisition_probe_rna_20261009/`

## 1. 问题

部署层 M（225 个代谢物），借用层 RNA。在**每个查询细胞只允许实测 k 个基因**的同等预算下，**逐样本自适应地选择测哪 k 个基因**，是否比全局静态基因面板或随机面板收回更多"实测 M+RNA"的功能预测价值？这是一个探测实验（probe）；判据预先登记，负结果照实报告。

两个场景：new_cell（extra-supervision run 的 output/new_cell banks）和 tissue（output/tissue banks）。**只用原始 421 个开发细胞，不用额外 19 / 66 / 354 个样本训练任何新臂**（19 包只在复现保存的 `extra__m_only` 时用）。

## 2. 数据、划分与边界

- 输入：`gdsc-metabolite-full-protein-20260908-0001/output/result/source-inputs.npz`（m、auc、tissues、sample_ids、drug_ids；sha256 `52d71517…cd637`）；RNA 用 `rna421-20260906-0002/rna_log_cpm.npy`（421 × 34,985，ln(1+CPM)，sha256 `5eb953ea…718cf`），运行前断言其 `sample_ids.npy` 与 source-inputs 的 `sample_ids` 完全一致；`gene_symbols.npy` 只用于在诊断里给基因命名。
- 划分与 M 核：沿用 `extra-supervision-20261008-0001/output/{scenario}/fold-f/{inner-0,inner-1,inner-2,outer}/geometry.npz` 的 fit/query/panel 索引；M 核取保存的 `m_only_kernel` 左上 n_fit 块、`m_only_cross` 左侧 n_fit 列（额外样本行列只在复现 `extra__m_only` 时用）。
- 评价：每折 `predictions.npz` 的 truth、train_sd、evaluated；不删药物/折/组织。
- 只读上述两个 run、`crosslayer-matrix-20261009-0001/`（RNA 核配方、M→RNA 虚拟层生成器代码、保存的 M+RNA / M+vRNA 外折预测与内折损失，用于复现）、`acquisition-probe-20261009-0001/`（只读其 PLAN 与代码以镜像设计，不写入）。不读 privileged-geometry、64/123、CTRP、GBM、原始 CSV；不改任何旧 run；不碰其他用户目录。写入只到上面那一个新服务器目录与本地目录。

## 3. 复现门槛（先于一切新结论；任一失败只报告失败）

1. 保存臂：用本实现重算 new_cell 与 tissue 的 `original__m_only`（fit 块核）与 `extra__m_only`（保存核整块 + 19 包标签）的全部内外折网格和外折选择后预测，与 `grids.npz` / `predictions.npz` 保存值最大绝对差 ≤ 1e-8；同时用本实现的指标重算保存预测的折分数，与保存的 `fold_metrics.csv` 一致。
2. 矩阵 run 的两端：
   - **k = all 端**：H_meas（§5）在 k = all 的外折预测与矩阵 run `output/{scenario}/fold-f_predictions.npz['pred__M+RNA']` 最大绝对差 ≤ 1e-6；其对 m_only 的 gain%（逐折相对改善的 5 折均值，与矩阵 `analyze.py` 同定义）与矩阵 `analysis.json` 登记值一致到 ≤ 1e-6：new_cell headroom **+3.078810120332858%**，tissue **+2.1947192412669287%**。
   - **k = 0 端（矩阵配方）**：参照臂 `matrix_vRNA`（§4.1，逐行照搬矩阵 run 的生成器与虚拟核代码）的外折预测与 `pred__M+vRNA` 最大绝对差 ≤ 1e-6；其 gain% 与登记值一致到 ≤ 1e-6：new_cell recovered **+1.0555808085535539%**，tissue **+0.716058946743318%**。
   - 内折：H_meas 与 matrix_vRNA 在 3 个内折 bank 上的逐药损失与矩阵 `fold-f_inner_losses.npz` 的 `M+RNA__inner-j__loss`、`M+vRNA__inner-j__loss` 最大绝对差 ≤ 1e-8（dryrun 阶段即可核对，不涉及外折）。
3. **说明（预先写明）**：本探测自己的 k = 0 臂 `H_virt|virtual|0`（§4.2 的三子生成器、3000 个候选基因全部为目标、alpha 在内折 bank 上选）与矩阵的 M+vRNA（512 个目标基因、λ 在 fit 内按 OOF 选、query 由全 fit 生成器预测）**配方不同，数值不会完全相等**；两者的差只作描述性报告，不是门槛。收回比例（§8）以本探测各头自己的 k = 0 为起点。

## 4. 候选池、编码与虚拟 RNA

### 4.0 候选池与编码（每个 bank 单独定，只用 fit 行统计）
- 候选池 = 矩阵 run RNA 核所用的 fit-only **方差最高的前 3000 个基因**（`argsort(-var_fit, kind='stable')[:3000]`，ln(1+CPM) 原始单位的方差）。无缺失值，不需填补。
- 标准化：fit 均值 / 标准差（sd < 1e-8 置 1）。下文"标准化单位"均指此。K_RNA = RBF，带宽 = fit 两两正平方距离中位数（与矩阵 run 的 `kernel_state` 相同）。

### 4.1 参照臂 matrix_vRNA（矩阵配方，只为复现 k = 0 端）
照搬 `crosslayer.py` 的 `generator`、`kernel_state`、`rbf`、`stable_seed`：目标 = 3000 个标准化候选基因中方差最高的前 512 个；K_M 为核的 KRR，λ ∈ {0.1, 1, 10, 100} 在 fit 内按 3 折 OOF 均方误差选（种子 `sha256("oof|scenario|fold|bank")` 前 8 字节）；fit 行取 OOF 预测，query 行由全 fit 生成器预测；虚拟核 = `kernel_state(OOF)` 的 RBF；臂 = 0.5·K_M + 0.5·K_v；逐药 alpha 按 §6 规则在内折 bank 上选。它**不参与**任何策略比较，只作参照与复现。

### 4.2 探测自己的虚拟 RNA 生成器（填补未采集的基因；镜像蛋白版 §4）
- 模型：多输出、均值中心化的 KRR，M → 全部 3000 个标准化候选基因；核 = 保存的 M RBF 中位数核（`m_only_kernel` fit 块、`m_only_cross`）。
- 子生成器：把 fit 细胞用固定种子 `default_rng([20261009, 场景号, 折号, bank号, 7])` 置换后均分 3 份（与蛋白版同一种子，因此同一 bank 的 fit 行子划分与蛋白版完全相同）；子生成器 g 用其余 2 份训练。
  - fit 行的虚拟值 = 留出它的那个子生成器的预测（3 折 OOF）。
  - query 行保留 3 个子生成器的预测：均值 = 虚拟值 v_j(i)；三者标准差（ddof=0）= 该细胞该基因的不确定度 u_j(i)。
- 生成器 alpha（每折一个标量，网格 {0.1, 1, 10, 100}）：只在 3 个内折 bank 上选——对每个内折 bank，用其 fit 细胞训练 3 个子生成器，取均值预测内折 query 细胞的标准化基因，算均方重建误差（全部条目，RNA 无缺失）；三个 bank 的误差相加，取 argmin。选出的 alpha 用于该折全部 4 个 bank。

## 5. 响应头（每个 bank 固定一次，不按策略重训）

逐药、均值中心化的 masked KRR（与原代码相同；某药 fit 观测 < 20 时返回 fit 均值），alpha 网格 {0.1, 1, 10, 100}。

- **H_meas**：核 = 0.5·K_M + 0.5·K_RNA，K_RNA 为 fit 细胞**实测** 3000 个候选基因的 RBF 中位数核（fit 标准化）。k = all 时它就是矩阵 run 的 M+RNA（实测 RNA 教师）。
- **H_virt**：同上，但 fit 侧 RNA 用 §4.2 的 OOF 虚拟基因（按虚拟矩阵自身的 fit 矩估计标准化、自身中位带宽）。k = 0 时它就是本探测的"虚拟 RNA 臂"。
- 查询时：查询细胞的 RNA 向量 = 虚拟均值 v(i)，其中被采集的 k 个基因换成实测值（标准化单位）；对 H_meas 把它换回原始单位后走 H_meas 的标准化与带宽；对 H_virt 走虚拟矩阵的标准化与带宽；算与 fit 细胞的交叉核，用固定的头预测。
- 逐药 alpha：每个头在 3 个内折 bank 上按 §6 规则各选一次：H_meas 用**实测**候选基因作为内折 query 输入（即 k = all；与矩阵 M+RNA 的选择完全相同）；H_virt 用 **k = 0 的虚拟均值**作为内折 query 输入。外折该头的系数由此固定，所有策略共用。

## 6. 选择规则（与原规则相同）

只用 3 个内折 bank：配置 × 药物的损失 = 该 bank query 细胞上 ((pred − truth)/sd)² 的均值，sd = 该内折 fit 集逐药 nanstd（下限 1e-8）；三个 bank 的损失相加、计数相加，逐药取平均后 argmin；三个 bank 都无信息时回退到索引 1（alpha = 1）。策略本身没有超参数。

## 7. 策略与预算

k ∈ {0, 8, 16, 32, 64, 128, 256, all}。k = 0 为全虚拟输入，k = all 为全实测输入；两端在两个头下都报告。中间 k 的策略（都只在 3000 个候选基因里选）：

| 策略 | 定义 | 性质 |
|---|---|---|
| random | 5 个固定种子 s∈{0..4}，`default_rng([20261009, 场景号, 折号, 3, s])` 置换候选池取前 k（同种子下嵌套），所有细胞相同 | 对照；报告 5 种子均值（random_mean，折分数 = 5 个种子折分数的平均）与范围。候选池本身已是方差筛选过的，所以"池内随机"就是 random，不另设臂 |
| variance | fit 方差（原始 ln(1+CPM) 单位）最大的前 k 个 | 无监督静态（即全基因组方差最高的前 k 个） |
| mean_expr | fit 均值表达（ln(1+CPM)）最高的前 k 个 | 无监督静态的另一选择 |
| static | 任务相关性 w_j = Σ_药物 \|Spearman(gene_j, AUC)\|（fit 细胞、该药观测细胞上、观测数 < 10 或任一侧常数记 0）前 k 个 | 全局监督面板 |
| **adaptive** | 每个查询细胞 i 单独取 w_j · u_j(i) 前 k 个（既重要又预测不准的基因） | 主方法 |
| adaptive_surprise | 每个细胞取 w_j · \|v_j(i)\| 前 k 个（标准化单位下 fit 均值为 0，即"预测偏离均值"） | 次要 |
| oracle_static | w_j 用全部 421 个细胞算（泄漏），再取前 k | **仅作静态选择上界的参照，不是方法** |

同分按候选列号升序（stable argsort）。

## 8. 指标

与参考实现相同：逐外折逐药 mse_j = 观测测试细胞上 ((pred − truth)/train_sd)² 的均值；折分数 = sqrt(被评价药物上 mse_j 的均值)；主指标 = 5 折均值。同时报告同药物跨细胞 Spearman（跳过常数向量）与 centered MSE。

收回比例 R(头, 策略, k) = (S_h(k=0) − S_h(策略, k)) / (S_h(k=0) − S_teacher)，其中 S_h(k=0) 是该头 k=0（全虚拟输入）的 5 折均值，S_teacher = H_meas 在 k=all 的 5 折均值（实测 RNA 教师 = 矩阵 M+RNA）。对每个（头, 策略）另报告 **k50 / k80** = 使 R ≥ 50% / ≥ 80% 的最小 k（在 {8,16,32,64,128,256} 中找；都不满足时若 k=all 满足记 "all"，否则记 "—"）。

## 9. 全部臂（每个场景）

- 参照/复现：m_only（original__m_only 复现）、null_drug（逐药 fit 均值）、matrix_vRNA（§4.1，矩阵 M+vRNA 复现）。
- 两个头 × {k=0 虚拟、k=all 实测、k∈{8,16,32,64,128,256} × {random_s0..4, random_mean, variance, mean_expr, static, adaptive, adaptive_surprise, oracle_static}}。

## 10. 主比较与通过判据（预先登记，与蛋白版相同）

统计：改善% = (基线 5 折均值 − 新臂 5 折均值)/基线 × 100；另报告逐折相对改善的均值 gain%（矩阵 run 的定义）；胜折 = 新臂折分数更低的折数；逐折相对改善 d_f = (b_f − n_f)/b_f；Nadeau–Bengio 校正配对 t：t = mean(d)/sqrt((1/5 + r)·var(d, ddof=1))，r = 各折 n_test/n_train 的均值，df = 4，双侧 p；给 95% 区间。不做多重比较校正。

主比较（k = 16 与 k = 32 各做一次；H_meas 为主头，H_virt 为次头，两者都报告）：
- C1 adaptive vs static
- C2 adaptive vs random_mean
- C3 adaptive vs variance；C3' adaptive vs mean_expr

**通过判据（PASS）**：在**至少一个场景**下，**主头 H_meas** 满足全部四项：
1. k=16 与 k=32 两处，adaptive 的 5 折均值都低于 static，胜折 ≥ 4/5，校正 p < 0.10；
2. k=16 与 k=32 两处，adaptive 的 5 折均值都低于 random_mean，胜折 ≥ 4/5，校正 p < 0.10；
3. adaptive 的收回比例曲线在 k ∈ {0, 8, 16, 32, 64, 128, 256, all} 上单调非减（等价于 H_meas 下 adaptive 的 5 折均值 sRMSE 随 k 非增；k=all 为教师）；
4. 以上均用预先登记的指标、折与臂，不做任何改动。

否则 FAIL，并逐条写明哪一项未满足。H_virt 下同样的四项只作次要报告（标注"次头"），不改变 PASS/FAIL。C3/C3' 为主比较但不进入 PASS 判据（与蛋白版一致）。

次要比较（描述性）：adaptive_surprise 对 static / random_mean；static 对 random_mean；oracle_static 对 static（静态选择的上界距离）；adaptive 对 oracle_static；adaptive / static 对 m_only；H_virt 与 H_meas 在同策略同 k 下的差；两头 k=all 与 k=0 的两端；H_virt k=0 对 matrix_vRNA（两种虚拟配方的差）。

## 11. 计算与输出

- 服务器：8 线程（OMP/OPENBLAS/MKL），同机另有蛋白版探测在跑，不超过 8 线程；前台命令 < 9 分钟，长任务 nohup + 等待循环；预计每场景 < 20 分钟（目标 < 40 分钟），保留 5 个随机种子。
- 阶段：repro（§3 门槛 1–2，含 k=all 与 matrix_vRNA 两端的外折复现；不产生任何新臂外折分数）→ dryrun（fold-0 内折 bank：生成器 alpha、头 alpha、内折损失与矩阵核对；不碰外折）→ main（两场景）→ analyze。
- 输出：`output/{scenario}_main/fold_metrics.csv`（scenario, head, policy, k, fold, score, spearman, centered_mse）、`bank_info.json`、`fold-f_predictions.npz`（主臂与参照臂外折预测，压缩）、`fold-f_selection.npz`、`summary.json`；`output/analysis/summary.json`；run 目录含 `PLAN.md`、`code/`、`SHA256SUMS`、`run.log`。本地 RESULT.md（中文）含全部臂、全部折、收回曲线表、k50/k80 表、主比较（p 与胜折）、PASS/FAIL 与注意事项。

## 12. 不做的事

不加种子、不扩网格、不换头、不删药物/折/组织、不在看到外折分数后改判据或指标。所有数字来自已被反复用于开发的外折，属于 candidate_only，不是独立确认。面板的"实测值"取自 bulk RNA-seq 全转录组数据的对应列，不是独立的靶向面板检测；头固定不按策略重训；结论只在 3000 个候选基因内有效（candidate_only）。
