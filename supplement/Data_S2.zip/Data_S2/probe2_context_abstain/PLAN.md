# 探测 2：上下文自适应蛋白面板（头重训）与 M 侧不确定度弃答：预先登记

登记时间：2026-10-09（服务器时间以 `PLAN_REGISTERED_AT.txt` 为准）。本文件在计算任何新臂的外折分数之前写好、上传服务器 run 目录并记录 sha256（`SHA256SUMS` 同时登记全部代码的哈希）。外折分数出现后不再修改本文件；若必须改动，只在文末追加 ADDENDUM 说明原因。

- 服务器 run 目录：`/public/home/mengxl/creed-research-runs/probe2-context-abstain-20261009-0001/`（新建，运行前不存在）
- 本地目录：`/Users/xlzhexue/Desktop/proj/creed/probe2_context_abstain_20261009/`

## 0. 背景与两个假设

逐样本自适应采集探测（acquisition-probe-20261009-0001）在"头固定 + 虚拟 P 填补"的设定下失败：k ≤ 64 的任何策略只收回实测 P 教师增益的 2–15%，adaptive = static，不确定度代理与任务相关性反向。但更早的静态面板 run（protein-panel-20261009-0001）把头在 k 个实测蛋白上**重训**，k = 64 收回 64–74%，且监督挑选显著好于随机。本探测不再重复"固定头 + 虚拟填补"的设计，改测两个更便宜的假设：

- **A（上下文自适应面板，头重训）**：按查询细胞的上下文（组织 / 代谢组聚类）选择不同的 k 蛋白面板，每个面板的头在全部 fit 细胞上用该面板的实测值重训，是否好于全局静态面板？是否好于"同样多的头、随机面板"？
- **B（弃答治理）**：只用 M 和 fit 侧量算出的逐细胞不确定度，能否把虚拟层臂（M+vRNA、M+vP）误差最大的细胞挑出来弃答？这是对保存预测的纯分析。

## 1. 数据、划分与边界

- 只用原始 421 个开发细胞（source-inputs.npz：m、auc、p、tissues、sample_ids、drug_ids、protein_ids）；RNA 只在 B 部分重拟合生成器时读取 `rna421-20260906-0002/rna_log_cpm.npy`（运行前断言 sample_ids 与 source-inputs 一致）。**不用额外 19 个样本训练任何新臂**；19 包（`extra-supervision-20261008-0001/resources/m_gdsc_extra19.npz`）的 AUC 只在复现 `extra__m_only` 时读取。
- 划分与 M 核：沿用 `extra-supervision-20261008-0001/output/{scenario}/fold-f/{inner-0,inner-1,inner-2,outer}/geometry.npz` 的 fit/query/panel；K_M 取保存 `m_only_kernel` 左上 n_fit 块、`m_only_cross` 左侧 n_fit 列。两场景：new_cell、tissue。
- 评价：每折 `predictions.npz` 的 truth、train_sd、evaluated；不删药物/折/组织。
- 静态基线复用：protein-panel-20261009-0001 的候选规则、相关性打分、随机面板种子与 `output/{scenario}_main/fold-f_predictions.npz` 中保存的 `m_panel_k*`、`random_k*`、`m_allcand`、`teacher_saved` 预测（只读，用于复现核对与参照列）。
- B 部分读取 crosslayer-matrix-20261009-0001 的 `output/{scenario}/fold-f_predictions.npz`（`pred__M`、`pred__M+vRNA`、`pred__M+vP`、`pred__M+RNA`、`pred__M+P`）与 `bank_info.json`（生成器 λ、OOF R²，用于核对重拟合）。该 run **没有保存子生成器输出**，故 u1 需要按其代码在 fit 内重拟合（§5）。
- 不读 64/123、CTRP、GBM、原始 CSV、privileged-geometry、strong-teacher；不修改任何旧 run。写入只到上面两个新目录。

## 2. 复现门槛（先于一切新结论；任一不通过只报告失败）

1. 两场景全部 bank：我的 M 臂网格 vs `grids.npz['original__m_only']`、保存核全块 + 19 包标签的网格 vs `grids.npz['extra__m_only']`，最大绝对差 ≤ 1e-8；外折选择后预测 vs `predictions.npz` 对应键 ≤ 1e-8。
2. 两场景：global_static_k{8,16,32,64} 的外折预测 vs protein-panel 保存的 `m_panel_k{k}` ≤ 1e-8；m_allcand vs 保存 `m_allcand` ≤ 1e-8；random_global_k{16,32}_s{0,1,2} vs 保存 `random_k{k}_s{s}` ≤ 1e-8（同种子）。
3. 指标：用我的指标重算 protein-panel 保存预测的折分数，与其 `fold_metrics.csv` 一致（≤ 1e-12）；重算 extra-supervision 保存预测（original__m_only、extra__m_only）的折分数，与其 `fold_metrics.csv` 一致。
4. B 部分：重拟合的 M→RNA、M→P 生成器所选 λ 与 matrix run `bank_info.json` 记录的 λ 完全相同，OOF R² 均值相差 ≤ 1e-9。

## 3. A 部分：上下文自适应面板（M 部署，P 借用；两场景；原始 421）

### 3.1 候选池与相关性（每个 bank，只用 fit 细胞；与 protein-panel 相同）
- 候选：fit 中观测比例 ≥ 90% 且观测方差 > 1e-12 的蛋白。
- 全局相关性 w_global_j = Σ_药物 |Spearman(P_j, AUC)|（成对完整行；成对数 < 10 或任一侧常数记 0；平均秩）。
- 上下文相关性 w_ctx_j：同一公式，只用该上下文内的 fit 细胞（成对数 < 10 同样记 0）。
- 收缩：w = (n_c/(n_c+n0))·w_ctx + (n0/(n_c+n0))·w_global，**n0 = 10**。
- 面板 = w 前 k 个（降序，稳定排序，同分按蛋白列号升序），k ∈ {8, 16, 32, 64}。

### 3.2 上下文
- **tissue（仅 new_cell）**：fit 内细胞数 ≥ 8 的组织各有自己的面板；其余组织（含 query 中训练未见的组织）用全局面板。查询细胞用自己组织的面板。
- **cluster（两场景）**：fit 的 M 按 fit 均值/标准差标准化（sd < 1e-8 置 1，与核相同）；k-means K = 5，`np.random.default_rng(20261009)`，k-means++ 初始化，n_init = 10（取惯性最小者），Lloyd 迭代至分配不变或 100 轮，空簇以离最近中心最远的点补入。簇内 fit 细胞 ≥ 8 的簇有自己的面板，否则用全局面板。查询细胞分到同一标准化空间里最近的中心。
- 内折 bank 的上下文与面板只用该 bank 的 fit 细胞重算。

### 3.3 核与头
- 面板核：fit/query 的面板蛋白缺失用 fit 观测均值填补，按填补后 fit 矩阵标准化，RBF 中位带宽（与 `protein_kernel` 相同）。K = 0.5·K_M + 0.5·K_panel。
- 头：逐药、均值中心化的 masked KRR（与原代码相同；某药 fit 观测 < 20 时返回 fit 均值），alpha ∈ {0.1, 1, 10, 100}。**每个不同的面板一个头，在全部 fit 细胞上训练**；查询细胞的预测取它所属上下文面板的头。相同面板的上下文共用一个头。
- 每个策略在每个 bank 产出一个 (4 alpha × query × 药物) 网格；alpha 逐药只在 3 个内折 bank 上选（§6），同一策略的所有上下文共用逐药 alpha。

### 3.4 全部臂（每场景）

| 臂 | 部署输入 | 定义 | 网格 |
|---|---|---|---|
| m_only | 仅 M | 复现 original__m_only（k = 0 端） | alpha |
| repro_extra_m_only | M（+19 样本） | 复现 extra__m_only（仅复现，不进比较） | alpha |
| global_static_k{8,16,32,64} | M + k 蛋白 | 全局 w 前 k（= protein-panel m_panel_k） | alpha |
| tissue_adaptive_k{8,16,32,64}（仅 new_cell） | M + 组织标签 + k 蛋白 | §3.2 组织面板 | alpha |
| cluster_adaptive_k{8,16,32,64} | M + k 蛋白 | §3.2 聚类面板 | alpha |
| matched_random_tissue_k{k}_s{0,1,2}（仅 new_cell） | M + 组织标签 + k 随机蛋白 | 与 tissue_adaptive 相同的上下文划分与头数：每个有面板的上下文和"全局槽"各抽一个候选池随机置换取前 k（同种子下按 k 嵌套）；`default_rng([20261009, 场景号, 折号, bank号, 1, s])`，先抽全局槽，再按组织名排序逐个抽 | alpha |
| matched_random_cluster_k{k}_s{0,1,2} | M + k 随机蛋白 | 同上，对 cluster 划分；`default_rng([20261009, 场景号, 折号, bank号, 2, s])`，先全局槽，再按簇号 0..4 | alpha |
| random_global_k{8,16,32,64}_s{0,1,2} | M + k 随机蛋白 | 所有细胞同一随机面板；`default_rng([20261009, 场景号, 折号, bank号, s])` 置换候选池取前 k（k = 16/32 与 protein-panel 的 random_k 同种子，应逐位相同） | alpha |
| m_allcand | M + 全候选约 1800 蛋白 | k = all 端（候选池教师） | alpha |
| teacher_fullP_saved | M + 全 P 约 3350 蛋白 | protein-panel 保存的 `teacher_saved`，仅参照 | — |
| null_drug | 无 | 逐药 fit 均值 | — |

场景号 new_cell = 0、tissue = 1；bank 号 inner-0/1/2 = 0/1/2，outer = 3。随机臂的折分数汇总为种子均值（`*_mean`：每折取 3 个种子折分数的平均）。

### 3.5 读出
- 收回比例 R(策略, k) = (S_m_only − S_策略,k)/(S_m_only − S_teacher)，S 为 5 折均值；主教师 = m_allcand（k = all 端），同时用 teacher_fullP_saved 报告。
- 描述性：各上下文面板与全局面板在 k = 16 的 Jaccard、查询细胞落入各上下文的数目、簇大小、入选 alpha 的分布。

### 3.6 主比较与判据（A）
统计（全文统一）：改善% = (基线 5 折均值 − 新臂 5 折均值)/基线 × 100；胜折 = 新臂折分数更低的折数；逐折 d_f = (b_f − n_f)/b_f；Nadeau–Bengio 校正配对 t：t = mean(d)/sqrt((1/5 + r)·var(d, ddof=1))，r = 各折 n_query/n_fit 的均值，df = 4，双侧 p；95% 区间。不做多重比较校正。

主比较（k = 16 与 k = 32 各一次）：
- A1 tissue_adaptive vs global_static（new_cell）
- A2 cluster_adaptive vs global_static（new_cell 与 tissue）
- 各自对应的 matched_random 均值：A1r tissue_adaptive vs matched_random_tissue_mean；A2r cluster_adaptive vs matched_random_cluster_mean。

**PASS A**：存在一个场景和一个自适应变体，使得 (i) 在 k = 16 与 k = 32 两处都：自适应 5 折均值低于 global_static、胜折 ≥ 4/5、校正 p < 0.10；且 (ii) 在 k = 16 与 k = 32 两处都：自适应 5 折均值低于对应 matched_random 均值且胜折 ≥ 3/5。否则 **FAIL A**，逐条写明未满足项。

次要（描述性）：k = 8、64 处同样的比较；matched_random 均值 vs random_global 均值（"更多头"本身的效应）；global_static vs random_global 均值（应与 protein-panel P2 方向一致）；各策略收回曲线。

## 4. B 部分：M 侧不确定度弃答（纯分析，保存预测）

### 4.1 臂
两场景：M、M+vRNA、M+vP（虚拟层）与 M+RNA、M+P（实测参照），全部取 matrix run 保存的外折预测 `pred__*`；不重算任何臂。

### 4.2 逐细胞不确定度代理（只用 M 与 fit 侧量；外折 bank）
- **u1（主代理）**：按 matrix run 代码重拟合 M→Y 生成器（Y = RNA 或 P；目标 Z_Y 与 λ 选择与 `crosslayer.py` 完全相同：fit 行按 `sha256("oof|scenario|fold|outer")` 前 8 字节种子分 3 份交叉拟合，λ ∈ {0.1, 1, 10, 100} 按 OOF MSE 均值选）。3 个子生成器 = 交叉拟合的 3 个折模型（各用 2/3 fit 训练，选定 λ）；对每个查询细胞取三者对 Z_Y 的预测在特征上的标准差（ddof = 0），再对特征取均值。u1_vRNA 用于 M+vRNA，u1_vP 用于 M+vP；两者也都作用于其余臂（描述性）。
- **u2**：核空间新颖度 1 − max_j K_M(query, fit_j)（保存 `m_only_cross` 左侧 n_fit 列）。
- **u3**：fit 标准化 M 空间里到 10 个最近 fit 细胞的平均欧氏距离。
- **oracle（仅参照）**：该臂该细胞的真实逐细胞标准化误差 e_i。
- **random**：5 个种子 `default_rng([20261009, 场景号, 折号, 5, s])` 的随机排列，折分数取 5 种子均值。

### 4.3 风险–覆盖
- 逐细胞误差 e_i = 该细胞在被评价且有观测的药物上 ((pred − truth)/train_sd)² 的均值。
- 按 u 降序（最不确定在前，稳定排序）弃答前 (1 − c) 部分：保留数 n_keep = ceil(c·n_query)。保留集折分数 = sqrt(被评价且在保留集中有观测的药物上逐药 mse 的均值)，逐药 mse 只用保留细胞（药物权重与主指标相同）。报告 c ∈ {1.0, 0.9, 0.8, 0.7, 0.5}。
- AURC：对 n_keep 从 ceil(0.5·n) 到 n 的每个整数算保留集折分数，以 c = n_keep/n 为横轴做梯形积分，再除以横轴跨度（即 [0.5, 1] 上的平均风险）。random 的 AURC 为 5 种子均值。
- 增益–覆盖：G(c) = S_M(c) − S_{M+vY}(c)，两臂用同一保留集（由该代理的排序决定）；报告 G(0.8) 是否大于 G(1.0)（方向，5 折均值与逐折）。

### 4.4 主比较与判据（B）
对 M+vRNA（代理 u1_vRNA）与 M+vP（代理 u1_vP），每个场景：
- B1：AURC(u1) vs AURC(random 均值)：逐折 d_f = (AURC_rand − AURC_u1)/AURC_rand，胜折 ≥ 4/5 且校正 p < 0.10 记为满足。
- B2：c = 0.8 的保留集折分数（5 折均值）比 c = 1.0 的全集折分数低 ≥ 1%（相对）。
- 另报告 G(0.8) > G(1.0) 的方向（不进判据）。

**PASS B**：至少一个场景、至少一个虚拟臂同时满足 B1 与 B2。否则 **FAIL B**。u2、u3 为次要代理，同样报告 B1/B2 但不改变判定；oracle 只给上界。

## 5. 计算与输出
- 服务器：A 部分按（场景, 折）拆成 10 个单线程进程，最多 8 个并行（总线程 ≤ 8）；B 部分与分析脚本单线程串行。先做 dryrun（fold-0 inner-0 bank，全部臂，核对内折网格，不算外折），通过后固定 SHA256SUMS 再跑 main。
- 输出：`output/A/{scenario}/fold-f_predictions.npz`、`fold-f_selection.npz`、`fold-f_bank_info.json`、`fold-f_metrics.json`、`fold-f_repro.json`；合并后 `output/A/fold_metrics.csv`（scenario, arm, fold, score, spearman, centered_mse）；`output/B/riskcov.csv`（scenario, arm, proxy, coverage, fold, score）、`aurc.csv`、`percell.csv`；`output/summary.json`；`run.log`、`SHA256SUMS`、`PLAN.md`。本地 RESULT.md（中文）含全部臂、全部折、主比较、PASS/FAIL A/B 与注意事项（复用开发折 candidate_only、面板实测值取自全蛋白组、未做多重比较校正）。

## 6. 不做的事
不加种子、不扩网格、不换 n0/K、不删药物/折/组织、不换指标、不在看到外折分数后改判据。负结果原样报告。
