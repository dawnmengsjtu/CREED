Data S1. Identity-split record, whitelist packages and source-file checksums, related to Figure 1.

The 608-line identity protocol CREED_CCLE_L0_L1_L2_SPLIT_V1 (421 development, 64 validation and 123 internal-final
identities; seed 20260830; 35 tissue × cancer-type strata) and the identity lists of the whitelisted packages (19
M–AUC, 66 M–RNA and 354 RNA–AUC lines), with the per-bank lists of the M–RNA lines used by the generator-size curve,
and the size and SHA-256 of every public source file that the data-preparation code read (raw_source_checksums.tsv).
Identities and checksums only; no assay value.

About this archive
- Run records are byte-for-byte copies (not edited). Files that are not copies of files of the server run directories
  (derived tables, renderings, and records kept outside the compute server) are described under "Files" below.
- Plain-text formats only (.json, .tsv, .txt).
- Some files contain absolute file paths of an automated-agent workspace (/home/node/...); they are left unedited so
  that the files stay byte-identical to the original records.
- The run folder generator_curve/ has the layout of the run directory on the compute server; the runs' checksum lists
  are in Data S2 (Data_S2/CHECKSUM_INDEX.tsv shows which list covers each file of this archive).

Files
- identity_split/original_identity_split.json: the identity protocol record CREED_CCLE_L0_L1_L2_SPLIT_V1, frozen on
  2026-08-30, before the sealed-set release (released = false is expected; the release receipt is in Data S3).
  sample_ids_sha256 = SHA-256 of the IDs, in the stored order, joined by \n with a trailing \n;
  canonical_payload_sha256 = SHA-256 of the JSON without the integrity block, with sorted keys and compact separators
  (UTF-8). TEMPLAR and OX are internal project code names.
- whitelist_packages/extra19_M_AUC_ids.tsv, extra66_M_RNA_ids.tsv, extra354_RNA_AUC_ids.tsv (derived): the identities
  of the three whitelisted extra-sample packages (columns sample_id, model_id, tissue, package), exported on
  2026-10-11 from the package QA files of the compute server (m_gdsc_extra19_QA.json sample_qa;
  rna_candidate_sample_QA.tsv rows with has_m or has_gdsc, in the order of the package configuration), with patient
  identifiers and every count or value field dropped. Tissue is blank where the package records give none: SIDM00271
  (tissue unresolved; STAR Methods) in all three packages, and 3 further M–RNA and 87 further RNA–AUC lines. The
  packages overlap (18 lines are in all three; 403 distinct lines in total) and were never summed.
- Legacy file name: identity_split/original_identity_split.json and the code of Methods S1 name the RNA source
  CCLE_RNAseq_RSEM_Expected_Counts.csv.gz (role L1_rna_expected_counts). That file is a locally gzip-compressed copy
  of the Cell Model Passports release 20191101 read-count table rnaseq_read_count_20191101.csv (key resources table);
  the RSEM name is historical.
- raw_source_checksums.tsv (derived): for every public source file that the data-preparation code read, the public
  location, size, SHA-256 (and the MD5 that DepMap publishes), what it feeds and notes, computed on the compute server
  on 2026-10-11. The files themselves are public and are not redistributed here.
- generator_curve/output/extra_ids_{new_cell,tissue}_fold-{0..4}.txt: the per-bank subsets of the 66-line M–RNA
  package used by the generator-size curve (run generator-curve-20261009-0001; the first line of each file gives the
  count per bank).
- Not listed in any run checksum list: identity_split/original_identity_split.json, raw_source_checksums.tsv,
  whitelist_packages/extra19_M_AUC_ids.tsv, whitelist_packages/extra354_RNA_AUC_ids.tsv,
  whitelist_packages/extra66_M_RNA_ids.tsv.

SHA-256 of every file in this archive:
d297ce691265307c4c41587ef22e636b793544a2aa9cbeb8e9870ff4d1f187d6  Data_S1/generator_curve/output/extra_ids_new_cell_fold-0.txt
bfdeea1600492cc24178bbb5eeb53461cf6fec2422f7921f3f8a4ff433360bb5  Data_S1/generator_curve/output/extra_ids_new_cell_fold-1.txt
771c76da5449d437ed0442e0cb8a13673edf0e0ae0d983f3e7e949b12d88a1d8  Data_S1/generator_curve/output/extra_ids_new_cell_fold-2.txt
ebf96a0ced61c90ff83dc3c92913481e8ee2ccf20a92be0374255ba0e702ebd0  Data_S1/generator_curve/output/extra_ids_new_cell_fold-3.txt
53d7619a0ef156c9ee4b417dfa7776904ae9bda7311e4e7414314433da125d76  Data_S1/generator_curve/output/extra_ids_new_cell_fold-4.txt
a42cd8d4aa463483d27267c1eb68557c15ef9a38f3a2cec900d867d6b7ae74d6  Data_S1/generator_curve/output/extra_ids_tissue_fold-0.txt
a25a39b510c39c0a173869735ff839137f1c9c084191f9bc57508acbfdadf6fc  Data_S1/generator_curve/output/extra_ids_tissue_fold-1.txt
4416b06561c2531395fdc9dd00d4ec3dfeab98f2bd6a8f83dec4c11a38337acc  Data_S1/generator_curve/output/extra_ids_tissue_fold-2.txt
30b51d66ce7a6e9017ead3d95e14d35f5eadf08b7b4aa7ce407807025f01bc0e  Data_S1/generator_curve/output/extra_ids_tissue_fold-3.txt
21c67f6c9d9ec275af54a91f6a9385525d8a058d6f4c94cc4525cc27f634661a  Data_S1/generator_curve/output/extra_ids_tissue_fold-4.txt
367ffaacc85995cd967ecff26ad24d284772fa3518e1fded305944fc9a6b528d  Data_S1/identity_split/original_identity_split.json
e5948898f5600ef0d99d4f851278c12ac053efa42b0d4cb3046ee8e548ee4fc5  Data_S1/raw_source_checksums.tsv
81df2f79c8047d50b53500c5c9cb05215dace198dc1a3b8467add1b8f2d82b06  Data_S1/whitelist_packages/extra19_M_AUC_ids.tsv
0f9104c85f778b2c26d35462dff279e71fdf483eea604fde6bf9ded384730dfe  Data_S1/whitelist_packages/extra354_RNA_AUC_ids.tsv
d5583e4922b56642cd59a0b8c3053d836bb16ae5569386576c733fdc7b9807b9  Data_S1/whitelist_packages/extra66_M_RNA_ids.tsv
