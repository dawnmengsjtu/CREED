Data S8. Per-sample adaptive acquisition (N1), related to Figure 4.

Protein (a) and gene (b) versions: all policies × k under both fixed heads, recovery fractions and
relevance–disagreement correlations (Table S7).

About this archive
- Files are byte-for-byte copies of the run records (not edited).
- Plain-text formats only (.csv, .json, .md). JSON files use NaN for missing values (Python json syntax; strict
  parsers need NaN replaced by null).
- Chinese text, as written in the original records and not translated, occurs in: a_protein/output/analysis/tables.md.
- The run folders a_protein/, b_gene/ have the layout of the run directory on the compute server; the runs' checksum
  lists are in Data S2 (Data_S2/CHECKSUM_INDEX.tsv shows which list covers each file of this archive).

Files
- a_protein/ = run acquisition-probe-20261009-0001 (protein version); b_gene/ = run
  acquisition-probe-rna-20261009-0001 (gene version).
- Not listed in any run checksum list (acquisition-probe-rna-20261009-0001 wrote no output checksum list):
  b_gene/output/analysis/summary.json, b_gene/output/new_cell_main/fold_metrics.csv,
  b_gene/output/tissue_main/fold_metrics.csv.

SHA-256 of every file in this archive:
c101451c80f07cc1589ed1c8d7d15e28e79acedd8cc41802b0538eedef10da56  Data_S8/a_protein/output/analysis/summary.json
54c0c4644109948b5580bbce06eaac5196bad3fe34ec0b1ad0ed08952d20c0aa  Data_S8/a_protein/output/analysis/tables.md
c1a1fdfa18d6e32818d1b735b96145ff71dee4b644f013cd4c319dad9576900e  Data_S8/a_protein/output/new_cell_main/fold_metrics.csv
cac231a84835beec7241cb8d2c5b1b789f6f31e5b95f6dee922346a45bca8f24  Data_S8/a_protein/output/new_cell_main/summary.json
e0339b7deb6f363793ddf83883b8517bf3faf71c5b5030d10cee65eaa3a2a252  Data_S8/a_protein/output/tissue_main/fold_metrics.csv
b3be72845b4541cb6abad0684d34f74bed2df9f5fa7e42e56db2738ee439d882  Data_S8/a_protein/output/tissue_main/summary.json
ed4f57bfbdcaa3bbd2202a520295d0a05e754d7f73fd9b29f0895fab71dc7157  Data_S8/b_gene/output/analysis/summary.json
2a472dff3493610347ed2b8aa6e2231b6fa086305728fa6519858bf3b4d0f854  Data_S8/b_gene/output/new_cell_main/fold_metrics.csv
af732b4d5e87c392303318998efb7c1b37de48f07f6141d50b1605388d5349c5  Data_S8/b_gene/output/tissue_main/fold_metrics.csv
