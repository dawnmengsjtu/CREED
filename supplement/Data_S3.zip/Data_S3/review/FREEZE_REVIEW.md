# 冻结只读复核（FREEZE_REVIEW）

复核时间：2026-10-09（服务器文件状态 20:18 之后）。方式：只读。服务器上未写任何文件（远程 Python 以 `-B` / `PYTHONDONTWRITEBYTECODE=1` 运行，`code/__pycache__` 时间戳仍为 20:00:31）。本地只写本文件。

复核对象：`/public/home/mengxl/creed-research-runs/internal-final-20261009-0001/`（PLAN.md sha `ca3288c1…`，登记 2026-10-09T19:33:56+0800）与本地镜像 `~/Desktop/proj/creed/internal_final_20261009/`。

**结论：冻结可以进入回执阶段（ready for receipt）。** 代码、frozen_models、哈希清单无需改动。发现的缺陷全部是文档 / 操作流程层面的（见 §6），其中第 1 条必须在写回执之前由操作者采纳，否则一次性运行会在回执门之后、任何分数产生之前崩溃。

---

## 1. 原始文件访问与封存加载门

### 1.1 每条原始文件读取路径都在物化数值之前按 allowed ID 过滤

| 读取器 | 文件:行 | 过滤方式 | 判定 |
|---|---|---|---|
| `load_omics` 入口 | `code/sealed_io.py:154` | `check_allowed(allowed, forbidden=64 validation, universe=train ∪ internal_final)`：非空、唯一、SIDM 格式、与 validation 交集为空、不超出 universe；任何原始文件打开之前执行 | ✓ |
| 原始文件 sha | `sealed_io.py:156-160` | 四个原始文件 sha256 与 `RAW_SHA` 不符即拒绝 | ✓ |
| 代谢物 M | `sealed_io.py:169-177`（身份遍历，`prefix_fields(line, 1)` 只切前两列）→ `:178-186`（mmc2 双约定解析，重复 / 缺失 fail-closed）→ `:188-198`（只对 `row2sid` 中的行 `csv.reader` 解码） | 与 `generator-fullpool-20261009-0001/code/extract_fullpool.py:405-416` 同构 | ✓ |
| RNA | `sealed_io.py:203-212`（表头身份）→ `:215-229`（整行按字节 `split(b',')`，只对 `cols` 中的列 `number(text(...))`） | 与 `extract_fullpool.py:417-435` 同构 | ✓ |
| 蛋白 P（mmc3） | `sealed_io.py:239-262`：第 2 行表头 == 冻结 6692 蛋白 ID；`iter_rows(min_row=3, values_only=True)` 逐行取 `row[0]` 的 SIDM，不在 allowed 立即 `continue`；重复 / 缺失 fail-closed | 见 §6 第 8 条（xlsx 解析器会瞬时产生整行值元组，但从不存储、转换或打印） | ✓（备注） |
| GDSC2 AUC | `sealed_io.py:288-330` | 与 `extra-supervision-20261008-0001/resources/original_prepare_gdsc421.py:17-53::extract` 逐字一致（仅删去 annotations / 两个诊断字段）；`sid not in whitelist: continue`（:299）在 `float()`（:306）之前 | ✓ |
| CRISPR | `sealed_io.py:361-401`：`index_models` 只读 Model.csv 元数据；`crispr_extract` 只解码 `ModelID` 前缀（:389），不在 mapping 的行不进 `csv.reader` | ✓ |
| `crispr_load` | `sealed_io.py:407` `check_allowed(ids, forbidden)` 先于任何打开 | ✓ |

调用点：
- `oneshot.py:660`（dryrun）`load_omics(..., allowed=sio.PARITY)`：5 条 421 训练线。
- `oneshot.py:790`（sealed）`load_omics(..., list(fin) + sio.PARITY, forbidden=validation, universe=train+internal_final)`，随后 `:795-796` 断言恰好 123 条 internal_final、无 validation ID。
- `oneshot.py:774` `gdsc_parity_421`（白名单 421）、`:798` `gdsc_load_ids`（白名单 123）、`:781` `crispr_parity_310`（白名单 421）、`:803` `crispr_load`（白名单 123）。
- freeze / gates 模式（`oneshot.py:607-615, 686-757`）不调用 `sealed_io` 的任何读取器。

### 1.2 封存加载器在无有效回执时不可达

- `do_sealed`（`oneshot.py:760`）第一条语句即 `receipt_gate()`（:571-603）。`main()`（:823-826）在回执门之前只检查 `--gdsc` 参数存在，不打开任何文件。
- 回执门逐项：`protocol_id`（:579）；PLAN.md sha（:581-583）；`code/` 下全部 `.py` 的 sha 以字典相等比较——键集合必须恰好一致（:584-588）；`frozen_models/` 下全部文件的 sha 以字典相等比较（:589-593）；numpy / scipy 版本 == 回执 == `ENV_EXPECTED`（:594-596）；internal_final ID 清单 sha 重算并要求 `e8f278c4` 前缀（:597-600）；`output/` 已存在即拒绝（:601-602）。任一不符 → `refuse` → exit 3。
- 无回执测试：`logs/gate_test_no_receipt.log` 与冻结后 `logs/gate_test_no_receipt_postfreeze.log` 均为 `REFUSED: RELEASE_RECEIPT.json is absent ... No raw file was opened.`，`exit=3`；服务器上现在无 `RELEASE_RECEIPT.json`、无 `output/`。
- 哈希是对**磁盘文件**重算后比较（`cc.sha_file`），不是读回执自报的值。

### 1.3 本次复核额外做的一次身份层核对（不解码任何数值）
用服务器上的 `sealed_io.read_mmc2 / prefix_fields / resolve_m_row` 对原始文件只做身份列遍历：
- 代谢物文件：421 训练 ID 与 123 internal_final ID 在 mmc2 双约定解析下**各自恰好解析到 1 行**（缺失 0、重复 0）。
- RNA 表头 1047 列：421/421、123/123 存在。
- mmc3 第一列 949 行：421/421、123/123 各恰好出现 1 次。
- mmc2：421/421、123/123 存在。

因此 `sealed_io.py:185-186 / :208-210 / :261-262` 三个 fail-closed 门不会因身份问题在一次性运行中触发。（`:232-234` 的 RNA 完整性门需要数值，运行前不可测。）

## 2. frozen_models 只依赖 421

- `do_freeze`（`oneshot.py:607-615`）→ `load_train()`（:78-100）只读 `source-inputs.npz`（sha 校验 :79）、`rna421`、`crispr310` 三个 421 开发工件与 ID 划分 json；`fit_training_set(D, …)` 的 D 为 421。
- 服务器上实读 `frozen_models/model.npz`：372 个键；`sample_ids` 421 条，与划分 json 的 `train` 顺序完全相同；与 validation、internal_final 交集均为 0。`inner_losses.npz` 145 个键，bank 大小 141/140/140。
- `FROZEN_MANIFEST.json`：`label = "FROZEN on 421 development lines only"`，`n_train = 421`，环境 numpy 2.0.2 / scipy 1.13.1；全文不含任何 validation / internal_final ID 字串。
- internal_final ID 清单只在 `receipt_gate`（:597）与 `do_sealed`（:789-790）作为选择用 ID 列表出现。

## 3. 臂、指标、bootstrap、F1–F8 与 PLAN §4–§6 逐行对照；崩溃语义 §7

### §3 规则
| PLAN §3 | 实现 | 判定 |
|---|---|---|
| 逐药均值中心化 masked KRR，α∈{0.1,1,10,100}，观测<20→训练均值 | `creed_core.py:90-109 predict_grid`（`MIN_FIT=20`，:34） | ✓ |
| 3 个内折 bank = extra-supervision fold-0 内折规则在 421 上重放，种子 20261009，回退索引 1 | `oneshot.py:169 cell_folds(D.tis, 20261009, 3)`；`creed_core.py:61-74` 逐字；`:118-121 choose(fallback=1)`；gates 中 5 折 × 3 bank 重放全部 true | ✓ |
| M 核 / RNA 前 3000 方差基因 / P 值核+掩码核 / Pval / T 同组织指示 w∈{0,0.25,1} / 0.5+0.5 | `creed_core.py:173-198, 315-333, 411-439`；`WS=(0,.25,1)` :28；`one_grid` kind 'w' = `K + w*T`（`oneshot.py:158-160`） | ✓ |
| 生成器 crosslayer 3 路交叉拟合，sha256 种子作用于 421 全体，λ 按 OOF MSE，512 目标 | `creed_core.py:355-374`；种子 `stable_seed('oof','internal_final_421','full')`（`oneshot.py:261, 613`）；`TOP_TARGET=512` | ✓ |
| L_protein 公式，μ 网格按内折选 | `creed_core.py:205-225`，`MUS` 含 0；`one_grid` kind 'mu' | ✓ |
| 面板 top-k k=16,32,64 在 421 全体；随机 k=16,32 × 5 种子 rng [20261009, 9, s] | `creed_core.py:377-402, 304-311`；`oneshot.py:262 fit_panels(..., [cc.SEED, 9])` → `default_rng([20261009, 9, s])` | ✓ |
| 全部在加载 123 之前写盘，含哈希 | `write_frozen`（`oneshot.py:298-310`）；manifest 含 coef sha、L sha、npz sha；sealed 模式先 `rebuild_and_verify`（:771）逐键核对 1e-10 再加载 123 | ✓ |

### §4 臂（`creed_core.py:442-454`，`oneshot.py:115-116`）
null、M、T、M+T、M+vRNA、M+vP、M+vRNA+T、M+vRNA_shuf、M+vP_shuf、M+RNA、M+P、M+Pval（声明的额外教师臂）、M+P_graph、M+P16/32/64、M+G16/32/64、M+Prand16/32_s0..4、M+Grand16/32_s0..4 = **39 个药敏臂**；CRISPR 去掉 T / M+T / M+vRNA+T / M+P_graph = **35 个臂**。PLAN §4 表格每一行都有对应臂。dryrun `progress.jsonl` 74 行 = 39 + 35，无 `not_computed`。

### §5 指标（`creed_core.py:149-159`，`oneshot.py:353-385`）
- sRMSE = sqrt(mean_use(逐药 MSE))，逐药 MSE = Σ_obs((pred−truth)/train_sd)²/n_obs，train_sd = `nanstd0(421 auc)`（`oneshot.py:325`）✓
- 评估药物 = 评估集观测 ≥5 且训练观测 ≥20（`oneshot.py:49, 326`）✓
- 次指标 Spearman（分组实现，dryrun 与 scipy 差 1.1e-16）、centered MSE ✓
- 相对改善 `(base−arm)/base×100`（:370-371）✓；追回份额（:426-432）✓；R(k)（:433-444，教师 M+Pval / M+RNA）✓
- bootstrap B=2000 种子 20261009，细胞按组织分层、药物按 ID 同时有放回（:353-367, 394-397）；2.5/97.5 分位与 P(>0)（:374-378）；逐药配对符号检验（:381-385）✓；无 Nadeau–Bengio ✓

### §6 判定（`oneshot.py:459-495`）
F1/F2/F6：gain>0 且下限>0 ✓；F3：每个置乱臂 `lo ≤ 0 或 gain<0`（等价于"区间含 0 或 <0"）✓；F4：RNA 与 P 份额都在 [0.15,0.55] 且 F1、F2 确认（FREEZE_REPORT §5 已声明此解读）✓；F5：P32/P64/G32/G64 的 R ≥ 0.5 ✓；F7 只看方向 ✓；F8：CRISPR 终点上 F1、F2、F5，靶标 = 421∩CRISPR 中观测 ≥20 且 SD ≥0.2（`oneshot.py:110-112`）✓；总判定 "n/7 confirmed"，F8 另列 ✓。

### §7 崩溃语义
- 唯一脚本、无自动重试：`output/` 存在即拒绝（:601-602, 763）✓
- 启动校验回执哈希 ✓
- 每个臂算完立即写 `output/arms/<ep>__<arm>.npz` 与 `progress.jsonl`（:338-343）；单臂异常记 `not_computed` 并继续（:345-347），summary 中列出 ✓
- 分数产生后崩溃不重跑：由 `output/` 存在的拒绝保证 ✓
- 分数产生前崩溃可修复重跑：见 §6 第 2–4 条的操作说明。

## 4. dryrun 输出与代码等价门

- `dryrun/output/{summary.json, RESULT_DRAFT.md, progress.jsonl}`、`dryrun/output/arms/*.npz`（74 个）、`dryrun/frozen_models_dryrun/` 存在；标签 `"DRYRUN, 421-only (401 pseudo-train / 20 pseudo-eval, seed 20261009)"` 写入 summary、RESULT_DRAFT 首行与每个 arm npz 的 `label`。
- dryrun 内置门全部通过：GDSC 合成 421 重现 diff 0、CRISPR 合成 310 重现 diff 0、5 线 omics 重现（M 0 / RNA 1.78e-15 / P 0 / 组织相同）、冻结文件重建 diff 0.0、Spearman 1.1e-16、面板权重 5.0e-14。
- `dryrun/gates.json` `passed: true`，内容与 FREEZE_REPORT §2.1 一致（全部预测差 ≤ 1.1e-11）。
- 三次 dryrun 尝试：attempt1 为 `dryrun/` 目录已存在（随后改为 `exist_ok=True`），attempt2 为 `rebuild_and_verify` 把 421 行 AUC 传给 401 行训练集的索引错误（随后加入 `auc` 参数），attempt3 exit 0。两处修改均在冻结（20:13）之前，不涉及 §7。

## 5. SHA256SUMS

- 服务器 `sha256sum -c SHA256SUMS.v2`：PLAN.md、code/creed_core.py、code/oneshot.py、code/sealed_io.py、frozen_models/FROZEN_MANIFEST.json、frozen_models/inner_losses.npz、frozen_models/model.npz 全部 OK；v2 覆盖了 PLAN + 全部代码 + 全部 frozen_models 文件（目录内无其他文件）。模式 444。
- `SHA256SUMS.v1`（仅 PLAN.md，`ca3288c1…`）内容与 19:33 时间戳未变，`sha256sum -c` OK，模式 444。
- 本地镜像 PLAN.md、code/*.py、FROZEN_MANIFEST.json 的 sha 与 v2 完全一致。

## 6. 缺陷清单（按重要性）

1. **【操作流程，写回执前必须采纳】"回执写入后目录改只读"不能对运行目录本身执行。** PLAN §8 与 FREEZE_REPORT.md §4 第 2 条都写"目录改只读"。但 `do_sealed` 在回执门通过后立即 `os.makedirs(RUN + '/output')`（`code/oneshot.py:763`）并打开 `RUN/logs/sealed_<时间>.log`（`:765-766`）。若 `internal-final-20261009-0001/` 本身不可写，运行会在任何 123 数值解码之前崩溃，并且修复不是软件错误、无法走 §7。正确做法：只把文件改只读（`chmod 444 RELEASE_RECEIPT.json PLAN.md code/*.py frozen_models/*`，可加 `chmod 555 code frozen_models`），运行根目录与 `logs/` 保持可写。建议在回执的 authorization / 声明字段里写明此解读（不是 ADDENDUM，因为不是软件错误、不改 §4–§6）。
2. **【健壮性，无需改码】`output/` 在端点文件被验证之前就已创建。** `oneshot.py:763` 建目录早于 `:774 gdsc_parity_421(args.gdsc)` 与 `:781 crispr_parity_310`；`--gdsc` 路径写错 → `FileNotFoundError` 退出 1，此时 `output/` 已存在（含 `pre_sealed_checkpoint.json` 或为空），下一次调用会被 `:601-602` 拒绝。同类：`:777`（GDSC 421 重现门失败 exit 5）、`:794`（5 线 omics 重现失败 exit 6）、`sealed_io.load_omics` 抛出的 `Gate` 未被捕获（traceback exit 1）。这些都发生在任何分数之前，符合 §7"可修复重跑"的情形，但需要手动删除空的 `output/`。操作要求：调用前核对两个绝对路径存在且可读；若发生，先追加 ADDENDUM（原因、保留 `logs/sealed_*.log`），再删除 `output/`，再重跑。
3. **【流程】§7 修复与 §8 create-once 的衔接。** `receipt_gate` 要求 `code_sha256` 与磁盘字典相等（`oneshot.py:584-588`），因此任何 §7 允许的运行前软件修复都必然改变代码 sha，必须随 ADDENDUM 重新签发一份回执（保留旧回执、两版哈希，PLAN §7 已要求"保留两版哈希"）。建议在回执中预先写明"回执与代码版本一一对应；§7 修复后签发新回执，旧回执保留"。
4. **【文档，FREEZE_REPORT.md:37】臂数写错。** "74 个臂（药敏 37 + CRISPR 37）"应为药敏 39（13 个命名臂 + 26 个面板臂）+ CRISPR 35（9 + 26）= 74；`dryrun/output/progress.jsonl` 与 `summary.json` 均为 39/35。
5. **【文档，FREEZE_REPORT.md:24】内折随机面板种子顺序写错。** 报告写 "内折 bank c 用 `[20261009, 9, s, c]`"，代码实际为 `[20261009, 9, c, s]`（`oneshot.py:185` 传 `[cc.SEED, 9, c]`，`creed_core.py:308` 追加 `[s]`）。部署面板（421 全体）用 `[20261009, 9, s]`（`oneshot.py:262`），与 PLAN §3 一致，不受影响；FROZEN_MANIFEST 的规则文字 "rng=[20261009,9,s] (+ [c] inner bank c)" 也宜按代码顺序理解。
6. **【可选】`dryrun/gates.json`（20:03:23）早于最终版 `code/oneshot.py`（20:08:17）。** `creed_core.py` 与 `sealed_io.py` 自 20:00:29 未变，模型核心等价门仍然有效；20:03–20:08 之间 oneshot.py 的改动来自 dryrun attempt2 的修复（`rebuild_and_verify` 增加 `auc` 参数）。若希望 gates.json 对应最终 sha，可再跑一次 `oneshot.py gates`（只写 `dryrun/gates.json`，不影响 v2 清单）。非阻塞。
7. **【说明】`sealed_io.load_omics` 本身不校验回执**，门由模式逻辑保证（`do_sealed` 首句 `receipt_gate()`，`oneshot.py:761`）；传入 internal_final ID 的唯一调用点是 `:790`，dryrun 只传 `PARITY`（`:660`）。任何改动调用点都会改变 `oneshot.py` sha 而被回执门拒绝。可接受。
8. **【说明，sealed_io.py:249-258】** openpyxl `values_only=True` 在 SIDM 过滤（`:253`）之前已把整行值解析成 Python 元组；非 allowed 行的蛋白值在解析器内瞬时存在，但从不被存储、转换、打印或记日志。这是 xlsx 解析固有行为；M / RNA 读取器则与 `extract_fullpool.py` 一样在解码前按行 / 列门控。可接受。
9. **【说明】** 服务器 `registration/` 目录为空；`dryrun/synthetic_*.csv` 含 421 / 310 开发值的合成端点文件（允许范围内）。无影响。

## 7. 回执前检查单（给操作者）

- [ ] 回执字段按 FREEZE_REPORT §4 第 2 条，`code_sha256` 恰好三个键、`frozen_models_sha256` 恰好三个键、`internal_final_ids_sha256 = e8f278c49c8159c8d92e88404fed5dbd6da0439e91433262e5403a0218507be9`。
- [ ] 回执中写明：只读化只针对文件（见 §6.1）；§7 修复后签发新回执、旧回执保留（见 §6.3）。
- [ ] `chmod 444` 回执与 PLAN / code / frozen_models 文件；**不要**对运行根目录或 `logs/` 去写权限。
- [ ] `--gdsc`、`--crispr` 绝对路径确认存在、可读（见 §6.2）。
- [ ] 按 FREEZE_REPORT §3 的命令以 nohup 单次调用。
