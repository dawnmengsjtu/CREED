# 封存内部最终集一次性确认：冻结报告（FREEZE_REPORT）

协议：`CREED_INTERNAL_FINAL_ONESHOT_V1`（PLAN.md sha256 `ca3288c18736c6a572bb4a087da503148f694dd3c89d8f6c6afecbaec87bfdc1`，登记 2026-10-09T19:33:56+0800，未改动）。
服务器目录：`/public/home/mengxl/creed-research-runs/internal-final-20261009-0001/`；本地镜像：`~/Desktop/proj/creed/internal_final_20261009/`。
冻结时间：2026-10-09 20:15（服务器时钟）。环境：`/public/home/mengxl/.conda/envs/CellFM/bin/python`（Python 3.9.23，numpy 2.0.2，scipy 1.13.1，openpyxl 3.1.5），8 线程。

**截至本报告，没有解码、加载、打印或写出任何 123 条 `internal_final`（或 64 条 validation）细胞的代谢物 / RNA / 蛋白 / AUC / CRISPR 数值。** 所有冻结量只依赖 421 开发细胞。

## 1. 冻结了什么（`frozen_models/`，哈希见 `SHA256SUMS.v2`）

| 文件 | sha256 | 内容 |
|---|---|---|
| `frozen_models/model.npz` | `8e89f4a42ef76d1eca1d1416f57fa64d7f58ca12cb9ec8e366b87d056f5322cf` | 421 全体上的：M / RNA / P 层核状态（均值、标准差、RBF 中位带宽，RNA 前 3000 方差基因索引，P 候选 3356 蛋白及 fit 均值填补），2 个虚拟层生成器（M→RNA λ=0.1、M→P λ=1.0）及配对置乱对照（λ=100/100）的 KRR 系数、OOF 特征与虚拟核状态，L_protein（421×421，10-NN 并图，trace=421），蛋白 / 基因面板（k=16/32/64）与随机面板（k=16/32 × 5 种子）的索引与核状态，药敏终点与 CRISPR 终点每个臂逐靶标选定的配置下标（α / w / μ），421 逐药 train_sd、均值与观测数，CRISPR 可评估靶标列（2456 个基因）。 |
| `frozen_models/inner_losses.npz` | `143f6bd5bcc2445b0ea92be5a8ce90c6010619731ecdb927ee75c56a9e6752d4` | 3 个内折 bank 的划分（141/140/140）与每个臂每个配置的标准化 MSE 之和与计数（选择依据）。 |
| `frozen_models/FROZEN_MANIFEST.json` | `a2d530e9ad59b8d4c43a398bf5eda795e2af35f3c6229a9106d558e2da48777e` | 人可读清单：规则文字、每个臂的配置列表与被选计数、生成器 λ / OOF R²、面板蛋白 ID / 基因 ID、内折 bank 信息、npz 哈希。 |

### 冻结规则的精确构造（PLAN §3 的实现）

- **内折 bank**：`cell_folds(tissues_421, seed=20261009, nfolds=3)`，即 `extra-supervision-20261008-0001/code/run_recoverability.py` 的 `nested_cell_folds` 规则（按组织分层、负载均衡的确定性分配，种子 = `sha256("20261009|nested_cell_folds|<tissue>")`）。该规则用种子 20261008 在 `code/oneshot.py gates` 中逐字复现了 extra-supervision new_cell 全部 5 折 × 3 个内折 bank 的 fit/query 索引（`dryrun/gates.json: inner_rule_replay` 全部 true），故"fold-0 内折规则在全 421 上的重放"= 同一函数、训练集换成 421、种子换成 20261009。bank 大小 141/140/140。
- **逐药 α**：α ∈ {0.1, 1, 10, 100}，逐药取 3 个 bank 标准化 MSE 之和最小者，回退下标 1；bank 内某药 fit 观测 < 20 用 fit 均值（`predict_grid`）。
- **组织权重 w**（PLAN §3 "w ∈ {0, 0.25, 1} 按内折选"）：臂 `M+T` = K_M + w·T，臂 `M+vRNA+T` = (0.5 K_M + 0.5 K_vRNA) + w·T，(w, α) 逐药联合选（protein-panel / tissue-kernel run 的 `m_tissue` 规则；w=0 即底座）。`T` 单独臂 = 同组织指示核。
- **图正则 μ**：臂 `M+P_graph` = M 核 + 训练期 L_protein，μ ∈ {0, 0.1, 1, 10, 100, 1000} × α 逐药联合选；K_eff / H_eff 公式与 tissue-kernel / pushline / protein-panel run 相同。L_protein 构造 = fit 蛋白数值核（≥50% 覆盖蛋白、fit 均值填补、fit z-score、RBF 中位带宽）上的 10 近邻并图，W = K（支撑上），L = D − W，trace 归一到 n_fit；在 gates 中与 extra-supervision 保存的 L_protein 逐元素一致（最大差 8.9e-16）。
- **生成器**：`crosslayer.py generator()` 逐字；全 421 的 3 路交叉拟合种子 = `sha256("oof|internal_final_421|full")` 前 8 字节小端，配对置乱种子 = `sha256("pair_shuffle|internal_final_421|full")`；内折 bank c 用 `...|inner|c`。λ 按目标列平均 OOF MSE 选（M→RNA 0.1，OOF R² 0.295；M→P 1.0，OOF R² 0.174）。
- **面板**：蛋白候选 = 421 中覆盖 ≥ 90% 且方差 > 1e-12（1807 个）；基因候选 = 前 3000 方差基因（按列号升序）；分数 = Σ_药 |Spearman|（配对 ≥ 10），稳定降序取前 k，k ∈ {16, 32, 64}（protein-panel / rna-panel 规则）。随机面板：`np.random.default_rng([20261009, 9, s])` 对候选池置换取前 16 / 前 32，s ∈ {0..4}（内折 bank c 用 `[20261009, 9, s, c]`）。CRISPR 终点的监督面板用 CRISPR 靶标重新打分（crispr-endpoint 规则），随机面板同一种子。
- **CRISPR 靶标**：421∩CRISPR（310 系）中观测 ≥ 20 且 SD ≥ 0.2 的基因，共 2456 个。

## 2. 通过的门

### 2.1 代码等价门（`code/oneshot.py gates` → `dryrun/gates.json`，`passed: true`）
在 extra-supervision fold-0 的 4 个 bank 上，用本代码的冻结路径重算并与开发 run 的保存值比较：
- M 核块 vs 保存核：最大差 1.1e-16；L_protein vs 保存图：8.9e-16。
- 12 个生成器（含 RNA→P 等不在本协议内的方向不计；本协议 4 个）λ 全部相同，OOF R² 均值/中位数最大差 3.3e-16，虚拟核带宽最大差 8.0e-13（crosslayer-matrix `bank_info.json`）。
- 蛋白面板 top-16 与 top-64 索引与 protein-panel run 完全相同（4 个 bank），基因面板 top-16 与 rna-panel run 完全相同，随机面板（蛋白 / 基因，k=16/32 × 5 种子）完全相同。
- 外折预测复现（3 内折选 α 后对 outer bank 预测）：矩阵 run 的 M / M+RNA / M+P / M+Pval / M+vRNA / M+vP / 两个置乱 / T 最大差 ≤ 3.4e-14；protein-panel run 的 m_tissue(M+T) 1.4e-14、m_only__protein(M+P_graph) 1.1e-11、m_panel_k16/32/64 ≤ 1.9e-14、random_k16 ≤ 2.4e-14；rna-panel run 的 m_panel_k16/32/64 ≤ 1.9e-14。全部 ≤ 1e-8。

### 2.2 DRYRUN（`code/oneshot.py dryrun` → `dryrun/`，exit 0，标签 "DRYRUN, 421-only"）
421 按种子 20261009 随机取 20 条伪评估、401 条伪训练，整条流水线端到端执行：3 内折 → 冻结（`dryrun/frozen_models_dryrun/`）→ 重建并逐键核对冻结文件（372 个数组，最大差 0.0）→ 两个终点全部 74 个臂（药敏 37 + CRISPR 37）→ bootstrap B=2000 → 符号检验 → F1–F8 → `dryrun/output/summary.json` 与中文 `RESULT_DRAFT.md`。伪评估：20 细胞、282/295 药、2455 CRISPR 靶标、9 个组织层。**其数字只证明代码能跑，不是结果。**
附带门：Spearman 分组实现 vs scipy 逐药 1.1e-16；面板权重快速实现 vs 逐字慢实现 5.0e-14。

### 2.3 加载器门（DRYRUN 中执行，只涉及 421 数值）
- 身份门控 omics 加载器（`sealed_io.load_omics`）以 5 条 421 训练线（SIDM00018/00080/00082/00396/00685）为 allowed 集跑原始文件：M 最大差 0、NaN 模式相同；RNA log-CPM 最大差 1.78e-15；P（mmc3 `Prot matrix excl single-peptide`，第 2 行表头 == 6692 蛋白 ID）最大差 0、NaN 模式相同；组织相同。另在冻结前对全部 421 条 P 行做过同样核对（最大差 0，421/421 NaN 模式相同）。
- AUC 读取器 = `original_prepare_gdsc421.py::extract` 逐字；用 421 AUC 合成的 GDSC2 格式文件走通解析 + 421 重现门（最大差 0、295 药序相同）+ 按 ID 子集读取。
- CRISPR 读取器 = `prepare_crispr_development.py`（`index_models` + `extract`）镜像；用 310 系合成的 CRISPRGeneEffect 格式文件走通 310 重现门（310/310，最大差 0）。
- 真实端点文件尚未提供，上述两条是代码路径验证；一次性运行时会在任何 123 数值解码之前，对真实文件先做 421 / 310 重现门（1e-9），不过门即拒绝。

### 2.4 回执门测试
- 无回执：`python code/oneshot.py sealed --gdsc /nonexistent/GDSC2.csv` → `REFUSED: RELEASE_RECEIPT.json is absent ...`，退出码 3，未创建 `output/`，未打开任何原始文件（`logs/gate_test_no_receipt.log`，冻结后再测 `logs/gate_test_no_receipt_postfreeze.log`）。
- 伪造回执（PLAN sha 不符）→ `REFUSED: PLAN.md sha ... differs from the receipt`，退出码 3。

## 3. 唯一一次运行的命令

```
cd /public/home/mengxl/creed-research-runs/internal-final-20261009-0001
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 MKL_NUM_THREADS=8
nohup /public/home/mengxl/.conda/envs/CellFM/bin/python code/oneshot.py sealed \
    --gdsc  <GDSC2_fitted_dose_response_24Jul22.csv 的绝对路径> \
    --crispr <DepMap 24Q2 CRISPRGeneEffect.csv 的绝对路径（可省略；省略则不做 F8）> \
    > logs/sealed_run.log 2>&1 &
```
两个文件路径参数：`--gdsc`（必需，GDSC2 fitted dose response 表，需含 SANGER_MODEL_ID/DATASET/DRUG_ID/DRUG_NAME/WEBRELEASE/AUC/LN_IC50/MIN_CONC/MAX_CONC/PUTATIVE_TARGET 列；预期 sha256 `9d6dc82b…`，不同版本也接受但必须过 421 重现门）与 `--crispr`（可选，DepMap 24Q2 `CRISPRGeneEffect.csv`，md5 `d10d7369…`；310 重现门不过则只跳过 CRISPR 终点，不中止药敏终点）。运行顺序：回执门 → 读 421 → 重建并核对 `frozen_models/`（选择下标从冻结文件读取）→ GDSC 421 重现门 → CRISPR 310 重现门 → `output/pre_sealed_checkpoint.json` → **首次**加载 123（M/RNA/P/组织：身份门控，allowed = 123 ∪ 5 条校验线，断言恰为该集合且不含 validation ID；AUC；CRISPR）→ 每个臂算完立即写 `output/arms/<终点>__<臂>.npz` 与 `output/progress.jsonl`（PLAN §7 崩溃语义；单个臂异常记为"未计算"，其余继续）→ `output/summary.json`、`output/RESULT_DRAFT.md`。`output/` 已存在则拒绝（无重试）。预计用时约 3–5 分钟。

## 4. 还缺什么（不由本步骤完成）

1. **两个端点文件**：GDSC2 fitted dose-response（24Jul22）与 DepMap 24Q2 CRISPRGeneEffect.csv，放到允许读取的位置并以绝对路径传入。
2. **释放回执 `RELEASE_RECEIPT.json`**（create-once，PLAN §8）。运行脚本校验的字段与格式：
   - `protocol_id`: `"CREED_INTERNAL_FINAL_ONESHOT_V1"`
   - `plan_sha256`: `"ca3288c18736c6a572bb4a087da503148f694dd3c89d8f6c6afecbaec87bfdc1"`
   - `code_sha256`: `{"creed_core.py": "ae72a12c…", "oneshot.py": "50192cc4…", "sealed_io.py": "24679bce…"}`（`code/` 下全部 .py，键为文件名，必须恰好这三个）
   - `frozen_models_sha256`: `{"FROZEN_MANIFEST.json": "a2d530e9…", "inner_losses.npz": "143f6bd5…", "model.npz": "8e89f4a4…"}`（完整值见 `SHA256SUMS.v2`）
   - `environment`: `{"numpy": "2.0.2", "scipy": "1.13.1"}`
   - `internal_final_ids_sha256`: `"e8f278c49c8159c8…"`（= sha256(排序后的 123 个 SIDM 以换行连接并以换行结尾)；脚本从 `generator-fullpool-20261009-0001/resources/original_identity_split_ids.json` 重算并核对）
   - 以及 PLAN §8 要求的写入时间、授权记录（用户 2026-10-09 转达导师批准）、"写入前未读取任何 internal_final 数值"声明（脚本不校验内容，只随 summary.json 原样保存）。回执写入后目录改只读。
3. 之后只允许 PLAN §9 的 ADDENDUM；运行后不得基于结果改任何算子、臂、指标或判定规则。

## 5. 实现中需要声明的解释性决定（全部在冻结前写下）

- PLAN §6 F4 的"份额点估计落在 [0.15, 0.55] 且 F1/F2 成立"按 **RNA 与 P 两个份额都落在区间内且 F1、F2 都确认** 判定；两个份额及其 bootstrap 区间都单独报告。
- PLAN §4 的"M+P 实测参照"同时给 `M+P`（值核 + 掩码核，矩阵 run 的 P 编码，用于追回份额）与 `M+Pval`（纯值核，蛋白面板的教师，用于 R(k)）。
- 评估药物 = 123 中观测 ≥ 5 且 421 中观测 ≥ 20（PLAN §5）；CRISPR 靶标在 123 上同样要求观测 ≥ 5。
- bootstrap：细胞按 mmc2 组织分层有放回（空组织各自一层），药物按 ID 在评估药物内有放回，B=2000，种子 20261009，所有臂共用同一组抽样（配对）。符号检验 = 逐药 MSE 臂 < 基线 的比例 + 精确二项双侧 p（平局剔除）。
- 虚拟层只有 M→RNA、M→P（PLAN §4 只部署 M）；RNA→P 等方向不在本协议内。
- 没有折：不做 Nadeau–Bengio 检验。
