Data S3. Sealed-set release chain, related to Figure 6 and Table 1.

Plan with registration time and SHA-256, SHA256SUMS.v1 and .v2, freeze report and freeze review, release receipt,
frozen-model manifest, pre-sealed checkpoint, run log, progress log, summary and result draft of the single run, and
the independent recomputation report.

About this archive
- Run records are byte-for-byte copies (not edited). Files that are not copies of files of the server run directories
  (derived tables, renderings, and records kept outside the compute server) are described under "Files" below.
- Plain-text formats only (.json, .jsonl, .log, .md, .tsv, .txt, checksum lists without extension or with .v1-.v3).
- Most registered plans and audit records are in Chinese, as registered; they are not translated.
- Some files contain absolute file paths of the compute server (/public/home/<user>/...); they are left unedited so
  that the files stay byte-identical to the original records.
- Run folders have the layout of the run directory on the compute server, so each checksum list can be checked from
  its run folder (e.g. cd Data_S3/<run folder>; shasum -a 256 -c <list>). Entries for files not included here (the
  code files and the frozen model arrays) are reported as missing. Lines beginning with # are comments written by the
  runs; checkers report them as improperly formatted. CHECKSUM_INDEX.tsv (derived by the archive builder) gives the
  status of every entry: OK (verifies here), FAILED (a different version is at the listed path), ELSEWHERE (the same
  bytes are at the archive path given), NOT_INCLUDED.

Files
- internal_final/ has the layout of the server run directory internal-final-20261009-0001 for the files included
  (plan, registration time, SHA256SUMS.v1 and .v2, FREEZE_REPORT.md, RELEASE_RECEIPT.json,
  output/pre_sealed_checkpoint.json, logs/sealed_run.log, output/progress.jsonl, output/summary.json,
  output/RESULT_DRAFT.md, frozen_models/FROZEN_MANIFEST.json).
- review/FREEZE_REVIEW.md (read-only freeze review) and review/RECOMPUTE.md (independent recomputation report) were
  written by the reviewers outside the compute server; they are not listed in any checksum file.
- The frozen model arrays (model.npz, inner_losses.npz; SHA-256 in SHA256SUMS.v2) are not included and will be
  deposited in a DOI-minting repository before publication.
- CRISPR evaluated lines = 95: output/summary.json (n_eval_cells = 123) and output/RESULT_DRAFT.md count all 123
  sealed lines, of which 95 have DepMap 24Q2 CRISPR gene effects (corrected in review/RECOMPUTE.md). Items F1-F8 in
  these files are P1-P8 in the paper.
- Checksum verification from internal_final/ (counts of CHECKSUM_INDEX.tsv): OK 3, FAILED 0, ELSEWHERE 0, NOT_INCLUDED
  5; NOT_INCLUDED are the three code files and the two frozen arrays.

SHA-256 of every file in this archive:
426fe1f6aa6532eebdaba9eaa3b4930c16655b607a7a10bdd90f03e79e4ae428  Data_S3/CHECKSUM_INDEX.tsv
da2927ff9d73cfdbb4008d4db403437601a0ed3838ec5f7ec2932079c24e474a  Data_S3/internal_final/FREEZE_REPORT.md
ca3288c18736c6a572bb4a087da503148f694dd3c89d8f6c6afecbaec87bfdc1  Data_S3/internal_final/PLAN.md
434c194e0a6141a35361660c541a3cbd9c725b932f8a954a13b63baa4799fdf2  Data_S3/internal_final/PLAN_REGISTERED_AT.txt
96cd50fd301cbb9e3b8142214b9df419bacf304ce7cb19000431cc5947d4f04d  Data_S3/internal_final/RELEASE_RECEIPT.json
16c6906ce7905c64f09e706ca04aade5177657c7a10e8a5a758b0fc731197e57  Data_S3/internal_final/SHA256SUMS.v1
9477599e8d723a64e74d35767ec4581e9bb50104662ce5bbaa4bcfa16027a806  Data_S3/internal_final/SHA256SUMS.v2
a2d530e9ad59b8d4c43a398bf5eda795e2af35f3c6229a9106d558e2da48777e  Data_S3/internal_final/frozen_models/FROZEN_MANIFEST.json
25d3ea09d38ee19608b8473a6237eac7de2970f342d91a7a9551cdae4bc8a60e  Data_S3/internal_final/logs/sealed_run.log
54691faf43598793b5c9c29138ae1e5a470e72eb60a43d2069fd5b312b925949  Data_S3/internal_final/output/RESULT_DRAFT.md
ee51d1bae4fe0bc723ee2b742cf367f9f3b51192989f43c756fe33b00a095f89  Data_S3/internal_final/output/pre_sealed_checkpoint.json
5190827cb5c0016ff0e269e398c8832adb70f1d3210887fba891212e6380f820  Data_S3/internal_final/output/progress.jsonl
efda0b468297888745344517c2dac2cb259bce0f8a2500786eec44c5f87eeea2  Data_S3/internal_final/output/summary.json
9b4ff429ab76053618d3999498df62e5b23cd667bab969593c8c5c1149be4eb6  Data_S3/review/FREEZE_REVIEW.md
8dcfa8ac221697bd222b6d8426f3a31e898f0d4843ac15957f4c2ef8e24246a8  Data_S3/review/RECOMPUTE.md
