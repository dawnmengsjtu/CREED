Data S6. Protein panel tables, related to Figure 4.

Panel arms (k = 8–64, per-drug k, random seeds, with and without tissue, graph-on-panel arms) with per-fold sRMSE,
Spearman correlation, centered MSE and recovery under both denominators, and panel membership per bank (Table S5).

About this archive
- Run records are byte-for-byte copies (not edited). Files that are not copies of files of the server run directories
  (derived tables, renderings, and records kept outside the compute server) are described under "Files" below.
- Plain-text formats only (.csv, .json). JSON files use NaN for missing values (Python json syntax; strict parsers
  need NaN replaced by null).
- Chinese text, as written in the original records and not translated, occurs in: protein_panel/output/analysis.json.
- The run folder protein_panel/ has the layout of the run directory on the compute server; the runs' checksum lists
  are in Data S2 (Data_S2/CHECKSUM_INDEX.tsv shows which list covers each file of this archive).

Files
- protein_panel/ = run protein-panel-20261009-0001. output/*_main/bank_info.json give each bank's panels as column
  indices into the 6,692-column proteome; they are not listed in the run's OUTPUT_SHA256SUMS.
- panel_membership.csv (derived, not a run record): every index list of output/*_main/bank_info.json mapped to protein
  identifiers (protein_ids of the frozen 421-line source bundle, exported on 2026-10-11). Columns: scenario, fold,
  bank (inner-0..2, outer), panel (top64 = candidates ranked by relevance; R16s0..R32s4 = random panels, k = 16 or 32,
  seeds 0-4), position (rank 1-64 for top64; position in the stored, column-sorted list for random panels),
  column_index, protein_id, top64_score. The k-protein panel of a bank is the first k rows of its top64. Indices are
  0-based: mapping the outer-bank top-k panels this way reproduces every identifier list in output/analysis.json
  (panels.k*_in_all_5_outer), and 1-based mapping does not.
- Not listed in any run checksum list: panel_membership.csv, protein_panel/output/new_cell_main/bank_info.json,
  protein_panel/output/tissue_main/bank_info.json.

SHA-256 of every file in this archive:
7c6fd29517d0c1b61cbbd1c4892c440e482b3b10ac07b8964aec0981756e837d  Data_S6/panel_membership.csv
4cc27c8277c8bafc7f5de0d1db80ee7cd031ee8e94195bfe93fbe85393be7ddc  Data_S6/protein_panel/output/analysis.json
04dabfb59d6d2971e7f818714e901cd77c896c9b2402f586db0754d269325653  Data_S6/protein_panel/output/new_cell_main/bank_info.json
58e3de70c4dfeaaff6c7dd5c5ebc3202b96f5a32e150de83073a0f15b7f14436  Data_S6/protein_panel/output/new_cell_main/fold_metrics.csv
dd4807aa629d3511ca7c3458214deb7c0b21d9464ab1eb3848b512b9d92566ff  Data_S6/protein_panel/output/new_cell_main/summary.json
40f25545a4be8f0f5e3a3c3826883f43edfa9120b08edcc35b1b5cbcc706a94f  Data_S6/protein_panel/output/tissue_main/bank_info.json
82019cb3a8200f9949452038167ab505b6558e27f7bdeeec7cdad1344c351eff  Data_S6/protein_panel/output/tissue_main/fold_metrics.csv
35e04fb9d35945364806c44c0363cd96b6e3ea12f42c453072fb140fdd154014  Data_S6/protein_panel/output/tissue_main/summary.json
