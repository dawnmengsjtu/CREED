Data S9. Context-specific panels (N2), related to Figure 4.

Context panels (tissue, metabolite cluster) against global static and matched-random panels at k = 16/32/64, the "more
heads" effect, Jaccard overlap and the audit recomputation (English translation of the run's audit appendix) (Table
S7; Figure S3B).

About this archive
- Run records are byte-for-byte copies (not edited). Files that are not copies of files of the server run directories
  (derived tables, renderings, and records kept outside the compute server) are described under "Files" below.
- Plain-text formats only (.csv, .md, .txt).
- Chinese text, as written in the original records and not translated, occurs in: result_tables.md.
- The run folder probe2_context_abstain/ has the layout of the run directory on the compute server; the runs' checksum
  lists are in Data S2 (Data_S2/CHECKSUM_INDEX.tsv shows which list covers each file of this archive).

Files
- probe2_context_abstain/ = run probe2-context-abstain-20261009-0001 (part A: context-specific panels).
- result_tables.md (rendered, not a server file): the tables of the run's output/summary.json (SHA-256 4b09a68b..., in
  Data S2) rendered by the run's code/make_result_tables.py (bcbc584a..., listed in its OUTPUT_SHA256SUMS); rerunning
  python3 make_result_tables.py summary.json reproduces it byte for byte.
- audit_recomputation.txt (derived): English translation of the run's audit appendix (RESULT.md section "附：独立审计结论"),
  every value copied as is, followed by the Chinese original.
- Not listed in any run checksum list: audit_recomputation.txt, result_tables.md.

SHA-256 of every file in this archive:
116d667412df66a3dbada6a7075e8dc4f54b7e61e4fd389f43daa6fe1b62b774  Data_S9/audit_recomputation.txt
55ed80495dfaa15695a8a8e437fcd6e55d718069872bfe24521c85847a0f19e4  Data_S9/probe2_context_abstain/output/A/fold_metrics.csv
602e3f01f636f971dde9108bc8efa2cf8f436852f817896c87f21b53378d890f  Data_S9/result_tables.md
