Data S5. Protein sample-graph tables, related to Figure 3.

Candidates, control graphs, decomposition, leave-one-fold-out, grouped and two-stage bootstrap, and the 281-drug
common-panel sensitivity.

About this archive
- Files are byte-for-byte copies of the run records (not edited).
- Plain-text formats only (.csv, .json). JSON files use NaN for missing values (Python json syntax; strict parsers
  need NaN replaced by null).
- The run folder pushline_checks/ has the layout of the run directory on the compute server; the runs' checksum lists
  are in Data S2 (Data_S2/CHECKSUM_INDEX.tsv shows which list covers each file of this archive).

Files
- pushline_checks/ = run pushline-checks-20261009-0001.
- Every file of this archive is listed in a run checksum list in Data S2 (see Data_S2/CHECKSUM_INDEX.tsv).

SHA-256 of every file in this archive:
7ee30b02ff43b1ff84cf0412f14728f61ae92834a8a836370946ed75b17dcbce  Data_S5/pushline_checks/output/comparisons.csv
36e8de1c0e609a68427036ca43e1b425dca1d4b9efae97b41efa50058c224e90  Data_S5/pushline_checks/output/fold_scores.csv
6acf61605a8f07199fff176431d19d9fa6d4f33e459e54325a4bfde95d29b2ac  Data_S5/pushline_checks/output/pass_fail.csv
230c9bb47a61a503fbbc06b556fde025532ec48211ced3a9248b2a48f642dca4  Data_S5/pushline_checks/output/summary.json
