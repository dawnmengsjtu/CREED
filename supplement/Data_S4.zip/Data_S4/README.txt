Data S4. Cross-layer matrix tables, related to Figure 2.

All 24 primary comparisons with per-fold values, the tissue-label row, generator diagnostics (out-of-fold R², λ) and a
Bonferroni 0.05/24 column; per-fold metrics and per-drug metrics of every arm.

About this archive
- Run records are byte-for-byte copies (not edited). Files that are not copies of files of the server run directories
  (derived tables, renderings, and records kept outside the compute server) are described under "Files" below.
- Plain-text formats only (.csv, .json, .md). JSON files use NaN for missing values (Python json syntax; strict
  parsers need NaN replaced by null).
- Chinese text, as written in the original records and not translated, occurs in:
  crosslayer_matrix/output/matrix_new_cell.csv, crosslayer_matrix/output/matrix_tables.md,
  crosslayer_matrix/output/matrix_tissue.csv.
- The run folder crosslayer_matrix/ has the layout of the run directory on the compute server; the runs' checksum
  lists are in Data S2 (Data_S2/CHECKSUM_INDEX.tsv shows which list covers each file of this archive).

Files
- crosslayer_matrix/ = run crosslayer-matrix-20261009-0001; output/comparisons.csv holds all comparisons with per-fold
  values, wins, Nadeau-Bengio p and CI.
- bonferroni_primary24.csv (derived, not a run record): the 24 primary comparisons (kind headroom or recovered) of
  output/comparisons.csv, every value copied as is, plus threshold = 0.05/24 and significant = TRUE when p < threshold
  (4 rows; two-sided test, the sign is given by gain).
- Labels in output/matrix_new_cell.csv and output/matrix_tissue.csv (output/matrix_tables.md is in Chinese): 有空间 =
  headroom; 小幅空间 = small headroom; 无空间 = no headroom; 有恢复 = recovered; 无恢复 = not recovered; 部分收回 = partly recovered;
  基本未收回 = essentially not recovered (room_label, recovery_label and share_label; STAR Methods).
- No file of this archive is listed in a run checksum list (crosslayer-matrix-20261009-0001 wrote no output checksum
  list).

SHA-256 of every file in this archive:
65612e538d2412eaeacfeaa8af47aca10db1b81e4307fdd4a8b7ee274e258280  Data_S4/bonferroni_primary24.csv
7c2e5dbdd633ec32686724e1f09886f03ba5c8b6d3b6b704552b95e469c09bd8  Data_S4/crosslayer_matrix/output/analysis.json
bd5a22047b2c74d6ad06e37974513f40a30984db658d481873e707677eae747c  Data_S4/crosslayer_matrix/output/comparisons.csv
1e459edce39d8085614914351ec0cbc4c8b008f0165054d190d91942ecb7a4e3  Data_S4/crosslayer_matrix/output/matrix_new_cell.csv
27cabc620743ed9eacf026dfc494245f94f3d5d4d202f70693b56d29e005c0c6  Data_S4/crosslayer_matrix/output/matrix_tables.md
8f7467c3e8e5feacc5792be48a7c4f81d3e850fe1826e5f4ceada02a96784cfd  Data_S4/crosslayer_matrix/output/matrix_tissue.csv
7244e1134e739490bc813a4d55f09a1ebb3009df9e47ceffe8d7931ae8098f13  Data_S4/crosslayer_matrix/output/new_cell/bank_info.json
2d8db55f8975f30bd41451771bfea7e34d4a236b68758a8a0318731651fd6678  Data_S4/crosslayer_matrix/output/new_cell/fold_metrics.csv
e77db2a0908acc4a1c3900fd189d264349fdb3e55fe0ca24dc4fc4f2d9f25f62  Data_S4/crosslayer_matrix/output/new_cell/per_drug_metrics.csv
22f76d9351648db0788040921ddabe7cf32896c8c40671aa46281efb65bf6709  Data_S4/crosslayer_matrix/output/new_cell/summary.json
93c78e9d0136406df7ac4fc12317194a2fc9f8527d9d899d22bf519cdfe23596  Data_S4/crosslayer_matrix/output/tissue/bank_info.json
6af543f585c3eaa6400075a2396eda3b6be929b91c9f22350c21850bc51f0825  Data_S4/crosslayer_matrix/output/tissue/fold_metrics.csv
d040eabca2708947918abf80fe4552de09dbfa440c4f2f6c9d3da70bd7d03696  Data_S4/crosslayer_matrix/output/tissue/per_drug_metrics.csv
3ca33f8dc2b149497f3e5c0b0b512481350ddaf4d3c37c4af74b80c63fef26cb  Data_S4/crosslayer_matrix/output/tissue/summary.json
