Data S7. Gene panel tables, related to Figure 4.

Panel arms (k = 8–128, per-drug k, random seeds, with tissue, frozen-embedding base, two-layer 32 + 32 arm),
cross-layer comparisons with the protein panels, and gene membership per bank (Table S6).

About this archive
- Run records are byte-for-byte copies (not edited). Files that are not copies of files of the server run directories
  (derived tables, renderings, and records kept outside the compute server) are described under "Files" below.
- Plain-text formats only (.csv, .json, .md). JSON files use NaN for missing values (Python json syntax; strict
  parsers need NaN replaced by null).
- Chinese text, as written in the original records and not translated, occurs in: rna_panel/output/analysis.json,
  rna_panel/output/result_tables.md.
- The run folder rna_panel/ has the layout of the run directory on the compute server; the runs' checksum lists are in
  Data S2 (Data_S2/CHECKSUM_INDEX.tsv shows which list covers each file of this archive).

Files
- rna_panel/ = run rna-panel-20261009-0001. output/*/fold-*_bank_info.json give each bank's panels as column indices
  (genes: into the 34,985-gene aligned RNA bundle; P32: into the 6,692-column proteome).
- gene_panel_membership.csv (derived, not a run record): every index list of the bank_info files mapped to identifiers
  (gene_id of the aligned RNA bundle, with the symbol as annotation; protein_id of the source bundle; exported on
  2026-10-11). Columns: scenario, fold, bank, panel (top128 = genes ranked by relevance; G8-G128 = gene panels, the
  first k of top128; R16s0..R32s4 = random gene panels; P32 = the 32-protein part of the two-layer arm), position
  (rank for top128; position in the stored, column-sorted list otherwise), column_index, layer (RNA or protein),
  feature_id, symbol, score (top128_score). Indices are 0-based: mapping the outer-bank panels this way reproduces the
  gene symbols in output/analysis.json (panels.k*_in_all_5_outer and outer_top16_fold0), and 1-based mapping does not;
  every P32 equals the first 32 proteins of the protein-panel run's top64 for the same bank (Data S6).
- Not listed in any run checksum list: gene_panel_membership.csv.

SHA-256 of every file in this archive:
ec06908ce2e1f1fff68540070fdd795226bbb1e53322f6b22130a0d8cf95bc2a  Data_S7/gene_panel_membership.csv
5845e2ba4045a9735466425250eca0a1e8aa24b59798575492ea629a5f5ebedd  Data_S7/rna_panel/output/analysis.json
6750fbf536f4ebffda2c41b956f68b1200542a63f3e49ce3982126276fc0298f  Data_S7/rna_panel/output/fold_metrics.csv
3ab8fedd064627c8832ba6628bb1b3d6e175b661603ce2f37842ec6d9a173780  Data_S7/rna_panel/output/new_cell/fold-0_bank_info.json
b5113fce7ad511a94b6e2ff29bf69c8b16d520e8c02137e3f8f9e470a71fbe6a  Data_S7/rna_panel/output/new_cell/fold-1_bank_info.json
1979f64a55bf4177b00ee03b017ef0abc07bddaa085940f32878fa0ecdc565da  Data_S7/rna_panel/output/new_cell/fold-2_bank_info.json
5c86c6532b7dc567ae9f1db014414b8711788dee4a189b5310317f3f08f71d5d  Data_S7/rna_panel/output/new_cell/fold-3_bank_info.json
c4163b58b08dfceca48940eb6cc3c3c41798ea26574022358ea2b6fef211996d  Data_S7/rna_panel/output/new_cell/fold-4_bank_info.json
95a5c769d9b106e7fbdece558c2eca668d85d8f2f75548a29fe57e71a38a454d  Data_S7/rna_panel/output/result_tables.md
4e08c6f7e1d3a4ad2dda599c1f692d9e9fbdfb99d670efade775fe647c261b98  Data_S7/rna_panel/output/summary.json
0c36fc5e22ac969f306b0dac6897baeb246813f24034968ff229f6772fa39a4d  Data_S7/rna_panel/output/tissue/fold-0_bank_info.json
fe89f226c3193e0569c2c7b735785d8254bf25a6563105651d92c2a47391d36e  Data_S7/rna_panel/output/tissue/fold-1_bank_info.json
089fec2de7da615d3c646fc111c5596505bcc683ccc8e889fad04d199fcd6c1a  Data_S7/rna_panel/output/tissue/fold-2_bank_info.json
6b727d5df03c584acce2cac9076ea32dd9409255227f791f90af87d122343862  Data_S7/rna_panel/output/tissue/fold-3_bank_info.json
4f46bee5a1b6dc240d171e20cbd25029856be2cd5e7d0e7d48e055d6b00ad6e9  Data_S7/rna_panel/output/tissue/fold-4_bank_info.json
