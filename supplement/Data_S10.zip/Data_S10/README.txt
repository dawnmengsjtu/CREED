Data S10. Abstention (N3), related to Figure 4.

Spearman(proxy, error), AURC and the retained error at coverage 0.8 for u1, u2, u3, random and oracle orderings on M,
M + virtual RNA, M + virtual P, M + measured RNA and M + measured P; per-line risk–coverage tables (Table S7).

About this archive
- Files are byte-for-byte copies of the run records (not edited).
- Plain-text formats only (.csv, .json).
- The run folder probe2_context_abstain/ has the layout of the run directory on the compute server; the runs' checksum
  lists are in Data S2 (Data_S2/CHECKSUM_INDEX.tsv shows which list covers each file of this archive).

Files
- probe2_context_abstain/ = run probe2-context-abstain-20261009-0001 (part B: abstention).
- Not listed in any run checksum list: probe2_context_abstain/output/B/aurc_new_cell.csv,
  probe2_context_abstain/output/B/aurc_tissue.csv, probe2_context_abstain/output/B/riskcov_new_cell.csv,
  probe2_context_abstain/output/B/riskcov_tissue.csv.

SHA-256 of every file in this archive:
63b25aaa2d3616ff35ce9c657eb78b3dde1853fce76306330774f5aa1040a119  Data_S10/probe2_context_abstain/output/B/aurc.csv
9eb70773d4991cc69c592c89c790a118eaeb5e822830b8e7efc933f150036902  Data_S10/probe2_context_abstain/output/B/aurc_new_cell.csv
6429eca54522589620de7642d1bf2427a9dd5438e1a0f208da863d1837a45490  Data_S10/probe2_context_abstain/output/B/aurc_tissue.csv
aca088ad869d0f13b1881deb794799950c40fe9f996c98718873b7b8b696a94a  Data_S10/probe2_context_abstain/output/B/gen_check_new_cell.json
c29f3bc0865d7db99369f0b17e626ce3c7cf79ccae1a00f61e8e699eea377e98  Data_S10/probe2_context_abstain/output/B/gen_check_tissue.json
a1425e1eb66bdd6946e699411e27853f8b1b337d4615c1b76cca8a6d0c4651a4  Data_S10/probe2_context_abstain/output/B/percell_new_cell.csv
e2f564f7db2aa1e5d75e7d53f6cc24c177b47f6dcbf7d5ba0035f025fc3b0a47  Data_S10/probe2_context_abstain/output/B/percell_tissue.csv
ef6ef7345126ce890613190994edb9b3b51b16a582b080dbdd7c7dad57ef4201  Data_S10/probe2_context_abstain/output/B/riskcov.csv
f1bc84bac8e4804e6a45d76b96d86115e1b7b67a38113af97c5cc8fd7377ecf7  Data_S10/probe2_context_abstain/output/B/riskcov_new_cell.csv
48c71acf93fa440d50fbab1787986aa06f44057851bc575e77e68156cdeb611d  Data_S10/probe2_context_abstain/output/B/riskcov_tissue.csv
